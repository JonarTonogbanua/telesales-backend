$(document).ready(function(){
    $("form").on('submit', function(event){
        event.preventDefault();
        var formData = $("form").serialize();
        $("input").prop('disabled', true);
        $.ajax({
            type: 'POST',
            url: $("form").attr('action'),
            data: formData,
            dataType : 'JSON',
        }).done(function(e){
            $("#error-cont").fadeIn();
            $("#error-cont").addClass('alert-'+e.type);
            $("#error-cont").html(e.message);
            $("input[type=password]").val('');
            $("input[type=password]").focus();
            var response = e.logged_in;
            if(response == 1){
                location.reload();
            }else{
                $("input").prop('disabled', false);
            }
            
        }).fail(function(){
            alert('LOGIN REQUEST ERROR : Contact the developer to resolve issue.');
            //location.reload();
        });
    });
});