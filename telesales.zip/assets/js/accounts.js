jQuery(document).ready(function() {
  jQuery(".dataTables span.pubdate").timeago();
});
$(document).ready(function(){
    $('.dataTables').DataTable({
        pageLength: 10,
        responsive: true,
        dom: '<"html5buttons"B>lTfgitp',
        buttons: [
        ]
    });
    $('.btn-create').click(function(){
        doCreate();
    });
    $('.dataTables').on('click', '.btn-action', function(){
        var action = $(this).attr('data-action');
        var userid = $(this).parents('tr').attr('user-id');
        if(action == "edit"){
            doEdit(userid);
        }else if(action == "view"){
            doView(userid);
        }else{
            doDelete(userid);
        }
    });
    doCreate = function(){
        $('#createModal').modal('show');
    }
    doView = function(userid){
        $('button').prop('disabled', true);
        $("#stat-load").show();
    }
    doEdit = function(userid){
        data = {
            userid : userid
        }
        $.ajax({
            type: 'POST',
            url: BASE_URL + "telesales/get_telesales_info",
            data: data,
            dataType : 'JSON',
        }).done(function(e){
            $("h3[name=edit-username]").text(e.user_name);
            $("input[name=edit-nickname]").val(e.user_nickname);
            $("select[name=edit-country]").val(e.user_country).change();
            $("select[name=edit-language]").val(e.user_language).change();
            $('#editModal').modal('show');
        }).fail(function(){
            alert('FATAL ERROR : Contact the developer to resolve issue.');
        });
    }
    doDelete = function(){
        swal({
            title: "Delete User",
            text: "Are you sure?",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Confirm",
            closeOnConfirm: false
        }, function () {
            
            swal("Deleted!", "Action has been cancelled.", "success");
        });
    }
    $('[data-toggle="tooltip"]').tooltip(); 
    
    $("#reg-form").on('submit', function(event){
        event.preventDefault();
        var formData = $("#reg-form").serialize();
        $("input").prop('disabled', true);
        $("select").prop('disabled', true);
        $.ajax({
            type: 'POST',
            url: $("#reg-form").attr('action'),
            data: formData,
            dataType : 'JSON',
        }).done(function(e){
            var response = e.result;
            if(response == "true"){
                $("modal").modal('close');
                location.reload();
            }else{
                $("#reg-cont").fadeIn();
                $("#reg-cont").addClass('alert-'+e.type);
                $("#reg-cont").html(e.message);
                $("input").prop('disabled', false);
                $("select").prop('disabled', false);
            }
        }).fail(function(){
            alert('FATAL ERROR : Contact the developer to resolve issue.');
        });
    });
    $("#edit-form").on('submit', function(event){
        event.preventDefault();
        var formData = $("#edit-form").serialize();
        $("input").prop('disabled', true);
        $("select").prop('disabled', true);
        $.ajax({
            type: 'POST',
            url: $("#edit-form").attr('action'),
            data: formData,
            dataType : 'JSON',
        }).done(function(e){
            var response = e.result;
            if(response == "true"){
                $("modal").modal('close');
                location.reload();
            }else{
                $("#reg-cont").fadeIn();
                $("#reg-cont").addClass('alert-'+e.type);
                $("#reg-cont").html(e.message);
                $("input").prop('disabled', false);
                $("select").prop('disabled', false);
            }
        }).fail(function(){
            alert('FATAL ERROR : Contact the developer to resolve issue.');
        });
    });
});