$(document).ready(function(){
	$('.form-interest input').prop('disabled', true);
	$('.form-interest button').prop('disabled', true);
	$("tab").click(function(){
		alert();
	});
	$('#skypecall').on('click', function(){
		$("#output-container").slideToggle(300);
	});
	$('#close-cont').on('click', function(){
		$("#output-container").slideToggle(300);
	});
	
	var timer = new Timer();
	$(".update-links").on('click', function(){
		var modal = $(this).attr('data-update');
		$("#"+modal).modal('show');
	});
	var settings = {
		labels: {
			current: "current step:",
			pagination: "Pagination",
			finish: "Finish",
			next: "Next",
			previous: "Previous",
			loading: "Loading ...",
		},
		onFinishing: function(e, currentIndex) {

			return true;
		},
		onFinished: function(e, currentIndex) {

		},
		enableFinishButton: false
	};
	$(".form-interest").on('submit', function(event){
		event.preventDefault();
		var dis = $(this);
		var formData = $(this).serialize();
		$("input").prop('disabled', true);
		$("select").prop('disabled', true);
		$.ajax({
			type: 'POST',
			url: $(this).attr('action'),
			data: formData,
			dataType : 'JSON',
		}).done(function(e){
			swal({
				html: true,
				title : e.title,
				text : e.message,
				type : e.type,
			});
			if(e.type == "success"){
				var destination =  $(dis).attr('data-tab');
				$('.nav-tabs a[href="#' + destination + '"]').tab('show');
			}
			$("input").prop('disabled', false);
			$("select").prop('disabled', false);
		}).fail(function(){
			alert('FATAL ERROR : Contact the developer to resolve issue.');
			location.reload();
		});
	});
	$(".btn-tab-page").on('click', function(){
		var destination = $(this).attr('data-tab');
		$('.nav-tabs a[href="#' + destination + '"]').tab('show');
		$(".rad-interest").prop('checked', false);
	});
	$(".form-revision1").on('submit', function(event){
		event.preventDefault();
		var field = $("input[name=field]").val();
		var newval = $("input[name="+field+"]").val().replace(/\s/g,'');
		var oldval = $("input[name="+field+"]").attr('placeholder');
		
		if(oldval == newval){
			swal("Update info","No changes were made.", 'info');
			$('.modal').modal('hide');
			return false;
		}
		var formData = $(".form-revision1").serialize();
		$("input").prop('disabled', true);
		$("select").prop('disabled', true);
		$.ajax({
			type: 'POST',
			url: $(".form-revision1").attr('action'),
			data: formData,
			dataType : 'JSON',
		}).done(function(e){
			swal({
				html: true,
				title : e.title,
				text : e.message,
				type : e.type,
			});
			$("input").prop('disabled', false);
			$("select").prop('disabled', false);
			$("input[name="+field+"]").attr('placeholder', newval);
			$('.modal').modal('hide');
		}).fail(function(){
			alert('FATAL ERROR : Contact the developer to resolve issue.');
			location.reload();
		});
	});
	$(".form-revision2").on('submit', function(event){
		event.preventDefault();
		var field = $("input[name=field]").val();
		var newval = $("input[name="+field+"]").val().replace(/\s/g,'');
		var oldval = $("input[name="+field+"]").attr('placeholder');
		
		if(oldval == newval){
			swal("Update info","No changes were made.", 'info');
			$('.modal').modal('hide');
			return false;
		}
		var formData = $(".form-revision2").serialize();
		$("input").prop('disabled', true);
		$("select").prop('disabled', true);
		$.ajax({
			type: 'POST',
			url: $(".form-revision2").attr('action'),
			data: formData,
			dataType : 'JSON',
		}).done(function(e){
			swal({
				html: true,
				title : e.title,
				text : e.message,
				type : e.type,
			});
			$("input").prop('disabled', false);
			$("select").prop('disabled', false);
			$("input[name="+field+"]").attr('placeholder', newval);
			$('.modal').modal('hide');
		}).fail(function(){
			alert('FATAL ERROR : Contact the developer to resolve issue.');
		});
	});
	$("#result-wizard").on('submit', function(event){
		event.preventDefault();
		var formData = $("#result-wizard").serialize();
		swal({
			title: "Are you sure?",
			text: "Review all data first before submitting",
			type: "warning",
			showCancelButton: true,
			closeOnConfirm: false,
			showLoaderOnConfirm: true,
		},
		function(isConfirm){
			if (isConfirm) {
				$.ajax({
					type: 'POST',
					url: BASE_URL + 'agent/review_deal',
					data: formData,
					dataType : 'JSON',
				}).done(function(e){
					var response = e.result;
					if(response === true){
						submitReview();
					}else{
						swal({
							title: "No promotion offered",
							text: "Are you sure you want to submit data?",
							type: "warning",
							showCancelButton: true,
							closeOnConfirm: false,
							showLoaderOnConfirm: true,
						},
						function(isConfirm){
							if (isConfirm) {
								submitReview();
							}
						});
					}
				}).fail(function(){
					alert('FATAL ERROR : Contact the developer to resolve issue.');
				});

			} else {
				swal("Cancelled", "Action cancelled", "error");
			}
			$("input").prop('disabled', false);
			$("select").prop('disabled', false);
		});
	});
	submitReview = function(){
		var formData = $("#result-wizard").serialize();
		$("input").prop('disabled', true);
		$("select").prop('disabled', true);
		$.ajax({
			type: 'POST',
			url: $("#result-wizard").attr('action'),
			data: formData,
			dataType : 'JSON',
		}).done(function(e){
			var response = e.result;
			if(response == "true"){
				nextCall();
				swal(e.title, e.message, e.type);
				$("input[type=radio]").prop('disabled', false);
			}else{
				$("#form-err").fadeIn();
				$("#form-err").addClass('alert-'+e.type);
				$("#form-err").html(e.message);
				$("input").prop('disabled', false);
				$("select").prop('disabled', false);
				swal({
					html: true,
					title : e.title,
					text : e.message,
					type : e.type,
				});
			}
		}).fail(function(){
			alert('FATAL ERROR : Contact the developer to resolve issue.');
		});
	}
	$("#wizard").steps(settings);
	$('.dataTables').DataTable({
		pageLength: 10,
		responsive: true,
		dom: '<"html5buttons"B>lTfgitp',
		buttons: [
		],
		"lengthChange": false,
		"searching": false
	});
	$('.binder').click(function(){
		var binds = $(this).attr('bind');
		if(binds == "reached"){
			$('.panel-body').removeClass('mute-bg');
			$('.menus').removeClass('mute-bg');
			$('.form-interest button').prop('disabled', false);
		}else{
			$('.panel-body').addClass('mute-bg');
			$('.menus').addClass('mute-bg');
			$('.form-interest input').prop('disabled', true);
			$('.form-interest button').prop('disabled', true);
		}
		$('.l2').hide();
		$('.l3').hide();
		$('div[data-bind='+binds+']').show();
	});
	$('.binder2').click(function(){
		var binds = $(this).attr('bind');
		if(binds == "full"){
			$('.form-interest input').prop('disabled', false);
		}else{
			$('.form-interest input').prop('disabled', true);
		}
		$('.l3').hide();
		$('div[data-bind='+binds+']').show();
	});
	var takebreak = 0;
	$("#takebreak").click(function(){
		validateMe();
	});
	validateMe = function(){
		takebreak = 1;
		$.ajax({
			type: 'POST',
			url: BASE_URL + "agent/start_break",
			dataType : 'JSON',
		}).done(function(e){
			if(e.result === true){
				$("#nextcall-container").hide();
				$("#breaktime-container").fadeIn(500).addClass('animated fadeInRight');
				timer.start({startValues: {seconds: 0}});
				timer.addEventListener('secondsUpdated', function (e) {
					$('#timer').html(timer.getTimeValues().toString());
				});
			}else{
				swal({
					title : 'Cheatin aren\'t we?',
					text : 'Finish current transaction first!',
					type : 'error',
					timer: 1900,
					showConfirmButton: false,
				});
				setTimeout(function(){
					location.reload();
				},2000);
			}
		}).fail(function(){
			alert('FATAL ERROR : Contact the developer to resolve issue.');
		});
		$("button").prop('disabled', false);
	}
	$(".dataTables").on('click', '.view-remark', function(){
		$("button").prop('disabled', true);
		var dataTrans = $(this).attr('data-trans');
		data = {
			dataTrans : dataTrans,
		};
		$.ajax({
			type: 'POST',
			url: BASE_URL + "agent/get_transaction_details",
			data: data,
			dataType : 'JSON',
		}).done(function(e){
			var response = e.result;
			if(response === true){
				$('input[name=trans_id]').val(e.trans_id);
				$('input[name=handler]').val(e.handler);
				$('input[name=call_type]').val(e.call_type);
				$('input[name=res]').val(e.res);
				$('input[name=type]').val(e.type);
				$('input[name=action]').val(e.action);
				$('input[name=duration]').val(e.duration);
				$('input[name=promo_title]').val(e.promo_title);
				$('input[name=add_action]').val(e.add_action);
				$('input[name=startend]').val(e.start_time + " ~ " + e.end_time);
				$("#remarksModal").modal('show');
			}else{
				swal({
					html: true,
					title : e.title,
					text : e.message,
					type : e.type,
				});
			}
		}).fail(function(){
			alert('FATAL ERROR : Contact the developer to resolve issue.');
		});
		$("button").prop('disabled', false);
	});
	$("#form-end-break").on('submit',function(event){
		event.preventDefault();
		swal({
			title: "Confirm Action",
			text: "Resume your session?",
			type: "info",
			showCancelButton: true,
			closeOnConfirm: false,
			showLoaderOnConfirm: true,
		},
		function(){
			var formData = $("#form-end-break").serialize();
			$("input").prop('disabled', true);
			$("select").prop('disabled', true);
			$.ajax({
				type: 'POST',
				url: $("#form-end-break").attr('action'),
				data: formData,
				dataType : 'JSON',
			}).done(function(e){
				var response = e.result;
				if(response === true){
					timer.stop();
					location.reload();
				}else{
					swal({
						title : 'Before you resume',
						text : e.message,
						type : 'error',
						timer: 1900,
						html: true,
						showConfirmButton: false,
					});
				}
			}).fail(function(){
				alert('FATAL ERROR : Contact the developer to resolve issue.');
			});
			$("input").prop('disabled', false);
			$("select").prop('disabled', false);
		});
	});
	$("#breakdeed").click(function(){
		$("#resumecall").attr("disabled", false);
	});
	nextCall = function(){
		setTimeout(function(){
			$(this).attr('disabled', true);
			$("#forms").addClass('fadeOutLeft animated');
			$("#forms").fadeOut(300);
			$("#timer-container").fadeIn(300);
			var totaltime = graceperiod;
			var count = parseInt($('#time').text());
			function update(percent){
				var deg;
				if(percent<(totaltime/2)){
					deg = 90 + (360*percent/totaltime);
					$('.pie').css('background-image',
						'linear-gradient('+deg+'deg, transparent 50%, white 50%),linear-gradient(90deg, white 50%, transparent 50%)'
						);
				} else if(percent>=(totaltime/2)){
					deg = -90 + (360*percent/totaltime);
					$('.pie').css('background-image',
						'linear-gradient('+deg+'deg, transparent 50%, #1fbba6 50%),linear-gradient(90deg, white 50%, transparent 50%)'
						);
				}
			}
			myCounter = setInterval(function () {
				if(takebreak == 0){
					if(count==totaltime){
						clearInterval(myCounter);
						location.reload();
					}else{
						count+=1;
					}
					$('#time').html(totaltime-count);
					update(count);
				}else{
					clearInterval(myCounter);
				}
			}, 1000);
		}, 2000);
	}
	if(offset > 0){
		$("#nextcall-container").hide();
		$("#breaktime-container").fadeIn(500).addClass('animated fadeInRight');
		timer.start({startValues: {seconds: offset}});
		timer.addEventListener('secondsUpdated', function (e) {
			$('#timer').html(timer.getTimeValues().toString());
		});
	}
});