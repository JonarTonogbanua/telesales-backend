$(document).ready(function(){
    var ismoved = false;
    $('.dataTables').DataTable({
        pageLength: 15,
        responsive: true,
        dom: '<"html5buttons"B>lTfgitp',
        buttons: [
        ],
        "order": [[ 0, "desc" ]],
        "lengthChange": false
    });
    $('.btn-create').click(function(){
        doCreate();
    });
    $('.dataTables').on('click',".btn-action",function(){
        var action = $(this).attr('data-action');
        var promoid = $(this).parents('tr').attr('promo-id');
        if(action == "create"){
            doCreate();
        }else if(action == "edit"){
            doEdit(promoid);
        }else{
            doDelete(promoid);
        }
    });
    $("#close-extend").click(function(){
        $(this).parents('.modal-body').fadeOut(300);
        $( "#createModal .modal-dialog" ).animate({
            left: "+=200",
        },500, function(){
            ismoved = false;
        });
    });
    $('#data_1 .input-group.date').datepicker({
        todayBtn: "linked",
        keyboardNavigation: false,
        forceParse: false,
        calendarWeeks: true,
        autoclose: true
    });
    $('.clockpicker').clockpicker();
    doCreate = function(){
        $('#createModal').modal('show');
    }
    doEdit = function(promoid){
        data = {
            promoid : promoid
        }
        $.ajax({
            type: 'POST',
            url: BASE_URL + "telesales/get_promo_info",
            data: data,
            dataType : 'JSON',
        }).done(function(e){
            $("select[name=campaign-id]").val(e.campaign_id).change();
            $("h3[name=edit-code]").text(e.promo_code);
            $("input[name=edit-id]").val(e.promo_id);
            $("select[name=edit-campaign").val(e.campaign_id).change();
            $("input[name=edit-title").val(e.promo_title);
            $("textarea[name=edit-link]").val(e.promo_link);
            $("textarea[name=edit-tnc]").val(e.custom_tnc);
            $("textarea[name=edit-notes]").val(e.promo_notes);
            $("select[name=edit-status]").val(e.promo_status).change();
            if(e.is_tnc_custom == 1){
                $('input[name=edit-iscustom]').prop('checked', true);
            }else{
                $('input[name=edit-iscustom]').prop('checked', false);
            }
            $('#editModal').modal('show');
        }).fail(function(){
            alert('FATAL ERROR : Contact the developer to resolve issue.');
        });
    }
    doDelete = function(promoid){
        data = {
            promo_id : promoid,
        }
        swal({
            title: "Are you sure?",
            text: "Delete selected promotion",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Confirm",
            closeOnConfirm: false
        }, function () {
            $.ajax({
                type: 'POST',
                url: BASE_URL + "telesales/delete_promotion",
                data: data,
                dataType : 'JSON',
            }).done(function(e){
                if(e.result === true){
                    swal('Success', e.message, 'success');
                    setTimeout(function(){
                        location.reload();
                    },2000);
                }else{
                    swal('Failed', e.message, 'error');
                }
            }).fail(function(){
                alert('FATAL ERROR : Contact the developer to resolve issue.');
            });
        });
    }
    $('#campaign-select').on('change', function(){
        var campaignid = $(this).val();
        $('select').attr('disabled', true);
        $('input').attr('disabled', true);
        $('textarea').attr('disabled', true);
        $('.campaign-info').fadeIn(100);
        $('.sk-spinner').fadeIn(300);
        $('#campaign-info').hide();
        data = {
            campaignid : campaignid
        }
        $.ajax({
            type: 'POST',
            url: BASE_URL + "telesales/get_campaign_info",
            data: data,
            dataType : 'JSON',
        }).done(function(e){
            $('input[data-tag=info-title]').val(e.campaign_title);
            $('input[data-tag=info-type]').val(e.call_type + " call");
            $('input[data-tag=info-country]').val(e.campaign_country);
            $('input[data-tag=info-product]').val(e.product_type);
            $('input[data-tag=info-total]').val(e.total);
            $('textarea[data-tag=info-tnc]').val(e.campaign_tnc);
            $('.linkto').attr("href", BASE_URL + "telesales/campaign-management/campaigns?cid=" + e.cid);
            if(e.is_default == 1){
                $('input[data-tag=info-default]').val('YES');
                $('input[data-tag=info-start]').val('-');
                $('input[data-tag=info-end]').val('-');
            }else{
                $('input[data-tag=info-default]').val('NO');
                $('input[data-tag=info-start]').val(e.start_date +" @ " +e.start_time);
                $('input[data-tag=info-end]').val(e.end_date +" @ " +e.end_time);
            }
            setTimeout(function(){
                if(ismoved === false){
                    $( "#createModal .modal-dialog" ).animate({
                        left: "-=200",
                    },500, function(){
                        ismoved = true;
                    });
                }
                $('.sk-spinner').hide();
                $('#campaign-info').fadeIn(300);
                $('select').attr('disabled', false);
                $('input').attr('disabled', false);
                $('textarea').attr('disabled', false);
            },500);
        }).fail(function(){
            alert('FATAL ERROR : Contact the developer to resolve issue.');
        });
    });
    $("#promotion-form").on('submit', function(event){
        event.preventDefault();
        var formData = $("#promotion-form").serialize();
        $("input").prop('disabled', true);
        $("select").prop('disabled', true);
        $.ajax({
            type: 'POST',
            url: $("#promotion-form").attr('action'),
            data: formData,
            dataType : 'JSON',
        }).done(function(e){
            var response = e.result;
            if(response == "true"){
                $("modal").modal('close');
                swal(e.title, e.message, e.type);
                setTimeout(function(){
                    location.reload();
                },1500);
            }else{
                $("#edit-promo").fadeIn();
                $("#edit-promo").addClass('alert-'+e.type);
                $("#edit-promo").html(e.message);
                $("input").prop('disabled', false);
                $("select").prop('disabled', false);
            }
        }).fail(function(){
            alert('FATAL ERROR : Contact the developer to resolve issue.');
        });
    });
    $("#edit-promo-form").on('submit', function(event){
        event.preventDefault();
        var formData = $("#edit-promo-form").serialize();
        $("input").prop('disabled', true);
        $("select").prop('disabled', true);
        $.ajax({
            type: 'POST',
            url: $("#edit-promo-form").attr('action'),
            data: formData,
            dataType : 'JSON',
        }).done(function(e){
            var response = e.result;
            if(response == "true"){
                $("modal").modal('close');
                swal(e.title, e.message, e.type);
                setTimeout(function(){
                    location.reload();
                },1500);
            }else{
                $("#reg-promo").fadeIn();
                $("#reg-promo").addClass('alert-'+e.type);
                $("#reg-promo").html(e.message);
                $("input").prop('disabled', false);
                $("select").prop('disabled', false);
            }
        }).fail(function(){
            alert('FATAL ERROR : Contact the developer to resolve issue.');
        });
    });
});