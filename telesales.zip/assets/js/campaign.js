$(document).ready(function(){
    table = $('.dataTables').DataTable({
        pageLength: 15,
        responsive: true,
        dom: '<"html5buttons"B>lTfgitp',
        buttons: [
        ],
        "order": [[ 0, "desc" ]],
        "lengthChange": false
    });
    var thebtn;
    $('.dataTables').on('click','.btn-action',function(){
        var action = $(this).attr('data-action');
        thebtn = $(this);
        var campaignid = $(this).parents('tr').attr('campaign-id');
        console.log(campaignid);
        if(action == "create"){
            doCreate();
        }else if(action == "edit"){
            doEdit(campaignid);
        }else{
            doDelete(campaignid);
        }
    });
    $('.btn-create').click(function(){
        doCreate();
    });
    $('#data_1 .input-group.date').datepicker({
        todayBtn: "linked",
        keyboardNavigation: false,
        forceParse: false,
        calendarWeeks: true,
        autoclose: true
    });
    $('.clockpicker').clockpicker();
    $("#edit-campaign-form").on('submit', function(event){
        event.preventDefault();
        var formData = $("#edit-campaign-form").serialize();
        $("input").prop('readonly', true);
        $("select").prop('readonly', true);
        $.ajax({
            type: 'POST',
            url: $("#edit-campaign-form").attr('action'),
            data: formData,
            dataType : 'JSON',
        }).done(function(e){
            var response = e.result;
            if(response == "true"){
                $("modal").modal('close');
                swal(e.title, e.message, e.type);
                setTimeout(function(){
                    location.reload();
                },1500);
            }else{
                $("#edit-camp").fadeIn();
                $("#edit-camp").addClass('alert-'+e.type);
                $("#edit-camp").html(e.message);
                $("input").prop('readonly', false);
                $("select").prop('readonly', false);
            }
        }).fail(function(){
            alert('FATAL ERROR : Contact the developer to resolve issue.');
        });
    });
    $("#campaign-form").on('submit', function(event){
        event.preventDefault();
        var formData = $("#campaign-form").serialize();
        $("input").prop('disabled', true);
        $("select").prop('disabled', true);
        $.ajax({
            type: 'POST',
            url: $("#campaign-form").attr('action'),
            data: formData,
            dataType : 'JSON',
        }).done(function(e){
            var response = e.result;
            if(response == "true"){
                $("modal").modal('close');
                swal(e.title, e.message, e.type);
                setTimeout(function(){
                    location.reload();
                },1500);
            }else{
                $("#reg-camp").fadeIn();
                $("#reg-camp").addClass('alert-'+e.type);
                $("#reg-camp").html(e.message);
                $("input").prop('disabled', false);
                $("select").prop('disabled', false);
            }
        }).fail(function(){
            alert('FATAL ERROR : Contact the developer to resolve issue.');
        });
    });
    doCreate = function(){
        $('#createModal').modal('show');
    }
    doEdit = function(campaignid){
        data = {
            campaignid : campaignid
        }
        $.ajax({
            type: 'POST',
            url: BASE_URL + "telesales/get_campaign_info",
            data: data,
            dataType : 'JSON',
        }).done(function(e){
            $("h3[name=edit-id]").text(e.cid);
            $("input[name=edit-id]").val(e.cid);
            $("select[name=edit-product]").val(e.product_type).change();
            $("select[name=edit-country]").val(e.campaign_country).change();
            $("select[name=edit-calltype]").val(e.call_type).change();
            $("select[name=edit-status]").val(e.is_enabled).change();
            $("input[name=edit-title]").val(e.campaign_title);
            $("input[name=edit-isdefault]").val(e.is_default);
            $("textarea[name=edit-tnc]").html(e.campaign_tnc);
            if(e.is_default == 1){
                $('.duration').attr('disabled', true);
                $("select[name=edit-status]").attr('readonly', true);
                $("input[name=edit-startdate]").val("-").change();
                $("input[name=edit-starttime]").val("-").change();
                $("input[name=edit-enddate]").val("-").change();
                $("input[name=edit-endtime]").val("-").change();
            }else{
                $('.duration').attr('disabled', false);
                $("select[name=edit-status]").attr('readonly', false);
                $("input[name=edit-startdate]").val(e.start_date).change();
                $("input[name=edit-starttime]").val(e.start_time).change();
                $("input[name=edit-enddate]").val(e.end_date).change();
                $("input[name=edit-endtime]").val(e.end_time).change();
            }
            $('#editModal').modal('show');
        }).fail(function(){
            alert('FATAL ERROR : Contact the developer to resolve issue.');
        });
    }
    doDelete = function(campaignid){
        swal({
            title: "Move to trash",
            text: "Are you sure?",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Confirm",
            closeOnConfirm: false,
            showLoaderOnConfirm: true,
        }, function () {
            data = {
                campaignid : campaignid
            }
            $.ajax({
                type: 'POST',
                url: BASE_URL + "telesales/trash_campaign",
                data: data,
                dataType : 'JSON',
            }).done(function(e){

                if(e.result == "true"){
                    table.row( $(thebtn).parents('tr') ).remove().draw();
                }else{

                }
                swal(e.title, e.message, e.type);
            }).fail(function(){
                alert('FATAL ERROR : Contact the developer to resolve issue.');
            });
        });
    }
});