<?php $greetings = array('Good day', 'Hey', 'Hi', 'Howdy', 'Good to see you', ); ?>
<body class="top-navigation">
    <div id="wrapper">
        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom white-bg">
        <nav class="navbar navbar-fixed-top" role="navigation">
            <div class="navbar-header">
                <button aria-controls="navbar" aria-expanded="false" data-target="#navbar" data-toggle="collapse" class="navbar-toggle collapsed" type="button">
                    <i class="fa fa-reorder"></i>
                </button>
                <a href="javascript:void(0);" class="navbar-brand">TLS</a>
            </div>
            <div class="navbar-collapse collapse" id="navbar">
                <ul class="nav navbar-top-links navbar-left">
                    <li>
                        <a href=""><?php echo $greetings[rand(0,4)] ?>, <?php echo ucfirst($this->session->userdata('ck_nickname')); ?>! </a>
                    </li>
                </ul>
                <ul class="nav navbar-top-links navbar-right">
                <li>
                    <span class="m-r-sm welcome-message text-info">Reached Calls : <?php echo $quick_count[0]["reached"]; ?></span>
                    <span class="m-r-sm welcome-message text-danger">Unreached Calls : <?php echo $quick_count[1]["unreached"]; ?></span>
                    <span class="m-r-sm welcome-message text-warning">Invalid Number : <?php echo $quick_count[2]["invalid"]; ?></span>|
                    <span class="m-r-sm welcome-message text-warning"><strong>Total Call  : <?php echo ($quick_count[2]["invalid"] + $quick_count[1]["unreached"] + $quick_count[0]["reached"]); ?></strong></span>
                </li>
                    <li>
                        <a href="<?php echo base_url('logout'); ?>">
                            <i class="fa fa-sign-out"></i> Log out
                        </a>
                    </li>
                </ul>
            </div>
        </nav>
        </div>