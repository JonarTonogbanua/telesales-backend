<script src="<?php echo base_url('assets/js/jquery-3.1.1.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/metisMenu/jquery.metisMenu.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/slimscroll/jquery.slimscroll.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/sweetalert/sweetalert.min.js'); ?>"></script>
<!-- Custom and plugin javascript -->
<script src="<?php echo base_url('assets/js/inspinia.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/easytimer.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/pace/pace.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/jasny/jasny-bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/datatables.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/steps/jquery.steps.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/validate/jquery.validate.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/iCheck/icheck.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/ponelib.js'); ?>"></script>
<script>
	<?php
	$offset = 0;
	if($on_break){
		$offset = time() - $on_break->start_time;
	}
	?>;
	var offset = <?php echo $offset; ?>;
	var graceperiod = <?php echo $settings->grace_period; ?>;
	notified = 0;
	<?php if(!$on_queue){ ?>
		setInterval(function(){
			if(notified == 0){
				$.ajax({
					type: 'POST',
					url: BASE_URL + "agent/check_queue",
					dataType : 'JSON',
				}).done(function(e){
					if(e.have_queue === true){
						notified = 1;
						swal({
							html: true,
							title : "Hi <?php echo ucfirst($this->session->userdata('ck_nickname')) ?>!" ,
							text : "A call is waiting at the queue :)",
							type : "info",
							showCancelButton: false,
							closeOnConfirm: false,
							closeOnCancel: false,
							confirmButtonText: "Go",
						},
						function(isConfirm){
							if (isConfirm) {
								location.reload();
							}
						});
					}
				});
			}
		},10000);
		<?php } ?>
	</script>
	<script src="<?php echo base_url('assets/js/main.js'); ?>"></script>
