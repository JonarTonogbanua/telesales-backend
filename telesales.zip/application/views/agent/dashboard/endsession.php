<div class="container-fluid margint50 text-center p-h-xl">
	<h1>No calls on queue, <?php echo ucfirst($this->session->userdata('ck_name')); ?></h1>
	<h4>You might wanna check today's report</h4>
	<div class="row">
		<div class="col-xs-12">
			<h4>Legends : </h4>
		</div>
		<div class="col-xs-12">
			<span class="label td-yellow">&emsp;</span>
			Rescheduled Calls&emsp;
		</div>
	</div>
	<br/>
	<table class="dataTables table table-condensed table-striped">
		<thead>
			<tr>
				<th>Login ID</th>
				<th>Call Type</th>
				<th>Duration</th>
				<th>Start Time</th>
				<th>End Time</th>
				<th>Result</th>
				<th>Type</th>
				<th>Action</th>
				<th>Followup at</th>
				<th>Remarks</th>
			</tr>
		</thead>
		<tbody>
			<?php if ($report_today): ?>
				<?php foreach ($report_today as $key => $value): ?>
					<?php $secs = $value->handle_end_timestamp - $value->handle_start_timestamp; ?>
					<?php $bg = ""; ?>
					<?php if ($value->is_resched == 1): ?>
						<?php $bg = "td-yellow"; ?>
					<?php endif ?>
					<tr class="<?php echo $bg; ?>">
						<th><?php echo $value->login_id; ?></th>
						<th><?php echo strtoupper($value->call_type); ?> CALL</th>
						<th><?php echo gmdate("H:i:s", $secs); ?></th>
						<th><?php if($secs != 0 ){echo date($value->handle_start_timestamp);}else{echo "<em>Not yet called</em>";}; ?></th>
						<th><?php if($secs != 0 ){echo date($value->handle_end_timestamp);}else{echo "<em>Not yet called</em>";}; ?></th>
						<th><?php echo strtoupper($value->result); ?></th>
						<th><?php echo strtoupper($value->type); ?></th>
						<th><?php echo strtoupper($value->action); ?> <?php echo strtoupper($value->add_action); ?></th>
						<th><?php
							if(!$value->is_fulfilled){
								echo date('h:i A',$value->no_call_until_date); 
							}else{
								echo "-";
							}
						 ?></th>
						<th><?php echo strtoupper($value->remarks); ?></th>
					</tr>
				<?php endforeach ?>
			<?php endif ?>
		</tbody>
	</table>
	<form action="<?php echo base_url('logout'); ?>">
		<input type="submit" class="btn btn-outline btn-lg btn-success m-xl" value="Log Out">
	</form>
</div>