<div class="modal inmodal fade" id="editEmailModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title"><?php echo ucfirst($this->lang->line('revise_email')) ?> </h4>
            </div>
            <form action="<?php echo base_url('agent/submit_revision'); ?>" method="post" class="form-revision1">
                <div class="modal-body">
                        <div class="form-group">
                            <label for=""><?php echo strtoupper($this->lang->line('new_email')) ?> ( <em>empty field and submit to delete the revision</em> )</label>
                            <input type="text" placeholder="<?php echo $on_queue->player_email; ?>" name="email" class="form-control">
                            <input type="hidden" value="email" name="field">
                        </div>
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-white" data-dismiss="modal"><?php echo strtoupper($this->lang->line('close')) ?></button>
                    <input type="submit" class="btn btn-primary" value="<?php echo strtoupper($this->lang->line('save_changes')) ?>">
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal inmodal fade" id="editPhoneModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title"><?php echo strtoupper($this->lang->line('revise_phone_number')) ?></h4>
            </div>
            <form action="<?php echo base_url('agent/submit_revision'); ?>" method="post" class="form-revision2">
                <div class="modal-body">
                        <div class="form-group">
                            <label for=""><?php echo strtoupper($this->lang->line('new_phone_number')) ?>  ( <em>empty field and submit to delete the revision</em> )</label>
                            <input type="text" placeholder="<?php echo strtoupper($on_queue->player_phone) ?>" name="phone" class="form-control">
                            <input type="hidden" value="phone" name="field">
                        </div>
                </div>
                <div class="modal-footer">
                     <button type="button" class="btn btn-white" data-dismiss="modal"><?php echo strtoupper($this->lang->line('close')) ?></button>
                    <input type="submit" class="btn btn-primary" value="<?php echo strtoupper($this->lang->line('save_changes')) ?>">
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal inmodal fade" id="remarksModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title">Transaction Details</h4>
            </div>
            <div class="modal-body">
                <h3>Transaction Summary</h3>
                <form method="get" class="form-horizontal">
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Transaction ID</label>
                        <div class="col-sm-9"><input type="text" name="trans_id" class="form-control" readonly>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Agent</label>
                        <div class="col-sm-9"><input type="text" name="handler" class="form-control" readonly>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Call Type</label>
                        <div class="col-sm-9"><input type="text" name="call_type" class="form-control" readonly>
                        </div>
                    </div>    
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Result</label>
                        <div class="col-sm-9"><input type="text" name="res" class="form-control" readonly>
                        </div>
                    </div>     
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Type</label>
                        <div class="col-sm-9"><input type="text" name="type" class="form-control" readonly>
                        </div>
                    </div>           
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Action</label>
                        <div class="col-sm-9"><input type="text" name="action" class="form-control" readonly>
                        </div>
                    </div>       
                    <div class="form-group">
                        <label class="col-sm-3 control-label"></label>
                        <div class="col-sm-9"><input type="text" name="add_action" class="form-control" readonly>
                        </div>
                    </div>        
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Start / End Time</label>
                        <div class="col-sm-9"><input type="text" name="startend" class="form-control" readonly>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Call Duration</label>
                        <div class="col-sm-9"><input type="text" name="duration" class="form-control" readonly>
                        </div>
                    </div>
                    <div class="hr-line-dashed"></div>
                    <h3>Promotion</h3>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Promo Applied</label>
                        <div class="col-sm-9"><input type="text" name="promo_title" class="form-control" readonly>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-white" data-dismiss="modal"><?php echo strtoupper($this->lang->line('close')) ?></button>
            </div>
        </div>
    </div>
</div>