<div class="container-fluid margint50 text-center p-h-xl">
	<h1>Good day, <?php echo ucfirst($this->session->userdata('ck_name')); ?> !</h1>
	<h4>Start whenever you're ready.</h4>
	<form action="<?php echo base_url('agent/start_session'); ?>">
		<input type="submit" class="btn btn-outline btn-lg btn-success m-xl" value="Let's get started">
	</form>
</div>