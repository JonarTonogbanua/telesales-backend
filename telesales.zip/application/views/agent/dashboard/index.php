<div class="container-fluid margint50 fadeInRight animated">
	<div class="row margint15" id="forms">
		<div class="col-xs-12">
			<?php  
			$bg = "bg-primary";
			if($on_queue->call_type == "reactivation"){
				$bg = "bg-danger";
			}elseif($on_queue->call_type == "retention"){
				$bg = "bg-success";
			}
			?>
			<div class="<?php echo $bg ?> p-xs b-r-sm"><?php echo strtoupper($on_queue->call_type); ?> CALL&emsp;|&emsp;<?php echo strtoupper($on_queue->product_type); ?></div>
			<br>
		</div>
		<br>
		<div class="col-xs-12 col-md-4">
			<div class="row">
				<div class="col-xs-12 col-md-12">
					<h3 class="sec-title"><?php echo strtoupper($this->lang->line('player_info')) ?></h3>
					<form class="form-horizontal">
						<div class="form-group fonts20"><label class="col-sm-4 control-label"><?php echo strtoupper($this->lang->line('login_id')) ?> :</label>
							<label class="col-sm-8 control-label2"><strong><?php echo $on_queue->login_id ?></strong></label>

							<label class="col-sm-4 control-label"><?php echo $this->lang->line('user_id') ?> :</label>
							<label class="col-sm-8 control-label2"><strong><?php echo $on_queue->user_id ?></strong></label>

							<label class="col-sm-4 control-label"><?php echo $this->lang->line('name') ?> :</label>
							<label class="col-sm-8 control-label2"><strong><?php echo $on_queue->player_name; ?></strong>&emsp;( <?php echo strtoupper($on_queue->pref_language); ?> )</label>

							<label class="col-sm-4 control-label"><?php echo strtoupper($this->lang->line('email')) ?> :</label>
							<label class="col-sm-6 control-label2"><strong><?php echo $on_queue->player_email; ?></strong> &emsp; </label><label for="" class="col-sm-2 control-label2"><a href="javascript:void(0);" data-update="editEmailModal" class="update-links btn btn-primary btn-outline btn-xs"><?php echo ucfirst($this->lang->line('update')) ?></a></label>

							<label class="col-sm-4 control-label"><?php echo strtoupper($this->lang->line('phone')) ?> :</label>
							<label class="col-sm-6 control-label2"><strong><input type="text" class="form-control" readonly id="phoneNumber" value="<?php echo strtoupper($on_queue->player_phone) ?>"></strong></label><label for="" class="col-sm-2 control-label2"> <a href="javascript:void(0);" data-update="editPhoneModal" class="m-t-xs update-links btn btn-primary btn-outline btn-xs"><?php echo ucfirst($this->lang->line('update')) ?></a></label>
							<label class="col-sm-4 control-label"></label>
							<label class="col-sm-6 m-t-xs"><input type="submit" value="Format phone number" class="btn btn-xs" onclick="return phoneNumberParser();" /></label>

							<label class="col-sm-4 control-label"><?php echo strtoupper($this->lang->line('date_join')) ?> :</label>
							<label class="col-sm-8 control-label2"><strong><?php echo strtoupper($on_queue->join_date) ?></strong></label>

							<label class="col-sm-4 control-label"><?php echo strtoupper($this->lang->line('attempt')) ?> :</label>
							<label class="col-sm-8 control-label2"><strong><?php echo $on_queue->daily_attempt + 1 ?></strong></label>
						</div>
						<div id="output-container" style="display:none;" class="panel panel-default">
							<div class="panel-heading text-right">
								<a href="javascript:void(0);" class="" id="close-cont">X</a>
							</div>
							<div class="panel-body">
								<div class="form-group text-center">
									<a href="javascript:void(0);" class="btn btn-lg btn-primary" id="skypecall">Call Skype</a>
								</div>
								<input type="hidden" name="defaultCountry" id="defaultCountry" size="2" value="<?php echo strtoupper($on_queue->player_loc); ?>"/>
								<input type="hidden" name="carrierCode" id="carrierCode" size="2" />
								<textarea id="output" rows="13"class="form-control" readonly ></textarea>
							</div>
						</div>
					</form>
					<hr>
					<h3 class="sec-title"><?php echo strtoupper($this->lang->line('recent_transaction')) ?></h3>
					<table class="dataTables table table-striped table-bordered table-condensed">
						<thead>
							<tr>
								<th>Date</th>
								<th>Agent</th>
								<th>Result</th>
								<th>Type</th>
								<th>Call</th>
								<th>Details</th>
							</tr>
						</thead>
						<tbody>
							<?php 
							if($player_history){ 
								foreach ($player_history as $key => $row) {
									?>
									<tr>
										<td><?php echo date("M d, Y h:i A",$row->handle_start_timestamp); ?></td>
										<td><?php echo strtoupper($row->user_nickname); ?></td>
										<td><?php echo strtoupper($row->result); ?></td>
										<td><?php echo strtoupper($row->type); ?></td>
										<td><?php echo strtoupper($row->call_type); ?> CALL</td>
										<td class="text-center"><button class="view-remark btn btn-xs btn-primary btn-outline" data-trans="<?php echo $row->trans_id; ?>">View</button></td>
									</tr>
									<?php
								}
							}
							?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<div class="col-xs-12 col-md-4 pull-right">
			<div class="alert alert-danger" id="form-err" style="display:none;">

			</div>
			<form action="<?php echo base_url('agent/submit_transaction_result'); ?>" id="result-wizard">
				<h3 class="sec-title"><?php echo strtoupper($this->lang->line('transaction_result')) ?></h3>
				<div id="wizard">
					<h1>Result</h1>
					<div class="step-content">
						<div class="col-sm-12">
							<div class="i-checks"><label class="binder" bind="reached"><input type="radio" value="reached" name="result"> <i></i> Reached </label></div>
							<div class="i-checks"><label class="binder" bind="unreached"><input type="radio" value="unreached" name="result"> <i></i> Unreached </label></div>
							<div class="i-checks"><label class="binder" bind="noaction"><input type="radio" value="invalid" name="result"> <i></i> Invalid Number </label></div>
						</div>
					</div>

					<h1>Type</h1>
					<div class="step-content">
						<div class="col-sm-12">
							<div class="i-checks l2" data-bind="reached"><label class="binder2" bind="full"> <input type="radio" value="full conversation" name="type"> <i></i> Full Conversation </label></div>
							<div class="i-checks l2" data-bind="reached"><label class="binder2" bind="resched"> <input type="radio" value="busy" name="type"> <i></i> Busy </label></div>
							<div class="i-checks l2" data-bind="reached"><label class="binder2" bind="resched"> <input type="radio" value="wrong person" name="type"> <i></i> Wrong Person </label></div>
							<div class="i-checks l2" data-bind="reached"><label class="binder2" bind="resched"> <input type="radio" value="hangup" name="type"> <i></i> Hangup </label></div>
							<div class="i-checks l2" data-bind="reached"><label class="binder2" bind="donotcall"> <input type="radio" value="harrass" name="type"> <i></i> Rude / Harrassing </label></div>
							<div class="i-checks l2" data-bind="unreached"><label class="binder2" bind="resched"> <input type="radio" value="busy tone" name="type"> <i></i> Busy Tone </label></div>
							<div class="i-checks l2" data-bind="unreached"><label class="binder2" bind="resched"> <input type="radio" value="unanswered" name="type"> <i></i> Unanswered </label></div>
							<div class="i-checks l2" data-bind="noaction"><label class="binder2" bind="donotcall"> <input type="radio" value="invalid number" name="type"> <i></i> Invalid Number </label></div>
						</div>
					</div>

					<h1>Action</h1>
					<div class="step-content">
						<div class="l3" data-bind="full">
							<div class="i-checks"><label> <input type="checkbox" value="send email" name="action[]"> <i></i> Send Email </label></div>
							<div class="i-checks"><label> <input type="checkbox" value="message" name="action[]"> <i></i> Message </label></div>
							<div class="form-group">
								<label for=""><?php echo ucfirst($this->lang->line('preferred_language')) ?></label>
								<select name="pref" id="" class="form-control">
									<option <?php if($on_queue->player_loc == "en"){ echo "selected"; } ?> value="en">English</option>
									<option <?php if($on_queue->player_loc == "cn"){ echo "selected"; } ?> value="cn">Chinese</option>
									<option <?php if($on_queue->player_loc == "th"){ echo "selected"; } ?> value="th">Thai</option>
									<option <?php if($on_queue->player_loc == "vn"){ echo "selected"; } ?> value="vn">Vietnamese</option>
								</select>
							</div>
						</div>
						<div class="form-group l3" data-bind="resched">
							<div class="i-checks"><label> <input type="radio" value="dont call" name="action"> <i></i> Dont't call again</label></div>
							<div class="i-checks"><label> <input type="radio" value="call after" name="action"> <i></i> Call After </label></div>
							<div class="row">
								<div class="col-xs-6">
									<input type="number" class="form-control" name="number" placeholder="number">
								</div>
								<div class="col-xs-6">
									<select class="form-control pull-right" name="multiplier">
										<option selected disabled>Select Unit</option>
										<option value="1">second(s)</option>
										<option value="60">minutes(s)</option>
										<option value="3600">hours(s)</option>
										<option value="86400">day(s)</option>
										<option value="604800">week(s)</option>
									</select>
								</div>
							</div>
						</div>
						<div class="form-group l3" data-bind="donotcall">
							<div class="i-checks"><label> <input type="radio" value="dont call" name="action"> <i></i> Dont't call again</label></div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-xs-12">
						<div class="form-group">
							<label for="">Remarks</label>
							<textarea class="form-control" name="remarks" id="" cols="30" rows="5"></textarea>
						</div>
					</div>		
				</div>
				<input type="submit" class="btn btn-lg btn-primary btn-block" value="SUBMIT" >
			</form>
		</div>
		<div class="col-xs-12 col-md-4">
			<h3 class="sec-title"><?php if($campaign_promos) {echo strtoupper($campaign_promos[0]->campaign_title) ?><?php if($campaign_promos[0]->is_default == 1){ echo ' <span class="badge badge-primary">Default Campaign</span>'; }}else{ echo "PROMOTIONS";} ?></h3>
			<div class="tabs-container">
				<ul class="nav nav-tabs">
					<?php 
					if($campaign_promos) {
						foreach ($campaign_promos as $key => $value): ?>
						<?php if ($key == 0): ?>
							<li class="active " style="pointer-events: none;"><a data-toggle="tab" href="#tab-<?php echo $key ?>" aria-expanded="true" class="menus mute-bg"> <?php echo $value->promo_title; ?></a></li>
						<?php else: ?>
							<li style="pointer-events: none;"><a data-toggle="tab" href="#tab-<?php echo $key ?>" aria-expanded="false" class="menus mute-bg"><?php echo $value->promo_title; ?></a></li>
						<?php endif ?>
					<?php endforeach;}else{ echo "<p>No promotion available this time</p>";} ?>
				</ul>
				<div class="tab-content">
					<?php 
					if($campaign_promos) {
						foreach ($campaign_promos as $key => $value): ?>
						<?php if ($key == 0): ?>
							<div id="tab-<?php echo $key ?>" class="tab-pane active">
							<?php else: ?>
								<div id="tab-<?php echo $key ?>" class="tab-pane">
								<?php endif ?>
								<div class="panel-body mute-bg">
									<div class="col-xs-12 fonts15">
										<strong><?php echo ucfirst($this->lang->line('t_n_c')) ?></strong>
										<p><?php echo ucfirst($value->campaign_tnc); ?>
										</p>
										<hr>
										<?php if ($value->custom_tnc): ?>
											<strong>Custom Terms and conditions</strong>
											<p><?php echo ucfirst($value->custom_tnc); ?>
											</p>
											<hr>
										<?php endif ?>
										<strong><?php echo ucfirst($this->lang->line('notes')) ?></strong>
										<p><?php echo ucfirst($value->promo_notes); ?>
										</p>
										<hr>
										<strong><?php echo ucfirst($this->lang->line('promotion_url')) ?></strong>
										<p><?php echo ucfirst($value->promo_link); ?>
										</p>
										<hr>
									</div>
									<div class="col-xs-12">
										<form action="<?php echo base_url('agent/submit_deal'); ?>" class="form-interest form-inline" data-tab="tab-<?php echo $key+1 ?>">
											<div class="form-group text-right">
												<input type="hidden" value="<?php echo $value->promo_id; ?>" name="promoid">
												<label> 
													<input type="radio" value="deal" class="rad-interest" id="optionsRadios1" name="interest"> Deal<br/>
												</label>
												<label> 
													<input type="radio" value="not interested" class="rad-interest" id="optionsRadios2" name="interest"> <?php echo ucfirst($this->lang->line('not_interested')) ?><br/>
												</label>
											</div>
											<div class="row">
												<div class="col-xs-6">
													<?php if (!$key == 0): ?>
														<div class="text-left m-t">
															<button type="button" class="btn btn-default btn-outline btn-tab-page"  data-tab="tab-<?php echo $key-1 ?>">Previous Promo</button>
														</div>
													<?php endif; ?>
												</div>
												<div class="col-xs-6">
													<div class="text-right m-t">
														<?php if (count($campaign_promos) == $key+1): ?>
															<?php $text = "Finish"; ?>
														<?php else: ?>
															<?php $text = "Next"; ?>
															<button type="button" class="btn btn-primary btn-outline btn-tab-page"  data-tab="tab-<?php echo $key+1 ?>">Next Promo</button>
														<?php endif; ?>
														<input type="submit" class="btn btn-primary submit-promo " value="<?php echo "Submit"; ?>" >
													</div>
												</div>
											</div>
										</form>
									</div>
								</div>
							</div>
						<?php endforeach;} ?>
					</div>
				</div>
			</div>
		</div>
		<div class="row" id="timer-container">
			<div class="col-xs-12 timer-container" id="nextcall-container">
				<div>
					<h1>Next Call in :</h1>
				</div>
				<div class="pie degree">
					<span class="blocks"></span>
					<span id="time">0</span>
				</div>
				<div>
					<button class="btn-lg btn btn-primary btn-outline" id="takebreak">PAUSE SESSION</button><br/>
					<a class="btn-lg btn btn-primary margint15" href="<?php echo base_url('agent'); ?>"> &nbsp;&nbsp;RESUME&nbsp;NOW&nbsp;</a>
				</div>
			</div>
			<form action="<?php echo base_url('agent/end_break'); ?>" id="form-end-break">
				<div  id="breaktime-container">
					<div class="col-xs-12 timer-container">
						<div class="col-xs-12 break-container">
							<h1>SESSION PAUSED</h1>
							<div class="ibox">
								<div class="ibox-content">
									<h1 id="timer">--:--:--</h1>
								</div>
							</div>
							<hr>
							<div class="col-sm-2" id="breakdeed">
								<div class="i-checks"><label> <input type="radio" value="CR BREAK" name="pausetype"> <i></i> CR </label></div>
								<div class="i-checks"><label> <input type="radio" value="MEAL BREAK" name="pausetype"> <i></i> MEAL BREAK </label></div>
								<div class="i-checks"><label> <input type="radio" value="MEETING" name="pausetype"> <i></i> MEETING </label></div>
							</div>
							<hr>
							<input type="submit" class="btn-lg btn btn-primary btn-outline" id="resumecall" value="RESUME SESSION">

						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
</div>
