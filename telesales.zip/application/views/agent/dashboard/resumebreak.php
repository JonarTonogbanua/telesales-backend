<div class="container-fluid margint50 fadeInRight animated">
	<div class="row margint15" id="forms">
		<div class="col-xs-12">
		<form action="<?php echo base_url('agent/end_break'); ?>" id="form-end-break">
		<div  id="breaktime-container">
			<div class="col-xs-12 timer-container">
				<div class="col-xs-12 break-container">
					<h1>SESSION PAUSED</h1>
					<div class="ibox">
						<div class="ibox-content">
							<h1 id="timer">--:--:--</h1>
						</div>
					</div>
					<hr>
					<div class="col-sm-2" id="breakdeed">
						<div class="i-checks"><label> <input type="radio" value="CR BREAK" name="pausetype"> <i></i> CR </label></div>
						<div class="i-checks"><label> <input type="radio" value="MEAL BREAK" name="pausetype"> <i></i> MEAL BREAK </label></div>
						<div class="i-checks"><label> <input type="radio" value="MEETING" name="pausetype"> <i></i> MEETING </label></div>
					</div>
					<hr>
					<input type="submit" class="btn-lg btn btn-primary btn-outline" id="resumecall" value="RESUME SESSION">
					
				</div>
			</div>
		</div>
		</form>
		</div>
	</div>
</div>