    <script src="<?php echo base_url('assets/js/jquery-3.1.1.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/metisMenu/jquery.metisMenu.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/slimscroll/jquery.slimscroll.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/sweetalert/sweetalert.min.js'); ?>"></script>
    <!-- Custom and plugin javascript -->
    <script src="<?php echo base_url('assets/js/inspinia.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/pace/pace.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/fullcalendar/moment.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/daterangepicker/daterangepicker.js'); ?>"></script>
    <!-- d3 and c3 charts -->
    <script src="<?php echo base_url('assets/js/plugins/d3/d3.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/c3/c3.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/peity/jquery.peity.min.js'); ?>"></script>
    <?php  
    $chart = array('spline', 'line', 'bar', 'pie', 'donut', 'area' , 'steps');
    $active = "spline";
    if (in_array($this->input->get('chart'), $chart)) {
        $active = strtolower($this->input->get('chart'));
    }
    ?>

    <script>
        var init = 0;
        $('[data-toggle="tooltip"]').tooltip(); 
        changeCountry = function(){
            $('input').prop('disabled', true);
            $('select').prop('disabled', true);
            var country = $('select[name=country] option:selected').val();
            data = {
                country : country,
            };
            $.ajax({
                type: 'POST',
                url: BASE_URL + "telesales/get_agent_by_country",
                data : data,
                dataType : 'JSON',
            }).done(function(e){
                $('input').prop('disabled', false);
                $('select').prop('disabled', false);
                if(e.result === true){
                    $('select[name=agent]').empty();
                    $('select[name=agent]').append("<option value=''>All</option>");
                    var selOpts;
                    agents = e.agents;
                    $.each(agents, function(k, v){
                        var id = agents[k].user_id;
                        var val = agents[k].user_nickname;
                        selOpts += "<option value='"+id+"'>"+val.toUpperCase()+"</option>";
                    });
                    $('select[name=agent]').append(selOpts);
                    if(init == 0){
                        $('select[name=agent]').val('<?php echo $this->input->get('agent'); ?>');
                        init = 1;
                    }
                }else{
                    $('select[name=agent]').empty();
                    $('select[name=agent]').append("<option value=''>All</option>");
                }
            }).fail(function(){
                swal('Fetch Error', 'Some required parameters are missing', 'error');
                $('input').prop('disabled', false);
                $('select').prop('disabled', false);
            });
        }
        <?php if ($this->input->get('country')): ?>
        changeCountry();
    <?php endif ?>
    $('select[name=country]').on('change', function(){
        changeCountry();
    });
    $('input[name="daterange"]').daterangepicker();
    $('[data-toggle="tooltip"]').tooltip();
    $("span.line").peity("bar",{
      fill: function(_, i, all) {
        var g = parseInt((i / all.length) * 255)
        return "rgb(255, " + g + ", 0)"
    }
});
    $("span.pie").peity("pie", {
        fill: ['#1ab394', '#d7d7d7', '#ffffff']
    });
    var month = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    <?php if ($lead_graph){ ?>
        var mainchart = c3.generate({
            bindto: '#slineChart',
            data: {
                x: 'x',
                columns: [
                ['x',<?php foreach ($lead_graph as $row): ?><?php echo "'".date('Y-m-d', strtotime($row->date_added))."',"; ?><?php endforeach ?>],
                ['Call Leads',<?php foreach ($lead_graph as $row): ?><?php echo "".$row->count.","; ?><?php endforeach ?>],
                ['Call Attempts',<?php foreach ($lead_graph as $row): ?><?php echo $row->fulfilled.",";?><?php endforeach ?>],
                ['reached',<?php foreach ($lead_graph as $row): ?><?php echo $row->reached.",";?><?php endforeach ?>],
                ['unreached',<?php foreach ($lead_graph as $row): ?><?php echo $row->unreached.",";?><?php endforeach ?>],
                ['invalid',<?php foreach ($lead_graph as $row): ?><?php echo $row->invalid.",";?><?php endforeach ?>],
                ['Call Done',<?php foreach ($lead_graph as $key => $row): ?><?php echo ($row->rfull + floor($lead_graph[$key]->inotfull / 3)).",";?><?php endforeach ?>],
                ],
                type: '<?php echo $active; ?>',
                types: {
                    reached: 'bar',
                    unreached: 'bar',
                    invalid: 'bar',
                },
                groups: [
                ['reached','unreached', 'invalid']
                ]
            },
            bar: {
                    width: {
                        ratio: 0.5
                    }
                },
            axis : {
                x : {
                    type : 'timeseries',
                    tick: {
                        <?php if($this->input->get('showby') == "hour"){ ?>
                            format: function (x) { return x.getHours(); }
                            <?php }elseif($this->input->get('showby') == "day"){ ?>
                                format: function (x) { return x.getDate() + "  " + month[x.getMonth()]; }
                                <?php }elseif($this->input->get('showby') == "month"){ ?> 
                                    format: function (x) { return month[x.getMonth()]; }
                                    <?php }elseif($this->input->get('showby') == "year"){ ?> 
                                        format: function (x) { return x.getFullYear();}
                                        <?php }else{ ?>    
                                            format: function (x) { return x.getDate() + "  " + month[x.getMonth()]; }
                                            <?php } ?>
                                        }
                                    }
                                }
                            });
        <?php } ?>
        <?php if ($break_graph || $call_graph){ ?>
            var mainchart = c3.generate({
                bindto: '#tlineChart',
                data: {
                    x: 'x',
                    columns: [
                    ['x',<?php if($call_graph):foreach ($call_graph as $row): ?><?php echo "'".date('Y-m-d', strtotime($row->timestamp))."',"; ?><?php endforeach;endif; ?>],
                    ['Total Break (min)',<?php if($break_graph):foreach ($break_graph as $row): ?><?php echo "".round($row->dur,2).","; ?><?php endforeach;endif; ?>],
                    ['Total Call (min)',<?php if($break_graph):foreach($call_graph as $row): ?><?php echo "".round($row->dur,2).","; ?><?php endforeach;endif; ?>],
                    ],
                    type: '<?php echo $active; ?>',
                    types: {
                        reached: 'bar',
                        unreached: 'bar',
                        invalid: 'bar',
                    },
                },
                axis : {
                    x : {
                        type : 'timeseries',
                        tick: {
                            <?php if($this->input->get('showby') == "hour"){ ?>
                                format: function (x) { return x.getHours(); }
                                <?php }elseif($this->input->get('showby') == "day"){ ?>
                                    format: function (x) { return x.getDate() + "  " + month[x.getMonth()]; }
                                    <?php }elseif($this->input->get('showby') == "month"){ ?> 
                                        format: function (x) { return month[x.getMonth()]; }
                                        <?php }elseif($this->input->get('showby') == "year"){ ?> 
                                            format: function (x) { return x.getFullYear();}
                                            <?php }else{ ?>    
                                                format: function (x) { return x.getDate() + "  " + month[x.getMonth()]; }
                                                <?php } ?>
                                            }
                                        }
                                    }
                                });
            <?php } ?>
            <?php if ($cr_bdown && $meal_bdown && $meeting_bdown){ ?>
                var mainchart = c3.generate({
                    bindto: '#ulineChart',
                    data: {
                        x: 'x',
                        columns: [
                        ['x',<?php if($call_graph):foreach ($call_graph as $row): ?><?php echo "'".date('Y-m-d', strtotime($row->timestamp))."',"; ?><?php endforeach ?>],
                        ['CR BREAK',<?php if($cr_bdown):foreach ($cr_bdown as $row): ?><?php echo "".round($row->dur,2).","; ?><?php endforeach;endif; ?>],
                        ['MEAL BREAK',<?php foreach ($meal_bdown as $row): ?><?php echo "".round($row->dur,2).","; ?><?php endforeach;endif; ?>],
                        ['MEETING BREAK',<?php if($meeting_bdown):foreach ($meeting_bdown as $row): ?><?php echo "".round($row->dur,2).","; ?><?php endforeach;endif; ?>],
                        ],
                        type: 'pie'
                    },
                    pie: {
                        label: {
                          format: function(value, ratio, id) {
        //return value + " min ("+Math.round(ratio * 100)+"%)";
        return value + " min";
    }
}
},
axis : {
    x : {
        type : 'timeseries',
        tick: {
            <?php if($this->input->get('showby') == "hour"){ ?>
                format: function (x) { return x.getHours(); }
                <?php }elseif($this->input->get('showby') == "day"){ ?>
                    format: function (x) { return x.getDate() + "  " + month[x.getMonth()]; }
                    <?php }elseif($this->input->get('showby') == "month"){ ?> 
                        format: function (x) { return month[x.getMonth()]; }
                        <?php }elseif($this->input->get('showby') == "year"){ ?> 
                            format: function (x) { return x.getFullYear();}
                            <?php }else{ ?>    
                                format: function (x) { return x.getDate() + "  " + month[x.getMonth()]; }
                                <?php } ?>
                            }
                        }
                    }
                });
                <?php } ?>
            </script>