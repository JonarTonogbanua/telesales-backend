    <script src="<?php echo base_url('assets/js/jquery-3.1.1.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/metisMenu/jquery.metisMenu.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/slimscroll/jquery.slimscroll.min.js'); ?>"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo base_url('assets/js/inspinia.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/pace/pace.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/fullcalendar/moment.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/daterangepicker/daterangepicker.js'); ?>"></script>
    <!-- d3 and c3 charts -->
    <script src="<?php echo base_url('assets/js/plugins/d3/d3.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/c3/c3.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/peity/jquery.peity.min.js'); ?>"></script>
    <script>
        $('input[name="daterange"]').daterangepicker();
        c3.generate({
            bindto: '#slineChart',
            data:{
                columns: [
                ['Reached Calls', 0, 120, 200, 100, 400, 150, 250, 100],
                ['Unreached Calls', 0, 20, 22, 30, 25, 50, 43, 26],
                ],
                colors:{
                    data1: '#1ab394',
                    data2: '#142efa',
                },
                type: 'spline'
            }
        });
    </script>