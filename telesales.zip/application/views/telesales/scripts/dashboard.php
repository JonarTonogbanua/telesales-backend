    <script src="<?php echo base_url('assets/js/jquery-3.1.1.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/metisMenu/jquery.metisMenu.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/slimscroll/jquery.slimscroll.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/timeago.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/js/plugins/sweetalert/sweetalert.min.js'); ?>"></script>
    <!-- Custom and plugin javascript -->
    <script src="<?php echo base_url('assets/js/inspinia.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/pace/pace.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/fullcalendar/moment.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/daterangepicker/daterangepicker.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/toastr/toastr.min.js'); ?>"></script>
    <!-- d3 and c3 charts -->
    <script src="<?php echo base_url('assets/js/plugins/d3/d3.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/c3/c3.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/peity/jquery.peity.min.js'); ?>"></script>
    <?php  
    $chart = array('spline', 'line', 'bar', 'pie', 'donut', 'area' , 'step');
    $active = "spline";
    if (in_array($this->input->get('chart'), $chart)) {
        $active = strtolower($this->input->get('chart'));
    }
    ?>

    <script>
        toastr.options = {
          "closeButton": true,
          "debug": false,
          "progressBar": true,
          "preventDuplicates": false,
          "positionClass": "toast-bottom-right",
          "onclick": null,
          "showDuration": "400",
          "hideDuration": "1000",
          "timeOut": "7000",
          "extendedTimeOut": "1000",
          "showEasing": "swing",
          "hideEasing": "linear",
          "showMethod": "fadeIn",
          "hideMethod": "fadeOut"
      }

      var init = 0;
      $('[data-toggle="tooltip"]').tooltip(); 
      jQuery("span.pubdate").timeago();
      liveProgress = function(){
        $.ajax({
            type: 'POST',
            url: BASE_URL + "telesales/get_live_progress",
            dataType : 'JSON',
        }).done(function(progress){
            $.each(progress, function(k, v){
                var progressClass = "progress-bar-danger";
                $('.leads-'+v.country).text(v.calls+" / "+v.leads);
                $('.indicator-'+v.country).text(Math.round((parseFloat(v.calls) / parseFloat(v.leads)) * 100) + "%");
                $('.progress-'+v.country).css('width', Math.round((parseFloat(v.calls) / parseFloat(v.leads)) * 100) + "%");
                var percentTemp = Math.round((parseFloat(v.calls) / parseFloat(v.leads)) * 100);
                
                if(percentTemp == 100){
                    progressClass = "progress-bar-success";
                }else if(percentTemp >= 70){
                    progressClass = "progress-bar-info";
                    
                }else if(percentTemp >= 21){
                    progressClass = "progress-bar-warning";
                }else if(percentTemp >=  0){
                    progressClass = "progress-bar-danger";
                }
                $('.progress-'+v.country).removeClass("progress-bar-danger");
                $('.progress-'+v.country).removeClass("progress-bar-warning");
                $('.progress-'+v.country).removeClass("progress-bar-info");
                $('.progress-'+v.country).removeClass("progress-bar-success");
                $('.progress-'+v.country).addClass(progressClass);
            });
        }).fail(function(){
            toastr.error('Please check your internet connection!','Progress Update Failed');
        }); 
    }
    liveActivity = function(){
        var html ="";
        $.ajax({
            type: 'POST',
            url: BASE_URL + "telesales/get_live_activity",
            dataType : 'JSON',
        }).done(function(progress){
            $.each(progress, function(k, v){
                var img;
                var message;
                if(v.activity_name == "Logged In"){
                    img = "login";
                    message = v.user_nickname +" logged in";
                }else if(v.activity_name == "Logged Out"){
                    img = "logout";
                    message = v.user_nickname +" logged out";
                }else if(v.activity_name == "On call"){
                    img = "call";
                    message = v.user_nickname +" is on call";
                }else if(v.activity_name == "On Break"){
                    img = "break";
                    message = v.user_nickname +" took a break";
                }else if(v.activity_name == "Waiting Call"){
                    img = "wait";
                    message = v.user_nickname +" is waiting for call";
                }else{
                    img = "-";
                    message = "-";
                }
                html += '<div class="feed-element">';
                html += '<a href="javascript:void(0);" class="pull-left">';
                html += '<img alt="image" class="img-circle" src="'+BASE_URL+'assets/img/status/'+img+'.png">';
                html += '</a>';
                html += '<div class="media-body">';
                html += message;
                html += '<br>';
                html += '<small class="text-muted"><span class="pubdate" title="'+v.timestamp+'">'+v.timestamp+'</span></small>';
                html += '</div>';
                html += '</div>';
            });
            $("#feed").html("");
            $("#feed").html(html);
            jQuery("span.pubdate").timeago();
        }).fail(function(){
           $("#feed").html('<div class="center-block text-center m-t"><div class="sk-spinner sk-spinner-wave"><div class="sk-rect1"></div><div class="sk-rect2"></div><div class="sk-rect3"></div><div class="sk-rect4"></div><div class="sk-rect5"></div></div><h5>Reconnecting . . .</h5></div>');
       }); 
    }
    setTimeout(function(){
        liveActivity();
        liveProgress();
    },2000);
    setInterval(function(){
        liveProgress();
        setTimeout(function(){
            liveActivity();
        },2000);
    },4000);
    changeCountry = function(){
        $('input').prop('disabled', true);
        $('select').prop('disabled', true);
        var country = $('select[name=country] option:selected').val();
        data = {
            country : country,
        };
        $.ajax({
            type: 'POST',
            url: BASE_URL + "telesales/get_agent_by_country",
            data : data,
            dataType : 'JSON',
        }).done(function(e){
            $('input').prop('disabled', false);
            $('select').prop('disabled', false);
            if(e.result === true){
                $('select[name=agent]').empty();
                $('select[name=agent]').append("<option value=''>All</option>");
                var selOpts;
                agents = e.agents;
                $.each(agents, function(k, v){
                    var id = agents[k].user_id;
                    var val = agents[k].user_nickname;
                    selOpts += "<option value='"+id+"'>"+val.toUpperCase()+"</option>";
                });
                $('select[name=agent]').append(selOpts);
                if(init == 0){
                    $('select[name=agent]').val('<?php echo $this->input->get('agent'); ?>');
                    init = 1;
                }
            }else{
                $('select[name=agent]').empty();
                $('select[name=agent]').append("<option value=''>All</option>");
            }
        }).fail(function(){
            swal('Fetch Error', 'Some required parameters are missing', 'error');
            $('input').prop('disabled', false);
            $('select').prop('disabled', false);
        });
    }
    <?php if ($this->input->get('country')): ?>
    changeCountry();
<?php endif ?>
$('select[name=country]').on('change', function(){
    changeCountry();
});
$('input[name="daterange"]').daterangepicker();
$('[data-toggle="tooltip"]').tooltip();
$("span.line").peity("bar",{
  fill: function(_, i, all) {
    var g = parseInt((i / all.length) * 255)
    return "rgb(255, " + g + ", 0)"
}
});
$("span.pie").peity("pie", {
    fill: ['#1ab394', '#d7d7d7', '#ffffff']
})
var month = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
<?php if ($lead_graph){ ?>
    var mainchart = c3.generate({
        bindto: '#slineChart',
        data: {
            x: 'x',
            columns: [
            ['x',<?php foreach ($lead_graph as $row): ?><?php echo "'".date('Y-m-d', strtotime($row->date_added))."',"; ?><?php endforeach ?>],
            ['Call Leads',<?php foreach ($lead_graph as $row): ?><?php echo "".$row->count.","; ?><?php endforeach ?>],
            ['Call Done',<?php foreach ($lead_graph as $key => $row): ?><?php echo ($row->rfull + floor($lead_graph[$key]->inotfull / 3)).",";?><?php endforeach ?>],
            ['Call Attempts',<?php foreach ($lead_graph as $row): ?><?php echo $row->fulfilled.",";?><?php endforeach ?>],
            ['reached',<?php foreach ($lead_graph as $row): ?><?php echo $row->reached.",";?><?php endforeach ?>],
            ['unreached',<?php foreach ($lead_graph as $row): ?><?php echo $row->unreached.",";?><?php endforeach ?>],
            ['invalid',<?php foreach ($lead_graph as $row): ?><?php echo $row->invalid.",";?><?php endforeach ?>],
            
            ],
            type: 'step',
            types: {
                'Call Attempts' : 'bar',
                'Call Done' : 'area-step',
                reached: 'bar',
                unreached: 'bar',
                invalid: 'bar',
            },
        },
        axis : {
            x : {
                type : 'timeseries',
                tick: {
                    <?php if($this->input->get('showby') == "hour"){ ?>
                        format: function (x) { return x.getHours(); }
                        <?php }elseif($this->input->get('showby') == "day"){ ?>
                            format: function (x) { return x.getDate() + "  " + month[x.getMonth()]; }
                            <?php }elseif($this->input->get('showby') == "month"){ ?> 
                                format: function (x) { return month[x.getMonth()]; }
                                <?php }elseif($this->input->get('showby') == "year"){ ?> 
                                    format: function (x) { return x.getFullYear();}
                                    <?php }else{ ?>    
                                        format: function (x) { return x.getDate() + "  " + month[x.getMonth()]; }
                                        <?php } ?>
                                    }
                                }
                            }
                        });
    c3.generate({
        bindto: '#stocked',
        data:{
            columns: [
            ['Campaign 1', 0,30,200,100,200,150,250,100],
            ['Campaign 2',0 ,50,20,10,40,15,25,120],
            ['Campaign 3', 0,60,10,20,30,20,35,160],
            ],
            colors:{
                data1: '#1ab394',
                data2: '#BABABA',
                data3: '#BABABA',
            },
            type: 'bar',
            groups: [
            ['data1', 'data2']
            ]
        }
    });
    c3.generate({
        bindto: '#pie',
        data:{
            columns: [
            ['On Break', 300],
            ['On Call', 1500]
            ],
            colors:{
                data1: '#1ab394',
                data2: '#BABABA'
            },
            type : 'pie'
        }
    });
    <?php } ?>
</script>