<script src="<?php echo base_url('assets/js/jquery-3.1.1.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/metisMenu/jquery.metisMenu.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/slimscroll/jquery.slimscroll.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/sweetalert/sweetalert.min.js'); ?>"></script>

<!-- Custom and plugin javascript -->
<script src="<?php echo base_url('assets/js/inspinia.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/pace/pace.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/jasny/jasny-bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/datatables.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/dataTables.select.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dropzone/dropzone.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/codemirror/codemirror.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/codemirror/mode/xml/xml.js'); ?>"></script>
<script>
    $(document).ready(function(){
        let table = $('.dataTables').DataTable( {
            columnDefs: [ {
                orderable: false,
                className: 'select-checkbox',
                targets:   0
            } ],
            select: {
                style:    'os',
                selector: 'td:first-child'
            },
            order: [[ 3, 'asc' ]]

        } );
        table.on("click", "th.select-checkbox", function() {
            if ($("th.select-checkbox").hasClass("selected")) {
                table.rows().deselect();
                $("th.select-checkbox").removeClass("selected");
            } else {
                table.rows().select();
                $("th.select-checkbox").addClass("selected");
            }
        }).on("select deselect", function() {
            ("Some selection or deselection going on")
            if (table.rows({
                selected: true
            }).count() !== table.rows().count()) {
                $("th.select-checkbox").removeClass("selected");
            } else {
                $("th.select-checkbox").addClass("selected");
            }
        });
        $('select[name=calltype]').on('change', function(){
            var calltype= $(this).val();
            if(calltype == "retention"){
                $("#select-campaign").attr('disabled', false);
                $("#select-campaign").fadeIn(300);
            }else{
                $("#select-campaign").attr('disabled', true);
                $("#select-campaign").fadeOut(300);
            }
        });
        $("#wselected").on('click', function(){
            var tids = new Array();
            $('.dataTables tbody .selected').each(function(){
              var tempid = $(this).attr('transaction-id');
              tids.push(tempid);
          });
            console.log(tids);
            if(tids.length == 0){
                return false;
            }
            swal({
                title: "Are you sure",
                text: "Drop this item(s) from call queue? On call items will not be dropped.",
                type: "warning",
                showCancelButton: true,
                closeOnConfirm: false,
                showLoaderOnConfirm: true,
            },
            function(){
                data = {
                    tids : tids,
                };
                $.ajax({
                    type: 'POST',
                    url: BASE_URL + "telesales/drop_call_item",
                    data : data,
                    dataType : 'JSON',
                }).done(function(e){
                    $('.dataTables .selected').each(function(){
                      table.row($(this)).remove().draw();
                  });
                    swal('Success!',"Item(s) successfully dropped", "success");
                }).fail(function(){
                    swal('Runtime Error', 'Some required parameters are missing', 'error');
                });
            });
        });
        
        var errorCount = 0;
        $('#action-buttons').on('click', '.btn-action', function(){
            var action = $(this).attr('data-action');
            swal({
              title: "Are you sure?",
              text: action +" all data",
              type: "info",
              showCancelButton: true,
              closeOnConfirm: false,
              showLoaderOnConfirm: true,
          },
          function(){
              data = {
                action : action,
            }
            $.ajax({
                type: 'POST',
                url: BASE_URL + "telesales/action_to_temp",
                data : data,
                dataType : 'JSON',
            }).done(function(e){
                swal(e.title, e.message, e.type);
                if(e.result == "true"){
                    setTimeout(function(){
                        location.reload();
                    },1500);
                }
            }).fail(function(){
                if(errorCount != 3){
                 swal('Oops !', 'Something went wrong, please try again', 'info');
                 errorCount++; 
             }else{
                swal('Fatal error', 'Please contact the developer to resolve issue.', 'error');
            }
        });
        });
        });
    });
</script>