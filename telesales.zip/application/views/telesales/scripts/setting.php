<script src="<?php echo base_url('assets/js/jquery-3.1.1.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/metisMenu/jquery.metisMenu.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/slimscroll/jquery.slimscroll.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/sweetalert/sweetalert.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/jquery-ui/jquery-ui.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/nestable/jquery.nestable.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/sweetalert/sweetalert.min.js'); ?>"></script>

<!-- Custom and plugin javascript -->
<script src="<?php echo base_url('assets/js/plugins/pace/pace.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/touchpunch/jquery.ui.touch-punch.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/inspinia.js'); ?>"></script>

<script>
	$(document).ready(function(){
		WinMove();
		var updateOutput = function (e) {
			var list = e.length ? e : $(e.target),
			output = list.data('output');
			$(".dd-list li").each(function(n) {
				var dataid = $(this).attr('data-id');
				data = {
					'id' : dataid,
					'position' : n + 1,
				}
				$.ajax({
					type: 'POST',
					url: BASE_URL + "telesales/set_call_priority",
					data: data,
				}).done(function(e){
					swal('Action success!', 'Changes has been saved', 'success');
				}).fail(function(){
					alert('FATAL ERROR : Contact the developer to resolve issue.');
				});
			});
		};

		$('#nestable').nestable({
			group: 1
		}).on('change', updateOutput);

		$("#frm-grace-update").on('submit', function(event){
			event.preventDefault();
			var formData = $("#frm-grace-update").serialize();
			$("input").prop('disabled', true);
			$.ajax({
				type: 'POST',
				url: $("#frm-grace-update").attr('action'),
				data: formData,
				dataType : 'JSON',
			}).done(function(e){
				var response = e.result;
				if(response == "true"){
					swal('Action success!', e.message, 'success');
				}else{
					swal('Action Failed!', e.message, 'error');
				}
				$("input").prop('disabled', false);
			}).fail(function(){
				alert('FATAL ERROR : Contact the developer to resolve issue.');
			});
		});
	});
</script>