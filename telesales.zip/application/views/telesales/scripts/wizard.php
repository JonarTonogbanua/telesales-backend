<script src="<?php echo base_url('assets/js/jquery-3.1.1.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/metisMenu/jquery.metisMenu.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/slimscroll/jquery.slimscroll.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/sweetalert/sweetalert.min.js'); ?>"></script>

<!-- Custom and plugin javascript -->
<script src="<?php echo base_url('assets/js/inspinia.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/pace/pace.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/jasny/jasny-bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/datatables.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dropzone/dropzone.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/codemirror/codemirror.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/codemirror/mode/xml/xml.js'); ?>"></script>
<script>
    $(document).ready(function(){
        $('.dataTables').DataTable({
            pageLength: 25,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
            ],
            "order": [[ 0, "desc" ]],
        });
        $('select[name=calltype]').on('change', function(){
            var calltype= $(this).val();
            if(calltype == "retention"){
                $("#select-campaign").attr('disabled', false);
                $("#select-campaign").fadeIn(300);
            }else{
                $("#select-campaign").attr('disabled', true);
                $("#select-campaign").fadeOut(300);
            }
        });
        var errorCount = 0;
        $('#action-buttons').on('click', '.btn-action', function(){
            var action = $(this).attr('data-action');
            swal({
              title: "Are you sure?",
              text: action +" all data",
              type: "info",
              showCancelButton: true,
              closeOnConfirm: false,
              showLoaderOnConfirm: true,
          },
          function(){
              data = {
                action : action,
            }
            $.ajax({
                type: 'POST',
                url: BASE_URL + "telesales/action_to_temp",
                data : data,
                dataType : 'JSON',
            }).done(function(e){
                swal(e.title, e.message, e.type);
                if(e.result == "true"){
                    setTimeout(function(){
                        location.reload();
                    },1500);
                }
            }).fail(function(){
                if(errorCount != 3){
                   swal('Oops !', 'Something went wrong, please try again', 'info');
                   errorCount++; 
                }else{
                    swal('Fatal error', 'Please contact the developer to resolve issue.', 'error');
                }
                
            });
        });
        });

        $('select[name=country]').on('change', function(){
            country_code = $(this).val();
            $('.sk-spinner').show();
            $('select').attr('disabled', true);
            data = {
                'country_code' : country_code,
            };
            $.ajax({
                type: 'POST',
                url: BASE_URL + "telesales/get_country_campaign",
                data: data,
                dataType : 'JSON',
            }).done(function(e){
                $('#select-campaign option[value!=""]').remove();
                $('#select-campaign').
                append('<option selected disabled>Select Campaign</option>');
                if(e){
                    $.each(e, function(k, v) {
                        $('#select-campaign').
                        append('<option value="'+v['campaign_id']+'">' +v['campaign_title']+'</option>');
                    });
                }
            }).fail(function(){
                swal('Fatal error', 'Failed to retrieve campaign list, please try again', 'error');
            });
            setTimeout(function(){
                $('.sk-spinner').hide();
                $('select').attr('disabled', false);
            }, 300);
        });
    });
</script>