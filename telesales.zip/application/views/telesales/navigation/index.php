<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="side-menu">
                    <li class="nav-header">
                        <div class="dropdown profile-element"> <span>
                            <img alt="image" class="img-circle" src="<?php echo base_url('assets/img/default-user.png'); ?>" />
                             </span>
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold">Telesales</strong>
                        </div>
                        <div class="logo-element">
                            TLS
                        </div>
                    </li>
                    <li class="<?php if($this->uri->segment(2) == "dashboard" || !$this->uri->segment(2)){ echo "active";} ?>">
                        <a href="<?php echo base_url('telesales/dashboard'); ?>"><i class="fa fa-th-large"></i><span class="nav-label">Dashboard</span></a>
                    </li>
                    <li class="<?php if($this->uri->segment(2) == "wizard"){ echo "active";} ?>">
                        <a href="<?php echo base_url('telesales/wizard'); ?>"><i class="fa fa-magic"></i> <span class="nav-label">Data Wizard </span></a>
                    </li>
                    <li class="<?php if($this->uri->segment(2) == "calls"){ echo "active";} ?>">
                        <a href="<?php echo base_url('telesales/calls'); ?>"><i class="fa fa-phone"></i> <span class="nav-label">Call List</span></a>
                    </li>
                    <li class="<?php if($this->uri->segment(2) == "accounts"){ echo "active";} ?>">
                        <a href="<?php echo base_url('telesales/accounts'); ?>"><i class="fa fa-users"></i> <span class="nav-label">Telesales Agents</span></a>
                    </li>
                    <li class="<?php if($this->uri->segment(3) == "revisions" || $this->uri->segment(3) == "list" || $this->uri->segment(2) == "players"){ echo "active";} ?>">
                        <a href="#"><i class="fa fa-diamond"></i> <span class="nav-label">Players</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li class="<?php if($this->uri->segment(3) == "list"){ echo "active";} ?>"><a href="<?php echo base_url('telesales/players/list'); ?>">List</a></li>
                            <li class="<?php if($this->uri->segment(3) == "revisions"){ echo "active";} ?>"><a href="<?php echo base_url('telesales/players/revisions/?show=0'); ?>">Revisions</a></li>
                        </ul>
                    </li>
                    <li class="<?php if($this->uri->segment(3) == "campaigns" || $this->uri->segment(3) == "promotions"){ echo "active";} ?>">
                        <a href="#"><i class="fa fa-bullhorn"></i> <span class="nav-label">Campaign Mgmt.</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li class="<?php if($this->uri->segment(3) == "campaigns"){ echo "active";} ?>"><a href="<?php echo base_url('telesales/campaign-management/campaigns'); ?>">Campaigns</a></li>
                            <li class="<?php if($this->uri->segment(3) == "promotions"){ echo "active";} ?>"><a href="<?php echo base_url('telesales/campaign-management/promotions'); ?>">Promotions</a></li>
                        </ul>
                    </li>
                    <li class="<?php if($this->uri->segment(3) == "calls" || $this->uri->segment(3) == "agents"){ echo "active";} ?>">
                        <a href="#"><i class="fa fa-bar-chart"></i> <span class="nav-label">Statistics</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li class="<?php if($this->uri->segment(3) == "calls"){ echo "active";} ?>"><a href="<?php echo base_url('telesales/reports/calls'); ?>">Telesales</a></li>
                            <!-- <li class="<?php if($this->uri->segment(3) == "campaign-promo"){ echo "active";} ?>"><a href="<?php echo base_url('telesales/reports/promotions'); ?>">Campaign Promo</a></li> -->
                        </ul>
                    </li>
                    <li class="<?php if($this->uri->segment(2) == "archives"){ echo "active";} ?>">
                        <a href="<?php echo base_url('telesales/archives'); ?>"><i class="fa fa-archive"></i> <span class="nav-label">Transaction Archive</span></a>
                    </li>
                    <li class="<?php if($this->uri->segment(2) == "settings"){ echo "active";} ?>">
                        <a href="<?php echo base_url('telesales/settings'); ?>"><i class="fa fa-cog"></i> <span class="nav-label">Settings </span></a>
                    </li>
                </ul>

            </div>
        </nav>

        <div id="page-wrapper" class="gray-bg dashbard-1">
        <div class="row border-bottom">
        <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <form role="search" class="navbar-form-custom" method="get" action="<?php echo base_url('telesales/players/list'); ?>">
                <div class="form-group">
                    <input type="text" placeholder="Search for players..." class="form-control" name="q" id="top-search" value="<?php if($this->input->get('q')){ echo $this->input->get('q');}  ?>">
                </div>
            </form>
        </div>
            <ul class="nav navbar-top-links navbar-right">
                <li>
                    <a href="<?php echo base_url('logout'); ?>">
                        <i class="fa fa-sign-out"></i> Log out
                    </a>
                </li>
            </ul>

        </nav>