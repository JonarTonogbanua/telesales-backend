<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-10">
		<h2>Transaction Archive</h2>
		<ol class="breadcrumb">
			<li>
				<a href="<?php echo base_url('telesales/dashboard'); ?>">Home</a>
			</li>
			<li class="active">
				<strong>Archive</strong>
			</li>
		</ol>
	</div>
</div>
<?php if ($this->input->get('q')): ?>
	<div class="col-xs-12 marginb20">
		<br>
		<h3><?php echo count($player_list); ?> results found for "<em><?php echo $this->input->get('q'); ?></em>"</h3>
	</div>
<?php endif ?>
<div class="wrapper wrapper-content animated fadeInRight">
	<div class="row">
		<div class="col-xs-12">
			<div class="ibox float-e-margins">
				<div class="ibox-content">
					<?php if($this->session->flashdata('errors')) { ?>
					<div class="alert alert-danger">
						<strong>Please fix the errors below : <br/></strong>
						<?php echo $this->session->flashdata('errors'); ?>
					</div>
					<?php } ?>
					<?php if($this->session->flashdata('success')) { ?>
					<div class="alert alert-success">
						<?php echo $this->session->flashdata('success'); ?>
					</div>
					<?php } ?>
					<form role="form" action="<?php echo base_url('telesales/archives'); ?>" class="form-inline" method="get" enctype="multipart/form-data" id="form-upload">
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"> 
									<input type="checkbox" name="inc-country"> 
								</span> 
								<select name="country" id="" class="form-control">
									<option selected disabled>Select Country</option>
									<option value="">All</option>
									<option value="vn">Vietnam</option>
									<option value="my">Malaysia</option>
									<option value="th">Thailand</option>
									<option value="cn">China</option>
								</select>
							</div>
						</div>&emsp;
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"> 
									<input type="checkbox" name="inc-result" value="1"> 
								</span> 
								<select name="status" id="" class="form-control">
									<option selected disabled>Select Result</option>
									<option value="">All</option>
									<option value="reached">Reached</option>
									<option value="unreached">Unreached</option>
									<option value="invalid">Invalid</option>
								</select>
							</div>
						</div>&emsp;
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"> 
									<input type="checkbox" name="inc-type" value="1"> 
								</span> 
								<select name="type" id="" class="form-control">
									<option selected disabled>Select Type</option>
									<option value="">All</option>
									<option value="full conversation">Full conversation</option>
									<option value="busy">Busy</option>
									<option value="wrong person">Wrong person</option>
									<option value="hangup">Hangup</option>
									<option value="harass">Harassing</option>
									<option value="busy tone">Busy tone</option>
									<option value="unanswered">Unanswered</option>
									<option value="invalid number">Invalid Number</option>
								</select>
							</div>
						</div>&emsp;
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"> 
									<input type="checkbox" name="inc-range" value="1"> 
								</span> 
								<input class="form-control" type="text" name="daterange" value="<?php echo date('m/d/Y', time()); ?> - <?php echo date('m/d/Y', time()); ?>" />
							</div>
						</div>&emsp;
						<div class="form-group">
							<input type="submit" class="btn mt5" value="Filter">
						</div>
						<div class="form-group">
							<div class="sk-spinner sk-spinner-fading-circle" style="display:none;">
								<div class="sk-circle1 sk-circle"></div>
								<div class="sk-circle2 sk-circle"></div>
								<div class="sk-circle3 sk-circle"></div>
								<div class="sk-circle4 sk-circle"></div>
								<div class="sk-circle5 sk-circle"></div>
								<div class="sk-circle6 sk-circle"></div>
								<div class="sk-circle7 sk-circle"></div>
								<div class="sk-circle8 sk-circle"></div>
								<div class="sk-circle9 sk-circle"></div>
								<div class="sk-circle10 sk-circle"></div>
								<div class="sk-circle11 sk-circle"></div>
								<div class="sk-circle12 sk-circle"></div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="col-xs-12">
			<div class="ibox float-e-margins">
				<div class="ibox-content">
					<table class="dataTables table table-bordered table-striped">
						<thead>
							<tr>
								<th></th>
								<th>Date</th>
								<th>Login ID</th>
								<th>Agent</th>
								<th>Call Type</th>
								<th>Duration</th>
								<th>Start Time</th>
								<th>End Time</th>
								<th>Result</th>
								<th>Type</th>
								<th>Action</th>
								<th>Promo (if have)</th>
								<th>Remarks</th>
							</tr>
						</thead>
						<tbody>
							<?php if ($transaction_archives): ?>
								<?php foreach ($transaction_archives as $key => $value): ?>
									<?php $secs = $value->handle_end_timestamp - $value->handle_start_timestamp; ?>
									<tr class="<?php if($value->is_fulfilled == NULL && !$value->handle_start_timestamp){ echo "td-yellow";} ?>">
										<td><?php echo strtoupper($value->country); ?></td>
										<td><?php echo date('m/d/Y', strtotime($value->date_added)); ?></td>
										<td><?php echo $value->login_id; ?></th>
										<td><?php echo strtoupper($value->user_nickname); ?></td>
										<td><?php echo strtoupper($value->call_type); ?> CALL</td>
										<td><?php if($value->handle_start_timestamp && $value->handle_end_timestamp){ echo gmdate("H:i:s", $secs); }elseif($value->handle_start_timestamp){ echo "<em>On call</em>";}else{echo "--:--:--";} ?></td>
										<td><?php if($secs != 0 ){echo date('h:i A',$value->handle_start_timestamp);}else{echo "<em>--:-- --</em>";}; ?></td>
										<td><?php if($secs != 0 && $value->handle_end_timestamp){echo date('h:i A', $value->handle_end_timestamp);}else{echo "<em>--:-- --</em>";}; ?></td>
										<td><?php echo strtoupper($value->result); ?></td>
										<td><?php echo strtoupper($value->type); ?></td>
										<td><?php echo strtoupper($value->action); ?> <?php if($value->add_action){echo "|";} ?> <?php echo strtoupper($value->add_action); ?></td>
										<td><?php echo strtoupper($value->promo_title); ?></td>
										<td><?php echo strtoupper($value->remarks); ?></td>
									</tr>
								<?php endforeach ?>
							<?php endif ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>