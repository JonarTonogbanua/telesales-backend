
<div class="gray-bg sidebar-content">
	<div class="sidebar-panel" style="min-height: 1046px;">
		<h4>TLS Live Activity Feed</h4>
		<div id="feed">
			<div class="center-block text-center m-t">
				<div class="sk-spinner sk-spinner-wave">
					<div class="sk-rect1"></div>
					<div class="sk-rect2"></div>
					<div class="sk-rect3"></div>
					<div class="sk-rect4"></div>
					<div class="sk-rect5"></div>
				</div>
				<h5>Loading live feed<br/>please wait . . .</h5>
			</div>
		</div>
	</div>
	<div class="row wrapper wrapper-content white-bg page-heading">
		<div class="col-lg-12">
			<h2>Welcome to your Dashboard, <?php echo ucfirst($this->session->userdata('ck_nickname')); ?>!</h2>
		</div>
	</div>
	<div class="row wrapper wrapper-content animated fadeInRight">
		<div class="col-xs-12">
			<div class="ibox">
				<div class="ibox-content">
					<h3>Today's Live call progress</h3>
					<ul class="stat-list bg-muted p-md">
						<div class="row">
							<div class="col-xs-12 col-sm-6 m-b togg-my">
								<li>
									<h2 class="no-margins leads-my">-</h2>
									<small><span class="text-success">Malaysia</span> total call leads</small>
									<div class="stat-percent indicator-my">-%</div>
									<div class="progress progress-mini">
										<div style="width: 0%;" class="progress-bar progress-my"></div>
									</div>
								</li>
							</div>
							<div class="col-xs-12 col-sm-6 m-b togg-cn">
								<li>
									<h2 class="no-margins leads-cn">-</h2>
									<small><span class="text-warning">China</span> total call leads</small>
									<div class="stat-percent indicator-cn">-%</div>
									<div class="progress progress-mini">
										<div style="width: 0%;" class="progress-bar progress-cn"></div>
									</div>
								</li>
							</div>
							<div class="col-xs-12 col-sm-6 m-b togg-vn">
								<li>
									<h2 class="no-margins leads-vn">-</h2>
									<small><span class="text-info">Vietnam</span> total call leads</small>
									<div class="stat-percent indicator-vn">-%</div>
									<div class="progress progress-mini">
										<div style="width: 0%;" class="progress-bar progress-vn"></div>
									</div>
								</li>
							</div>
							<div class="col-xs-12 col-sm-6 m-b togg-my">
								<li>
									<h2 class="no-margins leads-th">-</h2>
									<small><span class="text-danger">Thailand</span> total call leads</small>
									<div class="stat-percent indicator-th">-%</div>
									<div class="progress progress-mini">
										<div style="width: 0%;" class="progress-bar progress-th"></div>
									</div>
								</li>
							</div>
						</div>
					</ul>
					<hr class="hr-line-dashed">
					<div class="row m-t">
						<div class="col-xs-12">
							<h3>Past 7 days (Updated <span class="pubdate" title="<?php echo date("c", time()) ?>"></span>)</h3>
						</div>
					</div>
					<div class="row">
						<div class="col-xs-6 col-sm-3 ">
							<div class="ibox float-e-margins bg-muted">
								<div class="ibox-content bg-muted">
									<h1 class="no-margins"><?php echo $avg_call; ?></h1>
									<small>Average Handle Duration</small>
									<div class="stat-percent font-bold m-t-n-lg"><i class="fa fa-phone fa-4x"></i></div>
								</div>
							</div>
						</div>
						<div class="col-xs-6 col-sm-3 ">
							<div class="ibox float-e-margins bg-muted">
								<div class="ibox-content bg-muted">
									<h1 class="no-margins"><?php echo $avg_break; ?></h1>
									<small>Average Break Duration</small>
									<div class="stat-percent font-bold m-t-n-lg"><i class="fa fa-bell fa-4x"></i></div>
								</div>
							</div>
						</div>
						<div class="col-xs-6 col-sm-3 ">
							<div class="ibox float-e-margins bg-muted">
								<div class="ibox-content bg-muted">
									<h1 class="no-margins"><?php echo $long_call; ?></h1>
									<small>Longest Handle Recorded</small>
									<div class="stat-percent font-bold m-t-n-lg"><i class="fa fa-phone fa-4x"></i></div>
								</div>
							</div>
						</div>
						<div class="col-xs-6 col-sm-3 ">
							<div class="ibox float-e-margins bg-muted">
								<div class="ibox-content bg-muted">
									<h1 class="no-margins"><?php echo $long_break; ?></h1>
									<small>Longest Break Recorded</small>
									<div class="stat-percent font-bold m-t-n-lg"><i class="fa fa-bell fa-4x"></i></div>
								</div>
							</div>
						</div>
					</div>
					<?php if ($lead_graph): ?>
						<div id="slineChart" class="m-b"></div>
					<?php else: ?>
						<h2 class="center-block text-center m-b m-t">
							No graphical data avaialable
						</h2>
					<?php endif ?>
					<div class="center-block text-right">
						<a href="<?php echo base_url('telesales/reports/calls'); ?>" class="btn btn-outline btn-primary">More Info</a>
					</div>
					<hr>
					
				</div>
			</div>
		</div>
	</div>
</div>

