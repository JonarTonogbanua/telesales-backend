<body class="gray-bg">

    <div class="middle-box text-center loginscreen  animated fadeInDown">
        <div>
            <div>
                <h1 class="logo-name">TLS</h1>
            </div>
            <h3>Welcome to TLS</h3>
            <p>Please Login to continue</p>
            <form class="m-t" role="form" action="<?php echo base_url('login/submit'); ?>" method="post">
                <div class="alert alert-danger alert-dismissable" style="display:none;" id="error-cont">
                    <div id="err-message"></div>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Username" name="username" required="" autofocus>
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" placeholder="Password" name="password" required="">
                </div>
                <button type="submit" class="btn btn-primary block full-width m-b">Login</button>
            </form>
            <p class="m-t"> <small>Inspinia we app framework base on Bootstrap 3 &copy; 2014</small> </p>
        </div>
    </div>