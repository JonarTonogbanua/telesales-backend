<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-10">
		<h2>Reports</h2>
		<ol class="breadcrumb">
			<li class="active">
				<strong>Call Report</strong>
			</li>
		</ol>
	</div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
	<div class="row">
		<div class="col-lg-12">
			<div class="ibox float-e-margins">
				<div class="ibox-title">
					<form class="form-inline text-right" action="<?php echo base_url('telesales/reports/calls'); ?>" method="get">
						<div class="form-group pull-left m-t-xs">
							<label for="">Graph</label>
							<select class="form-control" name="chart">
								<option <?php if($this->input->get('chart') == "spline"){ echo "selected"; } ?> value="spline">Spline</option>
								<option <?php if($this->input->get('chart') == "line"){ echo "selected"; } ?> value="line">Line</option>
								<option <?php if($this->input->get('chart') == "bar"){ echo "selected"; } ?> value="bar">Bar</option>
								<option <?php if($this->input->get('chart') == "pie"){ echo "selected"; } ?> value="pie">Pie</option>
								<option <?php if($this->input->get('chart') == "donut"){ echo "selected"; } ?> value="donut">Donut</option>
								<option <?php if($this->input->get('chart') == "area"){ echo "selected"; } ?> value="area">Area</option>
							</select>
						</div>
						&emsp;
						<div class="form-group">
							<label for="">Date Range</label>
							<input class="form-control" type="text" name="daterange" value="<?php echo date('m/d/Y',time()); ?> - <?php echo date('m/d/Y', time()); ?>" />
						</div>&emsp;
						<div class="form-group">
							<label for="">Show by</label>
							<select class="form-control" name="showby">
								<option <?php if($this->input->get('showby') == "day"){ echo "selected"; } ?> value="day">Day</option>
								<option <?php if($this->input->get('showby') == "month"){ echo "selected"; } ?> value="month">Month</option>
								<option <?php if($this->input->get('showby') == "year"){ echo "selected"; } ?> value="year">Year</option>
							</select>
						</div>&emsp;
						<div class="form-group">
							<label for="">Country</label>
							<select class="form-control" name="country">
								<option <?php if(!$this->input->get('country')){ echo "selected"; } ?> value="all">All</option>
								<option <?php if($this->input->get('country') == "th"){ echo "selected"; } ?> value="th">TH</option>
								<option <?php if($this->input->get('country') == "my"){ echo "selected"; } ?> value="my">MY</option>
								<option <?php if($this->input->get('country') == "cn"){ echo "selected"; } ?> value="cn">CN</option>
								<option <?php if($this->input->get('country') == "vn"){ echo "selected"; } ?> value="vn">VN</option>
							</select>
						</div>&emsp;
						<div class="form-group">
							<label for="">Agent</label>
							<select class="form-control" name="agent">
								<option <?php if(!$this->input->get('agent')){ echo "selected"; } ?> value="all">All</option>
							</select>
						</div>&emsp;
						<div class="form-group">
							<label for="">Call Type</label>
							<select class="form-control" name="type">
								<option <?php if(!$this->input->get('type')){ echo "selected"; } ?> value="all">All</option>
								<option <?php if($this->input->get('type') == "welcome"){ echo "selected"; } ?> value="welcome">Welcome</option>
								<option <?php if($this->input->get('type') == "retention"){ echo "selected"; } ?> value="retention">Retention</option>
								<option <?php if($this->input->get('type') == "reactivation"){ echo "selected"; } ?> value="reactivation">Reactivation</option>
							</select>
						</div>&emsp;
						<input type="submit" class="btn btn-primary btn-outline m-t-xs">
						<a href="<?php echo base_url('telesales/reports/calls'); ?>" class="btn btn-danger m-t-xs">Reset Filter</a>
					</form>
				</div>
				<div class="ibox-content">
					<div class="row">
						<div class="col-xs-12">
							<div class="row">
								<div class="col-xs-6 col-sm-3 ">
									<div class="ibox float-e-margins bg-muted">
										<div class="ibox-content bg-muted">
											<h1 class="no-margins"><?php echo $avg_call; ?></h1>
											<small>Average Handle Duration</small>
											<div class="stat-percent font-bold m-t-n-lg"><i class="fa fa-phone fa-4x"></i></div>
										</div>
									</div>
								</div>
								<div class="col-xs-6 col-sm-3 ">
									<div class="ibox float-e-margins bg-muted">
										<div class="ibox-content bg-muted">
											<h1 class="no-margins"><?php echo $avg_break; ?></h1>
											<small>Average Break Duration</small>
											<div class="stat-percent font-bold m-t-n-lg"><i class="fa fa-bell fa-4x"></i></div>
										</div>
									</div>
								</div>
								<div class="col-xs-6 col-sm-3 ">
									<div class="ibox float-e-margins bg-muted">
										<div class="ibox-content bg-muted">
											<h1 class="no-margins"><?php echo $long_call; ?></h1>
											<small>Longest Handle Recorded</small>
											<div class="stat-percent font-bold m-t-n-lg"><i class="fa fa-phone fa-4x"></i></div>
										</div>
									</div>
								</div>
								<div class="col-xs-6 col-sm-3 ">
									<div class="ibox float-e-margins bg-muted">
										<div class="ibox-content bg-muted">
											<h1 class="no-margins"><?php echo $long_break; ?></h1>
											<small>Longest Break Recorded</small>
											<div class="stat-percent font-bold m-t-n-lg"><i class="fa fa-bell fa-4x"></i></div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-xs-12">
							<?php if ($lead_graph): ?>
								<div id="slineChart" class="m-b"></div>
							<?php else: ?>
								<h2 class="center-block text-center m-b m-t">
									No graphical data avaialable
								</h2>
							<?php endif ?>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-4">
							<div class="panel panel-primary">
								<div class="panel-heading">
									Reached Calls Breakdown
								</div>
								<div class="panel-body">
									<table class="table table-striped">
										<tbody>
											<tr>
												<td>
													<span class="line">
														<?php 
														$over = 0;
														$ureach = 0;
														if($lead_graph){ 
															foreach ($lead_graph as $key => $row): ?> 
															<?php 
															echo $row->rfull;
															$over = $over + $row->rfull; 
															$ureach = $ureach + $row->reached; 
															if(count($lead_graph) != $key + 1){echo ",";}
															?>
														<?php endforeach;
													}?>
												</span>
											</td>
											<td>Full Conversation</td>
											<td><?php echo $over ." of " .$ureach; ?> </td>
											<td colspan="4"><span class="pie"><?php echo $over ."/" .$ureach; ?></span></td>
										</tr>
										<tr>
											<td>
												<span class="line">
													<?php 
													$over = 0;
													if($lead_graph){ 
														foreach ($lead_graph as $key => $row): ?> 
														<?php 
														echo $row->rbusy;
														$over = $over + $row->rbusy; if(count($lead_graph) != $key + 1){echo ",";}
														?>
													<?php endforeach;
												}
												?>
											</span>
										</td>
										<td >Busy</td>
										<td><?php echo $over ." of " .$ureach; ?> </td>
										<td colspan="4"><span class="pie"><?php echo $over ."/" .$ureach; ?></span></td>
									</tr>
									<tr>
										<td>
											<span class="line">
												<?php 
												$over = 0;
												if($lead_graph){ 
													foreach ($lead_graph as $key => $row): ?> 
													<?php 
													echo $row->rwrong;
													$over = $over + $row->rwrong; if(count($lead_graph) != $key + 1){echo ",";}
													?>
												<?php endforeach;
											}
											?>
										</span>
									</td>
									<td>Wrong Person</td>
									<td><?php echo $over ." of " .$ureach; ?> </td>
									<td colspan="4"><span class="pie"><?php echo $over ."/" .$ureach; ?></span></td>
								</tr>
								<tr>
									<td>
										<span class="line">
											<?php 
											$over = 0;
											if($lead_graph){ 
												foreach ($lead_graph as $key => $row): ?> 
												<?php 
												echo $row->rhang;
												$over = $over + $row->rhang; if(count($lead_graph) != $key + 1){echo ",";}
												?>
											<?php endforeach;
										}
										?>
									</span>
								</td>
								<td>Hangup</td>
								<td><?php echo $over ." of " .$ureach; ?> </td>
								<td colspan="4"><span class="pie"><?php echo $over ."/" .$ureach; ?></span></td>
							</tr>
							<tr>
								<td>
									<span class="line">
										<?php 
										$over = 0;
										if($lead_graph){ 
											foreach ($lead_graph as $key => $row): ?> 
											<?php 
											echo $row->rharass;
											$over = $over + $row->rharass; if(count($lead_graph) != $key + 1){echo ",";}
											?>
										<?php endforeach;
									}
									?>
								</span>
							</td>
							<td>Rude / Harassing</td>
							<td><?php echo $over ." of " .$ureach; ?> </td>
							<td colspan="4"><span class="pie"><?php echo $over ."/" .$ureach; ?></span></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<div class="col-lg-4">
		<div class="panel panel-warning">
			<div class="panel-heading">
				Unreached Calls Breakdown
			</div>
			<div class="panel-body">
				<table class="table table-striped">
					<tbody>
						<tr>
							<td>
								<span class="line">
									<?php $over = 0;$ureach = 0;if($lead_graph){ foreach ($lead_graph as $key => $row): ?> <?php echo $row->ubusy;$over = $over + $row->ubusy;$ureach = $ureach + $row->unreached;  if(count($lead_graph) != $key + 1){echo ",";}?><?php endforeach;}?>
								</span>
							</td>
							<td>Rude / Harassing</td>
							<td><?php echo $over ." of " .$ureach; ?> </td>
							<td colspan="4"><span class="pie"><?php echo $over ."/" .$ureach; ?></span></td>
						</tr>
						<tr>
							<td>
								<span class="line">
									<?php $over = 0;if($lead_graph){ foreach ($lead_graph as $key => $row): ?> <?php echo $row->uanswered;$over = $over + $row->uanswered; if(count($lead_graph) != $key + 1){echo ",";}?><?php endforeach;}?>
								</span>
							</td>
							<td>Unanswered</td>
							<td><?php echo $over ." of " .$ureach; ?> </td>
							<td colspan="4"><span class="pie"><?php echo $over ."/" .$ureach; ?></span></td>
						</tr>
						<tr><td colspan="4">&emsp;</td></tr>
						<tr><td colspan="4">&emsp;</td></tr>
						<tr><td colspan="4">&emsp;</td></tr>
					</tbody>
					<div class="m-b-xs"></div>
				</table>
			</div>
		</div>
	</div>
	<div class="col-lg-4">
		<div class="panel panel-danger">
			<div class="panel-heading">
				Invalid Number Breakdown
			</div>
			<div class="panel-body">
				<table class="table table-striped">
					<tbody>
						<tr>
							<td>
								<span class="line">
									<?php $over = 0;$ureach = 0;if($lead_graph){ foreach ($lead_graph as $key => $row): ?> <?php echo $row->inumber;$over = $over + $row->inumber;$ureach = $ureach + $row->invalid; if(count($lead_graph) != $key + 1){echo ",";}?><?php endforeach;}?>
								</span>
							</td>
							<td>Invalid Number</td>
							<td><?php echo $over ." of " .$ureach; ?> </td>
							<td colspan="4"><span class="pie"><?php echo $over ."/" .$ureach; ?></span></td>
						</tr>
						<tr><td colspan="4">&emsp;</td></tr>
						<tr><td colspan="4">&emsp;</td></tr>
						<tr><td colspan="4">&emsp;</td></tr>
						<tr><td colspan="4">&emsp;</td></tr>
					</tbody>
					<div class="m-b-xs"></div>
				</table>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-xs-12">
		<hr class="hr-line-dashed">
	</div>
	<div class="col-xs-12 col-md-6 p-md">
		<h4 class="text-center">Agent Activity Graph</h4>
		<?php if ($break_graph): ?>
			<div id="tlineChart" class="m-b"></div>
		<?php else: ?>
			<h2 class="center-block text-center m-b m-t">
				No graphical data avaialable
			</h2>
		<?php endif ?>
	</div>
	<div class="col-xs-12 col-md-6">
		<h4 class="text-center">Break Graph</h4>
		<?php if ($break_graph): ?>
			<div id="ulineChart" class="m-b"></div>
		<?php else: ?>
			<h2 class="center-block text-center m-b m-t">
				No graphical data avaialable
			</h2>
		<?php endif ?>
	</div>
</div>