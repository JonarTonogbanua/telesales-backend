<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-10">
		<h2>Reports</h2>
		<ol class="breadcrumb">
			<li class="active">
				<strong>Agent Report</strong>
			</li>
		</ol>
	</div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
	<div class="row">
		<div class="col-lg-12">
			<div class="ibox float-e-margins">
				<div class="ibox-title">
					<form class="form-inline text-right" action="<?php echo base_url('telesales/reports/agents'); ?>" method="get">
						<div class="form-group pull-left m-t-xs">
							<label for="">Graph</label>
							<select class="form-control" name="chart">
								<option <?php if($this->input->get('chart') == "spline"){ echo "selected"; } ?> value="spline">Spline</option>
								<option <?php if($this->input->get('chart') == "line"){ echo "selected"; } ?> value="line">Line</option>
								<option <?php if($this->input->get('chart') == "bar"){ echo "selected"; } ?> value="bar">Bar</option>
								<option <?php if($this->input->get('chart') == "pie"){ echo "selected"; } ?> value="pie">Pie</option>
								<option <?php if($this->input->get('chart') == "donut"){ echo "selected"; } ?> value="donut">Donut</option>
								<option <?php if($this->input->get('chart') == "area"){ echo "selected"; } ?> value="area">Area</option>
							</select>
						</div>
						&emsp;
						<div class="form-group">
							<label for="">Date Range</label>
							<input class="form-control" type="text" name="daterange" value="<?php if($this->input->get('daterange')){ echo $this->input->get('daterange'); }else{echo date('m/d/Y', time());} ?> - <?php echo date('m/d/Y', time()); ?>" />
						</div>&emsp;
						<div class="form-group">
							<label for="">Country</label>
							<select class="form-control" name="country">
								<option <?php if(!$this->input->get('country')){ echo "selected"; } ?> value="all">All</a>
									<option <?php if($this->input->get('country') == "th"){ echo "selected"; } ?> value="th">TH</option>
									<option <?php if($this->input->get('country') == "my"){ echo "selected"; } ?> value="my">MY</option>
									<option <?php if($this->input->get('country') == "cn"){ echo "selected"; } ?> value="cn">CN</option>
									<option <?php if($this->input->get('country') == "vn"){ echo "selected"; } ?> value="vn">VN</option>
								</select>
							</div>
							&emsp;
							<input type="submit" class="btn btn-primary btn-outline m-t-xs">
							<a href="<?php echo base_url('telesales/reports/agents'); ?>" class="btn btn-warning m-t-xs">Reset Filter</a>
						</form>
					</div>
					<div class="ibox-content">
						<div class="row">
							<div class="col-lg-12">
								<div class="row">
									<div class="col-xs-6 col-sm-2">
										<div class="ibox float-e-margins">
											<div class="ibox-content">
												<h1 class="no-margins"><?php echo $avg_call; ?></h1>
												<small>Average Call Duration</small>
											</div>
										</div>
									</div>
									<div class="col-xs-6 col-sm-2">
										<div class="ibox float-e-margins">
											<div class="ibox-content">
												<h1 class="no-margins"><?php echo $avg_break; ?></h1>
												<small>Average Break Duration</small>
											</div>
										</div>
									</div>
									<div class="col-xs-6 col-sm-2">
										<div class="ibox float-e-margins">
											<div class="ibox-content">
												<h1 class="no-margins">--:-- </h1>
												<small>Longest Call Recorded</small>
											</div>
										</div>
									</div>
									<div class="col-xs-6 col-sm-2">
										<div class="ibox float-e-margins">
											<div class="ibox-content">
												<h1 class="no-margins">--:--</h1>
												<small>Longest Break Recorded</small>
											</div>
										</div>
									</div>
									<div class="col-xs-6 col-sm-2">
										<div class="ibox float-e-margins">
											<div class="ibox-content">
												<h1 class="no-margins">--:--</h1>
												<small>Shortest Call Duration</small>
											</div>
										</div>
									</div>
									<div class="col-xs-6 col-sm-2">
										<div class="ibox float-e-margins">
											<div class="ibox-content">
												<h1 class="no-margins">--:--</h1>
												<small>Shortest Break Duration</small>
											</div>
										</div>
									</div>
								</div>
								<div id="slineChart" ></div>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
	</div>