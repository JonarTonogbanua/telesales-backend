<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-10">
		<h2>Players</h2>
		<ol class="breadcrumb">
			<li>
				<a href="<?php echo base_url('telesales/dashboard'); ?>">Home</a>
			</li>
			<li class="active">
				<strong>Player List</strong>
			</li>
		</ol>
	</div>
</div>
<?php if ($this->input->get('q')): ?>
	<div class="col-xs-12 marginb20">
		<br>
		<h3><?php echo count($player_list); ?> results found for "<em><?php echo $this->input->get('q'); ?></em>"</h3>
	</div>
<?php endif ?>
<div class="wrapper wrapper-content animated fadeInRight">
	<div class="row">
		<div class="col-xs-12">
			<div class="ibox float-e-margins">
				<div class="ibox-content">
					<?php if($this->session->flashdata('errors')) { ?>
					<div class="alert alert-danger">
						<strong>Please fix the errors below : <br/></strong>
                        <?php echo $this->session->flashdata('errors'); ?>
                    </div>
                    <?php } ?>
                    <?php if($this->session->flashdata('success')) { ?>
					<div class="alert alert-success">
                        <?php echo $this->session->flashdata('success'); ?>
                    </div>
                    <?php } ?>
					<form role="form" action="<?php echo base_url('telesales/players/list'); ?>" class="form-inline" method="get" enctype="multipart/form-data" id="form-upload">
						<div class="form-group">
							<select name="country" id="" class="form-control">
								<option selected disabled>Select Country</option>
								<option value="">All</option>
								<option value="vn">Vietnam</option>
								<option value="my">Malaysia</option>
								<option value="th">Thailand</option>
								<option value="cn">China</option>
							</select>
						</div>
						<div class="form-group">
							<select name="product" id="" class="form-control">
								<option selected disabled>Select Product</option>
								<option value="">All</option>
								<option value="casino">Casino</option>
								<option value="poker">Poker</option>
							</select>
						</div>
						<div class="form-group">
							<select name="status" id="" class="form-control">
								<option selected disabled>Select Status</option>
								<option value="">All</option>
								<option value="1">Blocked</option>
								<option value="0">Active</option>
							</select>
						</div>
						<div class="form-group">
							<input type="submit" class="btn mt5" value="Filter">
						</div>
						<div class="form-group">
							<div class="sk-spinner sk-spinner-fading-circle" style="display:none;">
                                    <div class="sk-circle1 sk-circle"></div>
                                    <div class="sk-circle2 sk-circle"></div>
                                    <div class="sk-circle3 sk-circle"></div>
                                    <div class="sk-circle4 sk-circle"></div>
                                    <div class="sk-circle5 sk-circle"></div>
                                    <div class="sk-circle6 sk-circle"></div>
                                    <div class="sk-circle7 sk-circle"></div>
                                    <div class="sk-circle8 sk-circle"></div>
                                    <div class="sk-circle9 sk-circle"></div>
                                    <div class="sk-circle10 sk-circle"></div>
                                    <div class="sk-circle11 sk-circle"></div>
                                    <div class="sk-circle12 sk-circle"></div>
                                </div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="col-xs-12">
			<div class="ibox float-e-margins">
				<div class="ibox-content">
					<div class="row">
						<div class="col-xs-1">
							<h4>Legends : </h4>
						</div>
						<div class="col-xs-10">
							<span class="label td-yellow">&emsp;</span>
							Don't call yet&emsp;
							<span class="label td-red">&emsp;</span>
							Blocked&emsp;
							<span class="label bg-violet">&emsp;</span>
							Follow up&emsp;
						</div>
					</div>
					<br/>
					<table class="table table-striped table-bordered table-hover dataTables" >
						<thead>
							<tr>
								<th>LOGIN ID</th>
								<th>USER ID</th>
								<th>NAME</th>
								<th>BANK</th>
								<th>JOIN DATE</th>
								<th>EMAIL</th>
								<th>PHONE</th>
								<th>AGENT</th>
								<th>PRODUCT</th>
								<th>COUNTRY</th>
								<th>LAST CALLED</th>
								<th>NO CALL UNTIL</th>
							</tr>
						</thead>
						<tbody>
							<?php  
							if($player_list){
								foreach($player_list as $row){ 
								$bg ="";
								if($row->no_call_until_date > time()){
									$bg = "td-yellow";
								}elseif($row->is_blocked == 1){
									$bg = "td-red";
								}elseif(strtotime("today midnight") <= $row->no_call_until_date && time() < strtotime("tomorrow midnight")){
									$bg = "bg-violet";
								}
							?>
							<tr class="<?php echo $bg; ?>" entry-id="<?php echo $row->entry_no; ?>">
								<td><?php echo strtoupper($row->login_id); ?></td>
								<td><?php echo $row->user_id; ?></td>
								<td><?php echo $row->player_name; ?></td>
								<td><?php echo $row->player_bank; ?></td>
								<td><?php echo strtoupper($row->join_date); ?></td>
								<td><?php echo $row->player_email; ?></td>
								<td><?php echo strtoupper($row->player_phone); ?></td>
								<td>
									<?php
									if ($row->player_agent) {
									 	echo strtoupper($row->player_agent);
									 }else{
									 	echo "N/A";
									 } 
									 ?>
								</td>
								<td><?php echo strtoupper($row->player_product); ?></td>
								<td><?php echo strtoupper($row->player_loc); ?></td>
								<td>
									<?php
									if ($row->last_called > 0) {
									 	echo date('m/d/Y h:i A', $row->last_called);
									 }else{
									 	echo "N/A";
									 } 
									 ?>
								</td>
								<td>
									<?php
									if (is_numeric($row->no_call_until_date) && $row->no_call_until_date >= strtotime("today midnight")) {
									 	echo date('m/d/Y h:i A', $row->no_call_until_date);
									 }else{
									 	echo "N/A";
									 } 
									 ?>
								</td>
							</tr>
							<?php	
								}
							}
							?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>