<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-10">
		<h2>Players</h2>
		<ol class="breadcrumb">
			<li>
				<a href="<?php echo base_url('telesales/dashboard'); ?>">Home</a>
			</li>
			<li class="active">
				<strong>Players Revision</strong>
			</li>
		</ol>
	</div>
</div>
<?php if ($this->input->get('q')): ?>
	<div class="col-xs-12 marginb20">
		<br>
		<h3><?php echo count($player_list); ?> results found for "<em><?php echo $this->input->get('q'); ?></em>"</h3>
	</div>
<?php endif ?>
<div class="wrapper wrapper-content animated fadeInRight">
	<div class="row">
		<div class="col-xs-12">
			<div class="ibox float-e-margins">
				<div class="ibox-content">
					<?php if($this->session->flashdata('errors')) { ?>
					<div class="alert alert-danger">
						<strong>Please fix the errors below : <br/></strong>
                        <?php echo $this->session->flashdata('errors'); ?>
                    </div>
                    <?php } ?>
                    <?php if($this->session->flashdata('success')) { ?>
					<div class="alert alert-success">
                        <?php echo $this->session->flashdata('success'); ?>
                    </div>
                    <?php } ?>
					<form role="form" action="<?php echo base_url('telesales/players/revisions/'); ?>" class="form-inline" method="get" enctype="multipart/form-data" id="form-upload">
						<div class="form-group">
							<select name="country" id="" class="form-control">
								<option selected disabled>Select Country</option>
								<option value="">All</option>
								<option value="vn" <?php if($this->input->get('country') == "vn"): echo "selected";endif;?> >Vietnam</option>
								<option value="my" <?php if($this->input->get('country') == "my"): echo "selected";endif;?>>Malaysia</option>
								<option value="th" <?php if($this->input->get('country') == "th"): echo "selected";endif;?>>Thailand</option>
								<option value="cn" <?php if($this->input->get('country') == "cn"): echo "selected";endif;?>>China</option>
							</select>
						</div>&emsp;
						<div class="form-group">
							<select name="show" id="" class="form-control">
								<option value="" <?php if($this->input->get('show') == ""): echo "selected";endif;?>>Show All</option>
								<option value="1" <?php if($this->input->get('show') == "1"): echo "selected";endif;?> >Fulfilled</option>
								<option value="0" <?php if($this->input->get('show') == "0"): echo "selected";endif;?> >Not Fulfilled</option>
							</select>
						</div>
						<div class="form-group">
							<input type="submit" class="btn mt5" value="Submit">
						</div>
						<div class="form-group">
							<div class="sk-spinner sk-spinner-fading-circle" style="display:none;">
                                    <div class="sk-circle1 sk-circle"></div>
                                    <div class="sk-circle2 sk-circle"></div>
                                    <div class="sk-circle3 sk-circle"></div>
                                    <div class="sk-circle4 sk-circle"></div>
                                    <div class="sk-circle5 sk-circle"></div>
                                    <div class="sk-circle6 sk-circle"></div>
                                    <div class="sk-circle7 sk-circle"></div>
                                    <div class="sk-circle8 sk-circle"></div>
                                    <div class="sk-circle9 sk-circle"></div>
                                    <div class="sk-circle10 sk-circle"></div>
                                    <div class="sk-circle11 sk-circle"></div>
                                    <div class="sk-circle12 sk-circle"></div>
                                </div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="col-xs-12">
			<div class="ibox float-e-margins">
				<div class="ibox-content">
					<table class="table table-striped table-bordered table-hover dataTables2" >
						<thead>
							<tr>
								<th>LOGIN ID</th>
								<th>USER ID</th>
								<th>COUNTRY</th>
								<th>FIELD</th>
								<th>OLD VALUE</th>
								<th>NEW VALUE</th>
								<th>PLACED BY</th>
								<th>DATE PLACED</th>
								<th>IS FULFILLED</th>
							</tr>
						</thead>
						<tbody>
						<?php  
							if($players_revision){
								foreach($players_revision as $row){ 
							?>
							<tr entry-id="<?php echo $row->entry_id; ?>">
								<td><?php echo strtoupper($row->login_id); ?></td>
								<td><?php echo $row->user_id; ?></td>
								<td><?php echo strtoupper($row->player_loc); ?></td>
								<td><?php echo strtoupper($row->revise_field); ?></td>
								<td><?php echo $row->old_value; ?></td>
								<td><?php echo $row->new_value; ?></td>
								<td><?php echo strtoupper($row->placed_by); ?></td>
								<td><?php echo date("m/d/Y h:i A", strtotime($row->date_placed)); ?></td>
								<td>
									<?php $ff="YES";if($row->fulfill_status == 0){$ff="NO";}echo $ff; ?>
								</td>
							</tr>
							<?php	
								}
							}
							?>
						</tbody>
					</table>
					<hr class="hr-line-dashed">
					<form role="form" action="<?php echo base_url('telesales/upload_revision'); ?>" class="form-inline" method="post" enctype="multipart/form-data" id="form-upload">
						<div class="form-group">
							<label for="" class="control-label m-t-xs">Upload Revision</label>&emsp;
							<div class="fileinput fileinput-new" data-provides="fileinput">
								<span class="btn btn-default btn-file"><span class="fileinput-new">Select CSV File</span>
								<span class="fileinput-exists">Change</span><input type="file" name="csvfile" accept=".csv" required/></span>
								<span class="fileinput-filename"></span>
								<a href="#" class="close fileinput-exists" data-dismiss="fileinput" style="float: none">×</a>
							</div> 
						</div>
						<div class="form-group">
							<input type="submit" name="submit" class="btn mt5" value="Check">
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>