<div class="modal inmodal fade" id="createModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title">Create new Campaign</h4>
            </div>
            <form action="<?php echo base_url('telesales/campaign_submit'); ?>" id="campaign-form" method="POST">
                <div class="modal-body">
                    <div class="alert alert-danger alert-dismissable" style="display:none;" id="reg-camp">
                    </div>
                    <em>* required</em>
                    <div class="form-group">
                        <label for="">* Product Type</label>
                        <select name="product" id="" class="form-control">
                            <option value="poker">Poker</option>
                            <option value="casino">Casino</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">* Country</label>
                        <select name="country" id="" class="form-control">
                            <option value="my">Malaysia</option>
                            <option value="vn">Vietnam</option>
                            <option value="th">Thailand</option>
                            <option value="cn">China</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">* Campaign Title</label>
                        <input type="text" placeholder="Campaign title" name="title" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="">* Call Type</label>
                        <select name="calltype" id="" class="form-control">
                            <option selected disabled>Select Call type</option>
                            <option value="welcome">Welcome Call</option>
                            <option value="retention">Retention Call</option>
                            <option value="reactivation">Reactivation Call</option>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-xs-6">
                            <div class="form-group" id="data_1">
                                <label>* Campaign Start Date</label>
                                <div class="input-group date">
                                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span><input type="text" name="start-datedate" class="form-control" value="<?php echo date('m/d/Y', time()); ?>">
                                </div>
                            </div>  
                        </div>
                        <div class="col-xs-6">
                            <div class="form-group">
                                <label>* Time</label>
                                <div class="input-group clockpicker" data-autoclose="true">
                                    <input type="text" class="form-control" name="start-datetime" value="00:00">
                                    <span class="input-group-addon">
                                        <span class="fa fa-clock-o"></span>
                                    </span>
                                </div>
                            </div>  
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6">
                            <div class="form-group" id="data_1">
                                <label>* Valid Until Date</label>
                                <div class="input-group date">
                                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span><input type="text" name="end-datedate" class="form-control" value="<?php echo date('m/d/Y', time()); ?>">
                                </div>
                            </div>  
                        </div>
                        <div class="col-xs-6">
                            <div class="form-group">
                                <label>* Time</label>
                                <div class="input-group clockpicker" data-autoclose="true">
                                    <input type="text" class="form-control" name="end-datetime" value="00:00">
                                    <span class="input-group-addon">
                                        <span class="fa fa-clock-o"></span>
                                    </span>
                                </div>
                            </div>  
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">* Terms and Conditions</label>
                        <textarea name="tnc" cols="20" rows="5" class="form-control summernote"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
                    <input type="submit" class="btn btn-primary" value="Save Campaign">
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal inmodal fade" id="editModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title">Edit Campaign</h4>
            </div>
            <form action="<?php echo base_url('telesales/submit_edit_campaign'); ?>" id="edit-campaign-form">
                <div class="modal-body">
                    <div class="alert alert-danger alert-dismissable" style="display:none;" id="edit-camp">
                    </div>
                    <div class="form-group">
                        <label for="">Campaign ID : <h3 name="edit-id">WC</h3></label>
                        <input type="hidden" name="edit-id">
                        <input type="hidden" name="edit-isdefault">
                    </div>
                    <div class="form-group">
                        <label for="">Product Type</label>
                        <select name="edit-product" id="" class="form-control">
                            <option value="poker">Poker</option>
                            <option value="casino">Casino</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Country</label>
                        <select name="edit-country" id="" class="form-control">
                            <option value="my">Malaysia</option>
                            <option value="vn">Vietnam</option>
                            <option value="th">Thailand</option>
                            <option value="cn">China</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Campaign Title</label>
                        <input type="text" placeholder="Campaign title" name="edit-title" class="form-control">
                    </div>
                    <hr class="hr-line-dashed">
                    <div class="row">
                        <div class="col-xs-6">
                            <div class="form-group" id="data_1">
                                <label class="font-normal">Campaign Start Date</label>
                                <div class="input-group date">
                                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span><input type="text" name="edit-startdate" class="form-control duration">
                                </div>
                            </div>  
                        </div>
                        <div class="col-xs-6">
                            <div class="form-group">
                                <label class="font-normal">Time</label>
                                <div class="input-group clockpicker" data-autoclose="true">
                                    <input type="text" class="form-control duration" name="edit-starttime">
                                    <span class="input-group-addon">
                                        <span class="fa fa-clock-o"></span>
                                    </span>
                                </div>
                            </div>  
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6">
                            <div class="form-group" id="data_1">
                                <label class="font-normal">Valid Until Date</label>
                                <div class="input-group date">
                                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span><input type="text" name="edit-enddate" class="form-control duration">
                                </div>
                            </div>  
                        </div>
                        <div class="col-xs-6">
                            <div class="form-group">
                                <label class="font-normal">Time</label>
                                <div class="input-group clockpicker" data-autoclose="true">
                                    <input type="text" class="form-control duration" name="edit-endtime">
                                    <span class="input-group-addon">
                                        <span class="fa fa-clock-o"></span>
                                    </span>
                                </div>
                            </div>  
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Terms and Conditions</label>
                        <textarea name="edit-tnc" id="" cols="20" rows="5" class="form-control "></textarea>
                    </div>
                    <div class="form-group">
                        <label for="">Campaign status</label>
                        <select name="edit-status" id="" class="form-control">
                            <option value="1">Enabled</option>
                            <option value="0">Disabled</option>
                        </select>
                    </div>
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
                    <input type="submit" class="btn btn-primary" value="Save changes">
                </div>
            </form>
        </div>
    </div>
</div>