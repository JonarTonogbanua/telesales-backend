<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-10">
		<h2>Telesales</h2>
		<ol class="breadcrumb">
			<li>
				<a href="<?php echo base_url('telesales/dashboard'); ?>">Home</a>
			</li>
			<li>
				<a href="javascript:void(0);">Telesales</a>
			</li>
			<li class="active">
				<strong>Accounts</strong>
			</li>
		</ol>
	</div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
	<div class="row">
		<div class="col-xs-12">
			<div class="ibox float-e-margins">
				<div class="ibox-content">
					<button data-action="create" class="btn-create btn btn-outline btn-primary"><i class="fa fa-plus"></i> Create new Account</button>
					<br/><br/>
					<table class="table table-striped table-bordered table-hover dataTables" >
						<thead>
							<tr>
								<th></th>
								<th>USERNAME</th>
								<th>NICKNAME</th>
								<th>COUNTRY</th>
								<th>SYSTEM LANGUAGE</th>
								<th>DATE ADDED</th>
								<th>LAST ACTIVITY</th>
								<th>ACTION</th>
							</tr>
						</thead>
						<tbody>
							<?php  
							if($telesales_accounts){
								foreach($telesales_accounts as $row){
									?>
									<tr user-id="<?php echo $row->user_id; ?>">
										<td class="text-center">
											<?php if ($row->user_status == 1): ?>
												<span class="label label-primary img-circle" data-toggle="tooltip" data-placement="top" title="Online">&nbsp;</span>
											<?php else: ?>
												<span class="label label-danger img-circle" data-toggle="tooltip" data-placement="top" title="Offline">&nbsp;</span>
											<?php endif ?>
										</td>
										<td><?php echo $row->user_name; ?></td>
										<td><?php echo ucfirst($row->user_nickname); ?></td>
										<td><?php echo strtoupper($row->user_country); ?></td>
										<td><?php echo strtoupper($row->user_language); ?></td>
										<td><?php echo date('F d, Y @ h:i a',$row->date_added); ?></td>
										<td><?php echo $row->activity_name; ?> ( <span class="pubdate" title="<?php echo $row->timestamp; ?>"><?php echo $row->timestamp; ?></span> )</td>
										<td class="text-center">
											<a data-action="view" href="<?php echo base_url('telesales/reports/calls?country='.$row->user_country.'&agent='.$row->user_id); ?>" class="btn btn-action btn-xs btn-success"><i class="fa fa-bar-chart"></i></a>
											<button data-action="edit" class="btn btn-action btn-xs btn-primary"><i class="fa fa-edit"></i></button>
											<button data-action="delete" class="btn btn-action btn-xs btn-danger"><i class="fa fa-times"></i></button>
										</td>
									</tr>
									<?php	
								}
							}
							?>
						</tbody>
					</table>
					<hr>
					<div id="statistics" class="m-t">
						<div class="center-block text-center" id="stat-load" style="display:none;">
							<div class="sk-spinner sk-spinner-wave">
								<div class="sk-rect1"></div>
								<div class="sk-rect2"></div>
								<div class="sk-rect3"></div>
								<div class="sk-rect4"></div>
								<div class="sk-rect5"></div>
							</div>
							Loading agent statictistics . . .
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>