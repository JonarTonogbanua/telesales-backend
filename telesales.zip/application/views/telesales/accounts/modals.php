<div class="modal inmodal fade" id="createModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <form action="<?php echo base_url('telesales/accounts_submit'); ?>" id="reg-form">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title">Create new Account</h4>
                </div>
                <div class="modal-body">
                    <div class="alert alert-danger alert-dismissable" style="display:none;" id="reg-cont">
                    </div>
                    <div class="form-group">
                        <label for="">Username</label>
                        <div class="input-group m-b"><span class="input-group-addon">tls</span> <input type="text" placeholder="Username" name="username" class="form-control" required=""></div>
                    </div>
                    <div class="form-group">
                        <label for="">Nickname ( <em>This will be used on assigning calls</em> )</label>
                        <input type="text" placeholder="Nickname" name="nickname" class="form-control" required="">
                    </div>
                    <div class="form-group">
                        <label for="">Password</label>
                        <input type="password" placeholder="Password" name="password" class="form-control" required="">
                    </div>
                    <div class="form-group">
                        <label for="">Repeat Password</label>
                        <input type="password" placeholder="Repeat Password" name="rpassword" class="form-control" required="">
                    </div>
                    <div class="form-group">
                        <label for="">Country</label>
                        <select name="country" id="" class="form-control" required="">
                            <option value="my">Malaysia</option>
                            <option value="vn">Vietnam</option>
                            <option value="th">Thailand</option>
                            <option value="cn">China</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">System Language</label>
                        <select name="language" id="" class="form-control"  required="">
                            <option value="en">English (default)</option>
                            <option value="vi">Vietnamese</option>
                            <option value="th">Thai</option>
                            <option value="cn">Chinese</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
                    <input type="submit" class="btn btn-primary" value="Save Account">
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal inmodal fade" id="editModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title">Edit existing Account</h4>
            </div>
            <div class="modal-body">
                <div class="alert alert-danger alert-dismissable" style="display:none;" id="reg-cont">
                </div>
                <form action="<?php echo base_url('telesales/edit_submit'); ?>" id="edit-form">
                    <div class="form-group">
                        <label for="">Username : <h3 name="edit-username">xxxxx</h3></label>
                    </div>
                    <div class="form-group">
                        <label for="">Nickname</label>
                        <input type="text" placeholder="Nickname" name="edit-nickname" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="">New Password</label>
                        <input type="password" placeholder="Password" name="edit-password" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="">Country</label>
                        <select name="edit-country" id="" class="form-control">
                            <option value="my">Malaysia</option>
                            <option value="vn">Vietnam</option>
                            <option value="th">Thailand</option>
                            <option value="cn">China</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">System Language</label>
                        <select name="edit-language" id="" class="form-control">
                            <option value="en">English (default)</option>
                            <option value="vn">Vietnamese</option>
                            <option value="th">Thai</option>
                            <option value="cn">Chinese</option>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>