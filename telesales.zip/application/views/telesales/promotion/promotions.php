<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-10">
		<h2>Campaign Management</h2>
		<ol class="breadcrumb">
			<li>
				<a href="<?php echo base_url('telesales/dashboard'); ?>">Home</a>
			</li>
			<li>
				<a href="javascript:void(0);">Campaign Mgmt</a>
			</li>
			<li class="active">
				<strong>Promotions</strong>
			</li>
		</ol>
	</div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
	<div class="row">
		<div class="col-xs-12">
			<div class="ibox float-e-margins">
				<div class="ibox-content">
					<button data-action="create" class="btn-create btn btn-outline btn-primary"><i class="fa fa-plus"></i> Create new Promotion</button>
					<hr>
					<form role="form" class="form-inline pull-left">
						<div class="form-group">
							<label for="calltype">Country</label>
							<select name="country" id="" class="form-control">
                            <option value="">All</option>
                            <option <?php if($this->input->get('country') == "my"){echo "selected"; } ?> value="my">Malaysia</option>
                            <option <?php if($this->input->get('country') == "vn"){echo "selected"; } ?> value="vn">Vietnam</option>
                            <option <?php if($this->input->get('country') == "th"){echo "selected"; } ?> value="th">Thailand</option>
                            <option <?php if($this->input->get('country') == "cn"){echo "selected"; } ?> value="cn">China</option>
                        </select>
						</div>
						<div class="form-group">
							<label for="calltype">Call Type</label>
							<select name="calltype" id="" class="form-control">
								<option value="">All</option>
								<option <?php if($this->input->get('calltype') == "welcome"){echo "selected"; } ?> value="welcome">Welcome Call</option>
								<option <?php if($this->input->get('calltype') == "retention"){echo "selected"; } ?> value="retention">Retention Call</option>
								<option <?php if($this->input->get('calltype') == "reactivation"){echo "selected"; } ?> value="reactivation">Reactivation Call</option>
							</select>
						</div>
						<div class="form-group">
							<label for="product">Product</label>
							<select name="product" id="" class="form-control">
								<option value="">All</option>
								<option <?php if($this->input->get('product') == "poker"){echo "selected"; } ?> value="poker">Poker</option>
								<option <?php if($this->input->get('product') == "casino"){echo "selected"; } ?> value="casino">Casino</option>
							</select>
						</div>
						<div class="form-group">
							<input type="submit" class="btn btn-default btn-outline" style="margin-top:5px;">
						</div>
					</form>
					<br/>
					<table class="table table-striped table-bordered table-hover dataTables" >
						<thead>
							<tr>
								<th>STATUS</th>
								<th>PROMO CODE</th>
								<th>PROMO TITLE</th>
								<th>CAMPAIGN</th>
								<th>COUNTRY</th>
								<th>CALL TYPE</th>
								<th>PRODUCT</th>
								<th>START DATE</th>
								<th>EXPIRED DATE </th>
								<th>ACTION</th>
							</tr>
						</thead>
						<tbody>
							<?php  
							if($promotion_lists){
								foreach ($promotion_lists as $row) {
							?>
							<tr promo-id="<?php echo $row->promo_id; ?>">
								<td class="text-center">
								<?php 
									if($row->is_default == 1){
										echo '&nbsp;<span class="label label-primary">default</span>';
									} 
									if($row->campaign_end_date <= time() && $row->is_default == 0){
										echo '&nbsp;<span class="label label-danger">expired</span>';
									} 
									if($row->is_enabled == 0 ){
										echo '&nbsp;<span class="label label-warning">campaign disabled</span>';
									} 
									if($row->promo_status == 0 ){
										echo '&nbsp;<span class="label label-warning">promo disabled</span>';
									} 
								?>
								</td>
								<td><?php echo strtoupper($row->promo_code); ?></td>
								<td><?php echo strtoupper($row->promo_title); ?></td>
								<td><?php echo strtoupper($row->campaign_title); ?></td>
								<td><?php echo strtoupper($row->campaign_country); ?></td>
								<td><?php echo strtoupper($row->call_type); ?> CALL</td>
								<td><?php echo strtoupper($row->product_type); ?></td>
								<?php  
									if($row->is_default == 1){
										echo "<td>~</td><td>IN PERPETUITY</td>";
									}else{
								?>
								<td>
									<?php
										echo date('F d, Y h:i A ', $row->campaign_start_date);
									?>
								</td>
								<td>
									<?php
										echo date('F d, Y h:i A ', $row->campaign_end_date);

									?>
								</td>
								<?php } ?>
								<td class="text-center">
									<button data-action="edit" class="btn btn-action btn-xs btn-primary"><i class="fa fa-edit"></i></button>
									<button data-action="delete" class="btn btn-action btn-xs btn-danger"><i class="fa fa-times"></i></button>
								</td>
							</tr>
							<?php	
								}
							}
							?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>