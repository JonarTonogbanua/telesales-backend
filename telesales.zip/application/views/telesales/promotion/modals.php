<div class="modal inmodal fade" id="createModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title">Create new Promotion</h4>
            </div>
            <div class="modal-body campaign-info">
                 <button type="button" class="close" id="close-extend"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                <h3 class="text-center">Campaign Information</h3>
                <hr>
                <div class="sk-spinner sk-spinner-cube-grid" style="display:none;">
                    <div class="sk-cube"></div>
                    <div class="sk-cube"></div>
                    <div class="sk-cube"></div>
                    <div class="sk-cube"></div>
                    <div class="sk-cube"></div>
                    <div class="sk-cube"></div>
                    <div class="sk-cube"></div>
                    <div class="sk-cube"></div>
                    <div class="sk-cube"></div>
                </div>
                <div id="campaign-info">
                    <div class="form-group">
                        <label>Campaign Title </label><a class="linkto pull-right" href="<?php echo base_url(); ?>" target="_blank"><i class="fa fa-external-link"></i></a>
                        <input data-tag="info-title" readonly class="input-sm form-control">
                    </div>
                    <div class="form-group">
                        <label>Is Default</label>
                        <input data-tag="info-default" readonly class="input-sm form-control">
                    </div>
                    <div class="form-group">
                        <label>Call Type</label>
                        <input data-tag="info-type" readonly class="input-sm form-control">
                    </div>
                    <div class="form-group">
                        <label>Country</label>
                        <input data-tag="info-country" readonly class="input-sm form-control">
                    </div>
                    <div class="form-group">
                        <label>Product</label>
                        <input data-tag="info-product" readonly class="input-sm form-control">
                    </div>
                    <div class="form-group">
                        <label>Expiration Date</label>
                        <input data-tag="info-end" readonly class="input-sm form-control">
                    </div>
                    <div class="form-group">
                        <label>No. of active Promotions</label>
                        <input data-tag="info-total" readonly class="input-sm form-control">
                    </div>
                    <div class="form-group">
                        <label>Terms and Conditions</label>
                        <textarea data-tag="info-tnc" readonly class="input-sm form-control"></textarea>
                    </div>
                </div>
            </div>
            <form method="post" action="<?php echo base_url('telesales/submit_promotion'); ?>" id="promotion-form">
                <div class="modal-body">
                    <div class="alert alert-danger alert-dismissable" style="display:none;" id="reg-promo">
                    </div>
                    <em>* required</em>
                    <div class="form-group">
                        <label for="">* Campaign</label>
                        <select name="campaign-id" id="campaign-select" class="form-control" required>
                            <option disabled selected>Select Campaign</option>
                            <?php if ($campaign_dropdown): ?>
                                <?php foreach ($campaign_dropdown as $row): ?>
                                    <option value="<?php echo $row->campaign_id ?>"><?php echo " [ ". strtoupper($row->call_type) . " CALL ][ " . strtoupper($row->campaign_country) ." ] ".$row->campaign_title; ?></option> 
                                <?php endforeach ?>
                            <?php endif ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">* Promo Code</label>
                        <input type="text" placeholder="Promo code" name="promocode" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">* Promo Title</label>
                        <input type="text" placeholder="Promo Title" name="promotitle" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">* Promotion Link / information</label>
                        <textarea name="promolink" id="" cols="20" rows="5" class="form-control" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="">Custom Terms and Conditions</label>
                        <textarea name="customtnc" id="" cols="20" rows="5" class="form-control"></textarea>
                        <div class="checkbox">
                            <input id="checkbox1" type="checkbox" name="iscustom">
                            <label for="checkbox1">
                                Custom Terms and Conditions
                            </label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Additional Notes</label>
                        <textarea name="notes" id="" cols="20" rows="5" class="form-control"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
                    <input type="submit" class="btn btn-primary" value="Save Promotion">
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal inmodal fade" id="editModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title">Edit Promotion</h4>
            </div>
            <form action="<?php echo base_url('telesales/submit_edit_promo'); ?>" id="edit-promo-form">
                <div class="modal-body">
                    <div class="alert alert-danger alert-dismissable" style="display:none;" id="edit-promo">
                    </div>
                    <div class="form-group">
                        <label for="">Promo Code : <h3 name="edit-code">WC1</h3></label>
                        <input type="hidden" name="edit-id">
                    </div>
                    <div class="form-group">
                        <label for="">Campaign</label>
                        <select name="campaign-id" id="" class="form-control">
                            <?php if ($campaign_dropdown): ?>
                                <?php foreach ($campaign_dropdown as $row): ?>
                                    <option value="<?php echo $row->campaign_id ?>"><?php echo " [ ". strtoupper($row->call_type) . " CALL ][ " . strtoupper($row->campaign_country) ." ] ".$row->campaign_title; ?></option> 
                                <?php endforeach ?>
                            <?php endif ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Promo Title</label>
                        <input type="text" placeholder="Promo Title" name="edit-title" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="">Promotion Link / information</label>
                        <textarea name="edit-link" id="" cols="10" rows="5" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="">Custom Terms and Conditions</label>
                        <textarea name="edit-tnc" id="" cols="10" rows="5" class="form-control"></textarea>
                        <div class="checkbox">
                            <input id="checkbox1" name="edit-iscustom" type="checkbox">
                            <label for="checkbox1">
                                Custom Terms and Conditions
                            </label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Additional Notes</label>
                        <textarea name="edit-notes" id="" cols="10" rows="5" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="">Promotion status</label>
                        <select name="edit-status" id="" class="form-control">
                            <option value="1">Enabled</option>
                            <option value="0">Disabled</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
                    <input type="submit" class="btn btn-primary" value="Save changes">
                </div>
            </form>
        </div>
    </div>
</div>