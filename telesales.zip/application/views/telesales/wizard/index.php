<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-10">
		<h2>Wizard</h2>
		<ol class="breadcrumb">
			<li>
				<a href="<?php echo base_url('telesales/dashboard'); ?>">Home</a>
			</li>
			<li class="active">
				<strong>Wizard</strong>
			</li>
		</ol>
	</div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
	<div class="row">
		<div class="col-xs-12">
			<?php if($this->session->flashdata('errors')) { ?>
			<div class="alert alert-danger">
				<strong>Please fix the errors below : <br/></strong>
				<?php echo $this->session->flashdata('errors'); ?>
			</div>
			<?php } ?>
			<?php if($this->session->flashdata('success')) { ?>
			<div class="alert alert-success">
				<?php echo $this->session->flashdata('success'); ?>
			</div>
			<?php } ?>
		</div>
		<div class="col-xs-12">
			<div class="ibox float-e-margins">
				<div class="ibox-content">
					<?php  
					if(!$temporary_record){
						?>
						<form role="form" action="<?php echo base_url('telesales/upload_data'); ?>" class="form-inline" method="post" enctype="multipart/form-data" id="form-upload">
							<div class="form-group">
								<div class="fileinput fileinput-new" data-provides="fileinput">
									<span class="btn btn-default btn-file"><span class="fileinput-new">Select CSV File</span>
									<span class="fileinput-exists">Change</span><input type="file" name="csvfile" accept=".csv"/ required></span>
									<span class="fileinput-filename"></span>
									<a href="#" class="close fileinput-exists" data-dismiss="fileinput" style="float: none">×</a>
								</div> 
							</div>
							<div class="form-group">
								<select name="country" id="" class="form-control">
									<option selected disabled>Select Country</option>
									<option value="vn">Vietnam</option>
									<option value="my">Malaysia</option>
									<option value="th">Thailand</option>
									<option value="cn">China</option>
								</select>
							</div>
							<div class="form-group">
								<select name="calltype" id="" class="form-control">
									<option selected disabled>Select Call Type</option>
									<option value="welcome">Welcome Call</option>
									<option value="retention">Retention Call</option>
									<option value="reactivation">Reactivation Call</option>
								</select>
							</div>
							<div class="form-group">
								<select name="campaign-id" id="select-campaign" class="form-control">
									<option selected disabled>Select Campaign</option>
								</select>
							</div>
							<div class="form-group">
								<input type="submit" name="submit" class="btn mt5" value="Preview">
							</div>
							<div class="form-group">
								<div class="sk-spinner sk-spinner-fading-circle" style="display:none;">
									<div class="sk-circle1 sk-circle"></div>
									<div class="sk-circle2 sk-circle"></div>
									<div class="sk-circle3 sk-circle"></div>
									<div class="sk-circle4 sk-circle"></div>
									<div class="sk-circle5 sk-circle"></div>
									<div class="sk-circle6 sk-circle"></div>
									<div class="sk-circle7 sk-circle"></div>
									<div class="sk-circle8 sk-circle"></div>
									<div class="sk-circle9 sk-circle"></div>
									<div class="sk-circle10 sk-circle"></div>
									<div class="sk-circle11 sk-circle"></div>
									<div class="sk-circle12 sk-circle"></div>
								</div>
							</div>
						</form>
						<?php }else{ ?>
						<h3>Uploading currently disabled</h3>
						<?php } ?>
					</div>
				</div>
			</div>
			<div class="col-xs-12">
				<div class="ibox float-e-margins">
					<div class="ibox-content">
						<div class="row">
							<div class="col-xs-1">
								<h4>Legends : </h4>
							</div>
							<div class="col-xs-10">
								<span class="label td-green">&emsp;</span>
								No issue&emsp;
								<span class="label td-blue">&emsp;</span>
								Duplicate Entry&emsp;
								<span class="label td-yellow">&emsp;</span>
								Don't call yet&emsp;
								<span class="label td-red">&emsp;</span>
								Blocked&emsp;
							</div>
						</div>
						<br/>
						<table class="table table-striped table-bordered table-hover dataTables" >
							<thead>
								<tr>
									<th>LOGIN ID</th>
									<th>USER ID</th>
									<th>NAME</th>
									<th>BANK</th>
									<th>JOIN DATE</th>
									<th>EMAIL</th>
									<th>PHONE</th>
									<th>AGENT</th>
									<th>PRODUCT</th>
									<th>CALL TYPE</th>
									<th>CAMPAIGN</th>
								</tr>
							</thead>
							<tbody>
								<?php  
								if($temporary_record){
									foreach($temporary_record as $row){ 
										?>
										<tr class="<?php echo $row->entry_color; ?>">
											<td><?php echo $row->login_id; ?></td>
											<td><?php echo $row->user_id; ?></td>
											<td><?php echo $row->player_name; ?></td>
											<td><?php echo $row->player_bank; ?></td>
											<td><?php echo strtoupper($row->join_date); ?></td>
											<td><?php echo $row->player_email; ?></td>
											<td><?php echo strtoupper($row->player_phone); ?></td>
											<td>
												<?php
												if ($row->player_agent) {
													echo strtoupper($row->player_agent);
												}else{
													echo "<em><small>( AUTO ASSIGN )<small></em>";
												} 
												?>
											</td>
											<td><?php echo strtoupper($row->player_product); ?></td>
											<td><?php echo strtoupper($row->calltype ." call"); ?></td>
											<td>
												<?php
												if ($row->campaign_title) {
													echo strtoupper($row->campaign_title);
												}else{
													echo "( DEFAULT )";
												} 
												?>
											</td>
										</tr>
										<?php	
									}
								}
								?>
							</tbody>
						</table>
						<div class="row">
							<div class="col-xs-12 text-right" id="action-buttons">
								<button class="btn btn-danger btn-action" data-action="discard">Discard</button>
								<button class="btn btn-primary btn-action" data-action="submit">Submit</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>