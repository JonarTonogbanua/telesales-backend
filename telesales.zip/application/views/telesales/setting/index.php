<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-10">
		<h2>Settings</h2>
		<ol class="breadcrumb">
			<li>
				<a href="<?php echo base_url('telesales/dashboard'); ?>">Home</a>
			</li>
			<li class="active">
				<strong>Settings</strong>
			</li>
		</ol>
	</div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
	<div class="row">
		<div class="col-xs-12 col-md-6">
			<label for="">Timer Settings</label>
			<form role="form" action="<?php echo base_url('telesales/update_grace_period'); ?>" class="form-horizontal" id="frm-grace-update">
				<div class="form-group">
                    <div class="row">
                       <label class="col-sm-2 control-label">Grace Period</label>
                       <div class="col-sm-10">
                           <div class="input-group m-b">
                              <input type="number" placeholder="<?php echo $settings->grace_period; ?>" value="<?php echo $settings->grace_period; ?>" class="form-control" min="3" name="graceperiod">
                              <span class="input-group-addon">seconds</span> 
                          </div>
                      </div>
                  </div>
              </div>
              <div class="form-group">
               <div class="pull-right">
                   <button type="submit" class="btn btn-primary btn-save"> Save </button>
               </div>
           </div>
       </form>
   </div>
</div>
<div class="row">
    <div class="col-xs-12 col-md-6">
     <label for="">Call Priority Settings</label>
     <div class="wrapper wrapper-content  animated fadeInRight">
        <div class="row" id="sortable-view">
            <div class="dd" id="nestable">
                <ol class="dd-list">
                    <li class="dd-item" data-id="1">
                        <div class="dd-handle">Welcome Call</div>
                    </li>
                    <li class="dd-item" data-id="2">
                        <div class="dd-handle">Reactivation Call</div>
                    </li>
                    <li class="dd-item" data-id="3">
                        <div class="dd-handle">Retention Call</div>
                    </li>
                </ol>
            </div>

        </div>
    </div>
</div>
</div>