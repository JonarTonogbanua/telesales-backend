<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-10">
		<h2>Calls</h2>
		<ol class="breadcrumb">
			<li>
				<a href="<?php echo base_url('telesales/dashboard'); ?>">Home</a>
			</li>
			<li>
				<a href="javascript:void(0);">Call List</a>
			</li>
			<li class="active">
				<strong>On Queue</strong>
			</li>
		</ol>
	</div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
	<div class="row">
		<div class="col-xs-12">
			<div class="ibox float-e-margins">
				<div class="ibox-content">
					<form role="form" action="<?php echo base_url('telesales/calls'); ?>" class="form-inline">
						<div class="form-group">
							<select name="country" id="" class="form-control">
								<option selected disabled>Select Country</option>
								<option  value="">All</option>
								<option  value="vn">Vietnam</option>
								<option  value="my">Malaysia</option>
								<option  value="th">Thailand</option>
								<option  value="cn">China</option>
							</select>
						</div>
						<div class="form-group">
							<select name="calltype" id="" class="form-control">
								<option selected disabled>Select Call Type</option>
								<option  value="">All</option>
								<option  value="welcome">Welcome Call</option>
								<option  value="retention">Retention Call</option>
								<option  value="reactivation">Reactivation Call</option>
							</select>
						</div>
						<div class="form-group">
							<button class="btn mt5">Submit</button>
						</div>
					</form>
					<table class="table table-striped table-bordered table-hover dataTables" >
						<thead>
							<tr >
								<th class="text-center"><input type="checkbox" style="pointer-events: none;display: absolute;z-index: -1;"></th>
								<th>LOGIN ID</th>
								<th>USER ID</th>
								<th>NAME</th>
								<th>EMAIL</th>
								<th>PHONE</th>
								<th>AGENT</th>
								<th>PRODUCT</th>
								<th>CAMPAIGN</th>
								<th>CALL TYPE</th>
							</tr>
						</thead>
						<tbody>
							<?php  
								if($on_queue){
									foreach ($on_queue as $row) {
							?>
							<tr transaction-id="<?php echo $row->trans_id; ?>">
								<td></td>
								<td><?php echo $row->login_id; ?></td>
								<td><?php echo $row->user_id; ?></td>
								<td><?php echo $row->player_name; ?></td>
								<td><?php echo $row->player_email; ?></td>
								<td><?php echo $row->player_phone; ?></td>
								<td><?php echo strtoupper($row->user_nickname); ?></td>
								<td><?php echo $row->player_product; ?></td>
								<td><?php echo strtoupper($row->campaign_title); ?></td>
								<td><?php echo strtoupper($row->call_type ); ?> CALL</td>
							</tr>
							<?php
								}
							}
							?>
						</tbody>
					</table>
					<form action="" class="form-inline">
					<label for="">With selected : </label>
					<!-- <select name="" id="" class="form-control">
						<option disabled selected>Select Action</option>
						<option value="drop">Drop</option>
					</select> -->
					<input type="button" value="DROP" id="wselected" class="btn btn-danger margint" style="margin-top:5px;">
					</form>
				</div>
			</div>
		</div>
	</div>
</div>