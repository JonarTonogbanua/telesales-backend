<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Telesales extends CI_Controller {

	public function __construct(){
		parent::__construct();
		if(!$this->session->has_userdata('ck_name')){
			header('location:'.base_url());
		}elseif($this->session->userdata('subsegment') != "telesales"){
			show_404();
		}
	}
	//PAGES FUNCTIONS
	public function index(){
		$this->dashboard();
	}
	public function dashboard(){
		$country = "";
		$data['lead_graph'] = $this->_lead_graph();
		$data['lead_def_graph'] = $this->_lead_graph(true);
		$data['avg_call'] = $this->general->get_average_call('CALL',$country);
		$data['avg_break'] = $this->general->get_average_call('BREAK',$country);
		$data['long_call'] = $this->general->get_ceil_floor('MAX','CALL');
		$data['long_break'] = $this->general->get_ceil_floor('MAX','BREAK');
		$this->load->view('globals/header');
		$this->load->view('telesales/navigation/index');
		$this->load->view('telesales/dashboard/index', $data);
		$this->load->view('telesales/scripts/dashboard');
		$this->load->view('globals/footer');
	}public function upload_revision(){
		echo "<script src=" .base_url('assets/js/jquery-3.1.1.min.js') ."></script>";
		echo "<div id='queue'>Updating record(s) . . .</div>";
		if ( isset($_FILES["csvfile"]['tmp_name'])){
			$handle = fopen($_FILES['csvfile']['tmp_name'], "r");
			$delimiter = $this->_getFileDelimiter($_FILES['csvfile']['tmp_name'], 2);
			$data = fgetcsv($handle, 1000, "$delimiter");
			$counter = 0;
			$firstline = 0;
			$this->db->trans_start();
			while (($data = fgetcsv($handle, 1000, "$delimiter")) !== FALSE) {
				if(strtoupper($data[8]) == "YES"){
					$this->general->update_player_info($data);
				}
			} 
			$this->db->trans_complete();
			fclose($handle);
			echo "<script>$('#queue').html('Redirecting...');</script>";
			$this->session->set_flashdata('success', "Upload success! Changes has been saved.");
			echo '<script>setTimeout(function(){location.href =" '.base_url('telesales/players/revisions/').'"},1000);</script>';
		}
	}
	public function upload_data(){
		$tablename = $this->general->create_today_table();
		$this->load->library('form_validation');
		$this->form_validation->set_rules('country', 'COUNTRY', 'in_list[vn,cn,my,th]|xss_clean|trim|required');
		$this->form_validation->set_rules('calltype', 'CALL TYPE', 'in_list[welcome,retention,reactivation]|xss_clean|trim|required');
		if($this->input->post('calltype') == "retention"){
			$this->form_validation->set_rules('campaign-id', 'CAMPAIGN', 'callback_campaignid|xss_clean|trim|required');
		}
		if ($this->form_validation->run() == TRUE) {
			$insert_player_batch = array();
			$insert_temp_batch = array();
			if ( file_exists($_FILES["csvfile"]['tmp_name']) || is_uploaded_file($_FILES["csvfile"]['tmp_name'])){
				echo "<script src=" .base_url('assets/js/jquery-3.1.1.min.js') ."></script>";
				echo "<div id='queue'>Initializing process . . .</div>";
				$country = $this->input->post('country');
				$calltype = $this->input->post('calltype');
				$campaign = $this->input->post('campaign-id');

				$handle = fopen($_FILES['csvfile']['tmp_name'], "r");
				$delimiter = $this->_getFileDelimiter($_FILES['csvfile']['tmp_name'], 2);
				$data = fgetcsv($handle, 1000, "$delimiter");
				$counter = 0;
				$firstline = 0;
				while (($data = fgetcsv($handle, 1000, "$delimiter")) !== FALSE) {
					$counter++;
					$result = $this->general->check_data($data, $country, $calltype, $campaign);
					if(count($result) == 2){
						if($result[0]){
							array_push($insert_player_batch, $result[0]);
						}
						if($result[1]){
							array_push($insert_temp_batch, $result[1]);
						}
					}else{
						if($result[0]){
							array_push($insert_temp_batch, $result[0]);
						}
					}
					echo "<script>$('#queue').html('Processing entry #".$counter." , please wait...');</script>";
				} 
				fclose($handle);
				echo "<script>$('#queue').html('Saving player info...');</script>";
				$this->db->trans_start();
				if($insert_player_batch){
					$this->db->insert_batch('tbl_player_info', $insert_player_batch);
					echo "<script>$('#queue').html('Player info saved...');</script>";
				}
				if($insert_temp_batch){
					$this->db->insert_batch("tbl_temp_transaction", $insert_temp_batch);
					echo "<script>$('#queue').html('Temporary file processing done...');</script>";
				}
				$this->db->trans_complete();
				echo "<script>$('#queue').html('Redirecting...');</script>";
				$this->session->set_flashdata('success', "Upload success! Please review the call list before saving to the database.");
				echo '<script>setTimeout(function(){location.href =" '.base_url('telesales/wizard').'"},1000);</script>';
			}else{
				header('location:'.base_url('telesales/wizard'));
			}
		} else{
			$this->session->set_flashdata('errors', validation_errors("<li>", "</li>"));
			header('location:'.base_url('telesales/wizard'));
		}
	}
	public function wizard(){
		$data['temporary_record'] = $this->general->get_temporary_record();
		$this->load->view('globals/header');
		$this->load->view('telesales/navigation/index', $data);
		$this->load->view('telesales/wizard/index', $data);
		$this->load->view('telesales/scripts/wizard');
		$this->load->view('globals/footer');
	}
	public function calls(){
		$country = $this->input->get('country');
		$calltype = $this->input->get('calltype');
		$data['on_queue'] = $this->general->get_onqueue($country, $calltype);
		$this->load->view('globals/header');
		$this->load->view('telesales/navigation/index', $data);
		$this->load->view('telesales/calls/index', $data);
		$this->load->view('telesales/scripts/call');
		$this->load->view('globals/footer');
	}
	public function players(){
		$data['player_list'] = $this->general->get_player_list();
		$data['players_revision'] = $this->general->get_revision_list();
		$this->load->view('globals/header');
		$this->load->view('telesales/navigation/index', $data);
		if($this->uri->segment(3) == "revisions"){
			$this->load->view('telesales/players/revision', $data);
		}elseif($this->uri->segment(3) == "list"){
			$this->load->view('telesales/players/index', $data);
		}
		
		$this->load->view('telesales/scripts/players');
		$this->load->view('globals/footer');
	}
	public function archives(){
		$country = $this->input->get('country');
		$calltype = $this->input->get('calltype');
		$data['transaction_archives'] = $this->general->get_transaction_archives();
		$this->load->view('globals/header');
		$this->load->view('telesales/navigation/index', $data);
		$this->load->view('telesales/archives/index', $data);
		$this->load->view('telesales/scripts/archives');
		$this->load->view('globals/footer');
	}
	public function accounts(){
		$data['telesales_accounts'] = $this->general->get_telesales_account();
		$this->load->view('globals/header');
		$this->load->view('telesales/navigation/index', $data);
		$this->load->view('telesales/accounts/index', $data);
		$this->load->view('telesales/accounts/modals');
		$this->load->view('telesales/scripts/accounts');
		$this->load->view('globals/footer');
	}
	public function redirect_to_campaigns(){
		header('location:'. base_url('telesales/campaign-management/campaigns'));
		die();
	}
	public function campaigns(){
		$call_type = $this->input->get('calltype');
		$product = $this->input->get('product');
		$country = $this->input->get('country');
		$cid = $this->input->get('cid');
		$data['campaign_lists'] = $this->general->get_campaigns($call_type, $product, $country, $cid);
		$this->load->view('globals/header');	
		$this->load->view('telesales/navigation/index', $data);
		$this->load->view('telesales/campaign/campaigns', $data);
		$this->load->view('telesales/campaign/modals');
		$this->load->view('telesales/scripts/campaign');
		$this->load->view('globals/footer');
	}
	public function promotions(){
		$data['archives'] = $this->general->get_archive_list();
		$call_type = $this->input->get('calltype');
		$product = $this->input->get('product');
		$country = $this->input->get('country');
		$data['promotion_lists'] = $this->general->get_promotions($call_type, $product, $country);
		$data['campaign_dropdown'] = $this->general->get_campaigns("","", "");
		$this->load->view('globals/header');
		$this->load->view('telesales/navigation/index', $data);
		$this->load->view('telesales/promotion/promotions', $data);
		$this->load->view('telesales/promotion/modals', $data);
		$this->load->view('telesales/scripts/promotions');
		$this->load->view('globals/footer');
	}
	public function settings(){
		$data['settings'] = $this->general->get_settings();
		$this->load->view('globals/header');
		$this->load->view('telesales/navigation/index', $data);
		$this->load->view('telesales/setting/index', $data);
		$this->load->view('telesales/scripts/setting');
		$this->load->view('globals/footer');
	}
	public function redirect_to_calls(){
		header('location:'. base_url('reports/calls'));
		die();
	}
	public function report_calls(){
		$data['lead_graph'] = $this->_lead_graph();
		$data['call_graph'] = $this->_get_activity_graph("CALL");
		$data['break_graph'] = $this->_get_activity_graph("BREAK");
		$data['cr_bdown'] = $this->_get_activity_graph("BREAK", "CR BREAK");
		$data['meal_bdown'] = $this->_get_activity_graph("BREAK", "MEAL BREAK");
		$data['meeting_bdown'] = $this->_get_activity_graph("BREAK", "MEETING");
		$country ="";
		$countries=array('vn','cn','th','my');
		if (in_array($this->input->get('country'), $countries)) {
			$country = $this->input->get('country');
		}
		$data['avg_call'] = $this->general->get_average_call('CALL',$country);
		$data['avg_break'] = $this->general->get_average_call('BREAK',$country);
		$data['long_call'] = $this->general->get_ceil_floor('MAX','CALL', $country);
		$data['long_break'] = $this->general->get_ceil_floor('MAX','BREAK', $country);
		$data['short_call'] = $this->general->get_ceil_floor('MIN','CALL', $country);
		$data['short_break'] = $this->general->get_ceil_floor('MIN','BREAK', $country);
		$this->load->view('globals/header');
		$this->load->view('telesales/navigation/index', $data);
		$this->load->view('telesales/report/calls');
		$this->load->view('telesales/scripts/report_calls');
		$this->load->view('globals/footer');
	}
	public function report_agents(){
		$data['archives'] = $this->general->get_archive_list();
		$data['avg_call'] = $this->general->get_average_call('CALL');
		$data['avg_break'] = $this->general->get_average_call('BREAK');
		$this->load->view('globals/header');
		$this->load->view('telesales/navigation/index', $data);
		$this->load->view('telesales/report/agents');
		$this->load->view('telesales/scripts/report_player');
		$this->load->view('globals/footer');
	}
	public function test2(){
	}
	//END PAGES FUNCTIONS
	//PRIVATE FUNCTIONS
	public function _lead_graph($get_done = null){
		$countries = array('cn', 'my', 'vn', 'th');
		$dates = array('hour','day', 'month', 'year');
		$types = array('welcome', 'retention', 'reactivation');
		$by_date = "day";
		$country = "";
		$type = "";
		$agentid = NULL;
		$return = array();

		if (in_array($this->input->get('country'), $countries)) {
			$country = strtolower($this->input->get('country'));
		}
		if (in_array($this->input->get('showby'), $dates)) {
			$by_date = strtolower($this->input->get('showby'));
		}
		if (in_array($this->input->get('type'), $types)) {
			$type = strtolower($this->input->get('type'));
		}
		if ($this->input->get('agent') != "") {
			$agentid = strtolower($this->input->get('agent'));
		}
		if($get_done){
			$return = $this->general->get_lead_graph($country, $by_date, $type, $agentid, true);
		}else{
			$return = $this->general->get_lead_graph($country, $by_date, $type, $agentid);
		}
		return $return;
	}
	public function _get_activity_graph($type, $reason = null){
		$countries = array('cn', 'my', 'vn', 'th');
		$dates = array('hour','day', 'month', 'year');
		$by_date = "day";
		$country = "";
		$agentid = NULL;

		if (in_array($this->input->get('country'), $countries)) {
			$country = strtolower($this->input->get('country'));
		}
		if (in_array($this->input->get('showby'), $dates)) {
			$by_date = strtolower($this->input->get('showby'));
		}
		if ($this->input->get('agent') != "") {
			$agentid = strtolower($this->input->get('agent'));
		}
		$return = $this->general->get_activity_graph($country, $by_date, $type, $agentid, $reason);
		return $return;
	}
	function _getFileDelimiter($file, $checkLines = 2){
		$file = new SplFileObject($file);
		$delimiters = array(
			',',
			'\t',
			';',
			'|',
			':'
			);
		$results = array();
		$i = 0;
		while($file->valid() && $i <= $checkLines){
			$line = $file->fgets();
			foreach ($delimiters as $delimiter){
				$regExp = '/['.$delimiter.']/';
				$fields = preg_split($regExp, $line);
				if(count($fields) > 1){
					if(!empty($results[$delimiter])){
						$results[$delimiter]++;
					} else {
						$results[$delimiter] = 1;
					}   
				}
			}
			$i++;
		}
		$results = array_keys($results, max($results));
		return $results[0];
	}
	function _getseconds($time){
		$time = explode(':', $time);
		return ($time[0]*3600) + ($time[1]*60);
	}
	function _gettimestamp($rawdate){
		$date = explode("/", $rawdate);
		$time = strtotime( $date[1] ."-" .$date[0] ."-" .$date[2]);

		return $time;
	}
	public function promocode($promocode){
		$campaignid = $this->input->post('campaign-id');
		$result = $this->general->check_promocode($campaignid, $promocode);
		if($result){
			return TRUE;
		}
		else{
			$this->form_validation->set_message('promocode', 'Promo code already taken.');
			return FALSE;
		}
	}
	public function campaignid(){
		$campaign_id = $this->input->post('campaign-id');
		$result = $this->general->get_campaign_info($campaign_id);
		if($result){
			return TRUE;
		}
		else{
			$this->form_validation->set_message('campaign-id', 'Campaign doesn\'t exist.');
			return FALSE;
		}
	}
	public function promoid(){
		$promo_id = $this->input->post('edit-id');
		$result = $this->general->get_promo_info($promo_id);
		if($result){
			return TRUE;
		}
		else{
			$this->form_validation->set_message('edit-id', 'Promo doesn\'t exist.');
			return FALSE;
		}
	}
	//END PRIVATE FUNCTIONS
	//AJAX FUNCTIONS
	public function drop_call_item(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('tids[]', 'PARAMETER', 'xss_clean|required');
		if ($this->form_validation->run() == TRUE) {
			$id = $this->input->post('tids');
			$this->general->drop_call_item($id);
		}else{
			die();
		}
		$json = array('result' => true);
		echo json_encode($json);
	}
	public function set_call_priority(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('id', 'ID', 'in_list[1,2,3]|xss_clean|trim|required');
		$this->form_validation->set_rules('position', 'position', 'in_list[1,2,3]|xss_clean|trim|required');
		if ($this->form_validation->run() == TRUE) {
			$id = $this->input->post('id');
			$position = $this->input->post('position');
			$this->general->set_call_priority($id, $position);
		}else{
			die();
		}
	}
	public function accounts_submit(){
		$jsonresponse = array();
		$this->load->library('form_validation');
		$this->form_validation->set_rules('username', 'USERNAME', 'xss_clean|trim|required|min_length[5]|max_length[20]|alpha_numeric');
		$this->form_validation->set_rules('nickname', 'NICKNAME', 'xss_clean|trim|required|min_length[3]|max_length[15]|alpha_numeric');
		$this->form_validation->set_rules('password', 'PASSWORD', 'xss_clean|trim|required|min_length[8]|max_length[50]');
		$this->form_validation->set_rules('rpassword', 'REPEAT PASSWORD', 'matches[password]|xss_clean|trim|required');
		$this->form_validation->set_rules('country', 'COUNTRY', 'in_list[my,vi,th,cn]|trim|required');
		$this->form_validation->set_rules('language', 'SYSTEM LANGUAGE', 'in_list[en,vi,th,cn]|trim|required');

		if ($this->form_validation->run() == TRUE) {
			$encryption = $this->general->_encryption_key();
			$data['user_id'] = uniqid();
			$data['user_name'] = "tls" . strtolower($this->input->post('username', true));
			$data['user_nickname'] = $this->input->post('nickname', true);
			$data['user_password'] =  sha1(str_rot13($this->input->post('password', true) . $encryption));
			$data['user_status'] = 0;
			$data['user_country'] =  $this->input->post('country', true);
			$data['user_language'] =  $this->input->post('language', true);
			$data['date_added'] = time();
			$data['role'] =  2;

			$jsonresponse = $this->general->account_submit($data);

		} else {
			$errors = explode("\n", validation_errors());
			$jsonresponse = array(
				"result" => 'false',
				"message" => $errors,
				"type" => "error",
				);
		}
		echo json_encode($jsonresponse);
	}
	public function get_telesales_info(){
		$jsonresponse = false;
		$this->load->library('form_validation');
		$this->form_validation->set_rules('userid', 'USER ID', 'xss_clean|trim|required|min_length[5]|max_length[20]|alpha_numeric');

		if ($this->form_validation->run() == TRUE) {
			$user_id = $this->input->post('userid', true);

			$jsonresponse = $this->general->get_telesales_info($user_id);
		}
		echo json_encode($jsonresponse);
	}
	public function get_campaign_info(){
		$jsonresponse = false;
		$this->load->library('form_validation');
		$this->form_validation->set_rules('campaignid', 'CAMPAIGN ID', 'xss_clean|trim|required|min_length[5]|max_length[20]|alpha_numeric');

		if ($this->form_validation->run() == TRUE) {
			$campaign_id = $this->input->post('campaignid', true);
			$jsonresponse = $this->general->get_campaign_info($campaign_id);
		}
		echo json_encode($jsonresponse);
	}
	public function get_country_campaign(){
		$result = array();
		if($this->input->post('country_code')){
			$country_code = $this->input->post('country_code');
			$result = $this->general->get_campaigns("retention","", $country_code);
		}else{
			die();
		}
		echo json_encode($result);
	}
	public function get_promo_info(){
		$jsonresponse = false;
		$this->load->library('form_validation');
		$this->form_validation->set_rules('promoid', 'PROMO ID', 'xss_clean|trim|required|alpha_numeric');
		if($this->form_validation->run() == TRUE){
			$promoid = $this->input->post('promoid', true);
			$jsonresponse = $this->general->get_promo_info($promoid);
		}
		echo json_encode($jsonresponse);
	}
	public function campaign_submit(){
		$jsonresponse = array();
		$this->load->library('form_validation');
		$this->form_validation->set_rules('product', 'PRODUCT', 'in_list[poker,casino]|xss_clean|trim|required');
		$this->form_validation->set_rules('country', 'COUNTRY', 'in_list[my,vn,th,cn]|xss_clean|trim|required');
		$this->form_validation->set_rules('title', 'CAMPAIGN TITLE', 'xss_clean|trim|required');
		$this->form_validation->set_rules('calltype', 'CALL TYPE', 'in_list[welcome,retention,reactivation]|xss_clean|trim|required');
		$this->form_validation->set_rules('start-datedate', 'START DATE', 'xss_clean|trim|required');
		$this->form_validation->set_rules('start-datetime', 'START TIME', 'xss_clean|trim|required');
		$this->form_validation->set_rules('end-datedate', 'END DATE', 'xss_clean|trim|required');
		$this->form_validation->set_rules('end-datetime', 'END TIME', 'xss_clean|trim|required');
		$this->form_validation->set_rules('tnc', 'TERMS AND CONDITIONS', 'required');

		if ($this->form_validation->run() == TRUE) {
			$data = array(
				'campaign_id' => "ci" .uniqid(),
				'campaign_title' => strtolower($this->input->post('title', true)),	
				'call_type' => strtolower($this->input->post('calltype', true)),	
				'campaign_country' => strtolower($this->input->post('country', true)),	
				'campaign_tnc' => $this->input->post('tnc', true),	
				'product_type' => $this->input->post('product', true),	
				'campaign_start_date' => intval($this->_gettimestamp($this->input->post('start-datedate'))) + intval($this->_getseconds($this->input->post('start-datetime'))),	
				'campaign_end_date' => intval($this->_gettimestamp($this->input->post('end-datedate'))) + intval($this->_getseconds($this->input->post('end-datetime'))),	
				);

			$jsonresponse = $this->general->campaign_submit($data);
		} else {
			$errors = explode("\n", validation_errors());
			$jsonresponse = array(
				"result" => 'false',
				"title" => 'Form Error',
				"message" => $errors,
				"type" => "error",
				);
		}
		echo json_encode($jsonresponse);
	}
	public function submit_edit_promo(){
		$jsonresponse = array();
		$this->load->library('form_validation');
		$this->form_validation->set_rules('edit-id', 'PROMO ID' , 'callback_promoid|xss_clean|trim|required');
		$this->form_validation->set_rules('edit-title', 'PROMO TITLE' , 'xss_clean|trim|required');
		$this->form_validation->set_rules('edit-link', 'PROMO LINk' , 'xss_clean|trim|required');
		$this->form_validation->set_rules('edit-tnc', 'TERMS AND CONDITIONS' , 'xss_clean|trim');
		$this->form_validation->set_rules('edit-iscustom', 'CUSTOM TNC' , 'xss_clean|trim');
		$this->form_validation->set_rules('edit-notes', 'NOTES' , 'max_length[1000]|xss_clean|trim');
		$this->form_validation->set_rules('edit-status', 'STATUS' , 'in_list[0,1]|xss_clean|trim');
		if ($this->form_validation->run() == TRUE) {
			$data = array(
				"promo_title" => strtoupper($this->input->post('edit-title',true)),
				"promo_link" => $this->input->post('edit-link'),
				"custom_tnc" => $this->input->post('edit-tnc'),
				"is_tnc_custom" => (int)(bool)$this->input->post('edit-iscustom'),
				"promo_notes" => $this->input->post('edit-notes'),
				"promo_status" => $this->input->post('edit-status'),
				);
			$promoid = $this->input->post('edit-id');

			$jsonresponse = $this->general->submit_edit_promotion($data, $promoid);
		} else {
			$errors = explode("\n", validation_errors());
			$jsonresponse = array(
				"result" => 'false',
				"title" => "Form error",
				"message" => $errors,
				"type" => "error",
				);
		}
		echo json_encode($jsonresponse);
	}
	public function submit_promotion(){
		$jsonresponse = array();
		$this->load->library('form_validation');
		$this->form_validation->set_rules('campaign-id', 'CAMPAIGN ID', 'callback_campaignid|alpha_numeric|xss_clean|trim|required');
		$this->form_validation->set_rules('promocode', 'PROMO CODE', 'callback_promocode|alpha_numeric|xss_clean|trim|required');
		$this->form_validation->set_rules('promotitle', 'PROMO TITLE', 'xss_clean|trim|required');
		$this->form_validation->set_rules('promolink', 'PROMO LINK', 'xss_clean|trim|required');
		$this->form_validation->set_rules('customtnc', 'CUSTOM TERMS AND CONDITIONS', 'xss_clean|trim');
		$this->form_validation->set_rules('iscustom', 'HAS CUSTOM', 'xss_clean|trim');
		$this->form_validation->set_rules('notes', 'ADDITIONAL NOTES', 'xss_clean|trim');
		if ($this->form_validation->run() == TRUE) {
			$data = array(
				"promo_id" => "pc".uniqid(),
				"promo_code" => strtoupper($this->input->post('promocode', true)),
				"promo_title" => strtoupper($this->input->post('promotitle',true)),
				"campaign_id" => $this->input->post('campaign-id', true),
				"promo_link" => $this->input->post('promolink'),
				"custom_tnc" => $this->input->post('customtnc'),
				"is_tnc_custom" => (int)(bool)$this->input->post('iscustom'),
				"promo_notes" => $this->input->post('notes'),
				"promo_status" => 1,
				"date_added" => time(),
				);
			$jsonresponse = $this->general->submit_promotion($data);
		} else {
			$errors = explode("\n", validation_errors());
			$jsonresponse = array(
				"result" => 'false',
				"title" => "Form error",
				"message" => $errors,
				"type" => "error",
				);
		}
		echo json_encode($jsonresponse);
	}

	public function submit_edit_campaign(){
		$jsonresponse = array();
		$this->load->library('form_validation');
		$this->form_validation->set_rules('edit-id', 'CID', 'xss_clean|trim|required');
		$this->form_validation->set_rules('edit-isdefault', 'DEFAULT', 'in_list[0,1]|xss_clean|trim|required');
		$this->form_validation->set_rules('edit-product', 'PRODUCT', 'in_list[poker,casino]|xss_clean|trim|required');
		$this->form_validation->set_rules('edit-country', 'COUNTRY', 'in_list[my,vn,th,cn]|xss_clean|trim|required');
		$this->form_validation->set_rules('edit-title', 'CAMPAIGN TITLE', 'xss_clean|trim|required');
		if($this->input->post('edit-isdefault') == 0){
			$this->form_validation->set_rules('edit-status', 'STATUS', 'in_list[0,1]|xss_clean|trim|required');
			$this->form_validation->set_rules('edit-startdate', 'START DATE', 'xss_clean|trim|required');
			$this->form_validation->set_rules('edit-starttime', 'START TIME', 'xss_clean|trim|required');
			$this->form_validation->set_rules('edit-enddate', 'END DATE', 'xss_clean|trim|required');
			$this->form_validation->set_rules('edit-endtime', 'END TIME', 'xss_clean|trim|required');
		}
		$this->form_validation->set_rules('edit-tnc', 'TERMS AND CONDITIONS', 'required');

		if ($this->form_validation->run() == TRUE) {
			$cid = $this->input->post('edit-id');
			$data = array(
				'campaign_title' => strtolower($this->input->post('edit-title', true)),	
				'campaign_country' => strtolower($this->input->post('edit-country', true)),	
				'campaign_tnc' => $this->input->post('edit-tnc', true),	
				'product_type' => $this->input->post('edit-product', true),	
				);
			if($this->input->post('edit-isdefault') == 0){
				$data['is_enabled'] = $this->input->post('edit-status', true);
				$data['campaign_start_date'] = intval($this->_gettimestamp($this->input->post('edit-startdate'))) + intval($this->_getseconds($this->input->post('edit-starttime')));
				$data['campaign_end_date'] = intval($this->_gettimestamp($this->input->post('edit-enddate'))) + intval($this->_getseconds($this->input->post('edit-endtime')));
			}
			$jsonresponse = $this->general->campaign_edit_submit($data, $cid);
		} else {
			$errors = explode("\n", validation_errors());
			$jsonresponse = array(
				"result" => 'false',
				"title" => "Form error",
				"message" => $errors,
				"type" => "error",
				);
		}
		echo json_encode($jsonresponse);
	}
	
	public function trash_campaign(){
		$jsonresponse = array();
		$this->load->library('form_validation');
		$this->form_validation->set_rules('campaignid', 'CAMPAIGN ID', 'xss_clean|trim|required');
		if ($this->form_validation->run() == TRUE) {
			$campaign_id = $this->input->post('campaignid', true);
			$jsonresponse = $this->general->trash_campaign($campaign_id);
		}else{
			$jsonresponse = array(
				"result" => 'false',
				"title" => 'Action failed',
				"message" => 'required parameter missing',
				"type" => "error",
				);
		}
		echo json_encode($jsonresponse);
	}
	public function action_to_temp(){
		$jsonresponse = array();
		$this->load->library('form_validation');
		$this->form_validation->set_rules('action', 'ACTION', 'in_list[discard,submit]|required');
		if ($this->form_validation->run() == TRUE) {
			$action = $this->input->post('action', true);
			$jsonresponse = $this->general->action_to_temp($action);
			$jsonresponse = array(
				"result" => 'true',
				"title" => 'Action success',
				"message" => 'All data has been '.$action,
				"type" => "success",
				);
		}else{
			$jsonresponse = array(
				"result" => 'false',
				"title" => 'Action failed',
				"message" => 'required parameter missing',
				"type" => "error",
				);
		}
		echo json_encode($jsonresponse);
	}
	public function benchmark(){
		
	}
	public function get_agent_by_country(){
		$jsonresponse = array();
		$this->load->library('form_validation');
		$this->form_validation->set_rules('country', 'PARAM', 'in_list[cn,vn,th,my]|required');

		if ($this->form_validation->run() == TRUE) {
			$country = $this->input->post('country', true);
			$agents = $this->general->get_agent_by_country($country);
			$jsonresponse = array(
				"result" => true,
				"agents" => $agents,
				);
		}else{
			$jsonresponse = array(
				"result" => 'false',
				"agents" => NULL,
				);
		}
		echo json_encode($jsonresponse);
	}
	public function get_live_progress(){
		$jsonresponse = $this->general->get_progress();
		echo json_encode($jsonresponse);
	}
	public function get_live_activity(){
		$jsonresponse = $this->general->get_activities();
		echo json_encode($jsonresponse);
	}
	public function update_grace_period(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('graceperiod', 'GRACE PERIOD', 'integer|required');
		$jsonresponse = array();
		if($this->form_validation->run() == TRUE) {
			$this->general->update_grace_period($this->input->post('graceperiod'));
			$jsonresponse = array(
				"result" => true,
				"message" => "Changes has been saved!",
				);
		} else {
			$errors = explode("\n", validation_errors());
			$jsonresponse = array(
				"result" => 'false',
				"message" => $errors,
				);
		}
		echo json_encode($jsonresponse);
	}
	public function delete_promotion(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('promo_id', 'PROMO ID', 'xss_clean|required');
		$jsonresponse = array();
		if($this->form_validation->run() == TRUE) {
			$promo_id = $this->input->post('promo_id', true);
			$res = $this->general->delete_promotion($promo_id);
			$jsonresponse = array(
				"result" => $res,
				"message" => "Promotion deleted!",
				);
		}else{
			$jsonresponse = array(
				"result" => false,
				"message" => "Paramater missing!",
				);
		}
		echo json_encode($jsonresponse);
	}
	//END AJAX FUNCTIONS
}
