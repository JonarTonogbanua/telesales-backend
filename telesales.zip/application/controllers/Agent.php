<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Agent extends CI_Controller {

	public function __construct(){
		parent::__construct();

		$this->general->create_today_table();
		if(!$this->session->has_userdata('ck_name')){
			header('location:'.base_url());
		}elseif($this->session->userdata('subsegment') != "agent"){
			show_404();
		}
	}
	//PAGES FUNCTIONS
	public function index(){
		$this->lang->load('main', "en");
		$current = $this->general->_get_current_transaction();
		$this->load->view('globals/header');

		$data['quick_count'] = $this->general->get_call_stat_count();
		$this->load->view('agent/navigation/index',$data);
		if($this->session->has_userdata('in_session') || $current){
			$data['on_queue'] = $this->general->agent_on_queue();
			$data['on_break'] = $this->general->is_on_break();
			$data['settings'] = $this->general->get_settings();
			$data['report_today'] = $this->general->get_today_report($this->session->userdata['ck_id']);

			if($data['on_break']){
				$this->load->view('agent/dashboard/resumebreak', $data);
			}else{
				if($data['on_queue']){
					$data['campaign_promos'] = $this->general->get_campaign_promo($data['on_queue']->campaign_id);
					$data['player_history'] = $this->general->player_history();
					$this->load->view('agent/dashboard/index', $data);
					$this->load->view('agent/dashboard/modals', $data);
				}else{
					$this->general->activity_stamp("Waiting Call");
					$this->load->view('agent/dashboard/endsession', $data);
				}
			}
		}else{
			$this->load->view('agent/dashboard/nosession');
		}
		
		$this->load->view('agent/scripts/main');
		$this->load->view('globals/footer');
	}

	public function start_session(){
		$this->general->activity_stamp("Logged In");
		$datacookies = array(
			'in_session' => 1
			);
		$this->session->set_userdata($datacookies);
		header('location:'.base_url('agent'));
	}
	public function tests(){
		$res = $this->general->agent_on_queue();
		var_dump($res[0]);
	}
	public function submit_transaction_result(){
		
		$jsonresponse = array();
		$this->load->library('form_validation');
		$this->form_validation->set_rules('result', 'Result', 'in_list[reached,unreached,invalid]|xss_clean|trim|required');
		if ($this->input->post('result') == "reached") {
			$this->form_validation->set_rules('type', 'TYPE', 'in_list[full conversation,busy,wrong person,hangup,harrass]|xss_clean|trim|required');
			$ttype = $this->input->post('type');
			if($ttype == "full conversation"){
				$this->form_validation->set_rules('action[]', 'ACTION', 'xss_clean|trim|required');
				$this->form_validation->set_rules('pref', 'LANGUAGE', 'in_list[en,cn,th,vn]xss_clean|trim');
			}elseif($ttype == "busy" || $ttype == "wrong person" || $ttype == "hangup"){
				$this->form_validation->set_rules('action', 'ACTION', 'in_list[dont call,call after]|xss_clean|trim|required');
				if($this->input->post('action') == "call after"){
					$this->form_validation->set_rules('number', 'NUMBER', 'integer|xss_clean|trim|required');
					$this->form_validation->set_rules('multiplier', 'TIME UNIT', 'in_list[1,60,3600,86400,604800]|xss_clean|trim|required');
				}
			}
		}elseif($this->input->post('result') == "unreached"){
			$this->form_validation->set_rules('type', 'TYPE', 'in_list[busy tone,unanswered]|xss_clean|trim|required');
			$ttype = $this->input->post('type');
			if($ttype == "unanswered" || $ttype == "busy tone" ){
				$this->form_validation->set_rules('action', 'ACTION', 'in_list[dont call,call after]|xss_clean|trim|required');
				if($this->input->post('action') == "call after"){
					$this->form_validation->set_rules('number', 'NUMBER', 'integer|xss_clean|trim|required');
					$this->form_validation->set_rules('multiplier', 'TIME UNIT', 'in_list[1,60,3600,86400,604800]|xss_clean|trim|required');
				}
			}
		}elseif($this->input->post('result') == "invalid"){
			$this->form_validation->set_rules('type', 'TYPE', 'in_list[invalid number]|xss_clean|trim|required');
		}
		$this->form_validation->set_rules('remarks', 'REMARKS', 'xss_clean|trim');
		if ($this->form_validation->run() == TRUE) {
			$current = $this->general->_get_current_transaction();

			$result = strtoupper($this->input->post('result'));
			$type = strtoupper($this->input->post('type'));
			$action = $this->input->post('action');
			if(is_array($this->input->post('action[]'))){
				$action = strtoupper(implode(", ", $this->input->post('action[]')));
			}
			$remarks = $this->input->post('remarks', true);
			$add_action = NULL;
			$message = "Transaction submitted!";
			$this->db->trans_start();

			if ($this->input->post('pref')) {
				$add_action = "preferred language " .$this->input->post('pref');
				$clanguage = $this->input->post('pref');
			}
			if($this->input->post('number') && $this->input->post('multiplier')){
				$reschedtime = intval($this->input->post('number')) * intval($this->input->post('multiplier'));
				$add_action = " " . round(($reschedtime / 60), 2) ." MINUTES";
				$message = $this->general->reschedule_call($current, $reschedtime);
				if($message == "hasdeal"){
					$jsonresponse = array(
						"result" => 'false',
						"title" => "Rescheduled Failed",
						"message" => "Player already took a deal!",
						"type" => "error",
					);
					echo json_encode($jsonresponse);
					die();
				}
			}
			if($this->input->post('action') == "dont call"){
				$message = $this->general->block_call($current);
			}
			$update = array(
				'handle_end_timestamp' => time(),
				'result' => $result,
				'type' => $type,
				'action' => $action,
				'add_action' => $add_action,
				'remarks' => $remarks,
				'is_fulfilled' => 1,
				'fulfilled_by' => $this->session->userdata('ck_name'),
			);

			$this->general->fulfill_transaction($update, $current);

			$this->db->trans_complete();
			$jsonresponse = array(
				"result" => 'true',
				"title" => "Action success",
				"message" => $message,
				"type" => "success",
				);
		} else {
			$errors = explode("\n", validation_errors());
			$jsonresponse = array(
				"result" => 'false',
				"title" => "Form error",
				"message" => $errors,
				"type" => "error",
				);
		}
		echo json_encode($jsonresponse);
		die();
	}
	function testest(){
		echo date("F d Y h:i A", "1501516800");
	}
	function submit_deal(){
		$jsonresponse = array();
		$this->load->library('form_validation');
		$this->form_validation->set_rules('promoid', 'PROMOID', 'xss_clean|trim|required');
		$this->form_validation->set_rules('interest', 'OPTION', 'in_list[deal,not interested]|xss_clean|trim|required');
		if ($this->form_validation->run() == TRUE) {
			$promoid = $this->input->post('promoid', true);
			$interest = $this->input->post('interest', true);

			$table = 'transaction_'.date("m_d_Y");
			$current = $this->general->_get_current_transaction();
			$transaction = (array) $this->general->get_transaction_info($current);
			$player_info = (array) $this->general->get_player_info($transaction);
			$data = array(
				'deal_id' => 'dl'.$player_info['player_loc'].uniqid(),
				'trans_id' => $current,
				'login_id' => $player_info['login_id'],
				'promo_id' => $promoid,
				'user_id' => $this->session->userdata('ck_id'),
				'country' => $player_info['player_loc'],
				'is_interest' => $interest,
				);
			
			$jsonresponse = $this->general->submit_deal($data, $player_info);
			$this->general->update_has_deal($interest, $transaction);
		} else {
			$errors = explode("\n", validation_errors());
			$jsonresponse = array(
				"result" => 'false',
				"title" => "Form error",
				"message" => $errors,
				"type" => "error",
				);
		}
		echo json_encode($jsonresponse);
	}

	function get_transaction_details(){
		$jsonresponse = array();
		$this->load->library('form_validation');
		$this->form_validation->set_rules('dataTrans', 'TRANSACTION', 'xss_clean|trim|required');
		if ($this->form_validation->run() == TRUE) {
			$trans_id = $this->input->post('dataTrans', true);
			$jsonresponse = $this->general->player_history($trans_id);
		} else {
			$errors = explode("\n", validation_errors());
			$jsonresponse = array(
				"result" => 'false',
				"title" => "Retrieving failed",
				"message" => "An error occured",
				"type" => "error",
				);
		}
		echo json_encode($jsonresponse);
	}
	function start_break(){
		$jsonresponse =  $this->general->start_break();
		echo json_encode($jsonresponse);
	}
	function end_break(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('pausetype', 'REASON', 'in_list[CR BREAK,MEAL BREAK,MEETING]|xss_clean|trim|required');
		if ($this->form_validation->run() == TRUE) {
			$pause_type = $this->input->post('pausetype', true);
			$jsonresponse =  $this->general->end_break($pause_type);
		} else {
			$errors = explode("\n", validation_errors());
			$jsonresponse = array(
					'result' => "false",
					'message' => $errors,
				);
		}
		echo json_encode($jsonresponse);
	}
	function submit_revision(){
		$this->load->library('form_validation');
		$field = $this->input->post('field');
		$new_value;
		if($field == "phone"){
			$this->form_validation->set_rules('phone', 'PHONE', 'is_numeric|xss_clean|trim');
			$field = "player_phone";
			$new_value = $this->input->post('phone', true);
		}elseif($field == "email"){
			$this->form_validation->set_rules('email', 'EMAIL', 'valid_email|xss_clean|trim');
			$new_value = $this->input->post('email', true);
			$field = "player_email";
		}
		if ($this->form_validation->run() == TRUE) {
			$jsonresponse = $this->general->submit_revision($field, $new_value);
		} else {
			$errors = explode("\n", validation_errors());
			$jsonresponse = array(
				"result" => 'false',
				"title" => "Form error",
				"message" => $errors,
				"type" => "error",
				);
		}
		echo json_encode($jsonresponse);
	}
	function review_deal(){
		$json = array(
			'result' => true,
			);
		$current = $this->general->_get_current_transaction();
		$hasdeal = $this->general-> get_transaction_info($current, true);
		$type = $this->input->post('type');
		if($hasdeal && $type == "full conversation"){
			$json['result'] = false;
		}
		echo json_encode($json);
	}
	function check_queue(){
		$jsonresponse = array(
			'have_queue' => false,
			);
		$result = $this->general->agent_on_queue();
		if($result){
			$jsonresponse['have_queue'] = true;
		}
		echo json_encode($jsonresponse);
	}
}