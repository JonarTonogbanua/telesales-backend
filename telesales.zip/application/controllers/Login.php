<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct(){
		parent::__construct();
		if($this->session->has_userdata('ck_name')){
			header('location:'.base_url($this->session->userdata('subsegment')));
		}
	}

	public function index(){
		$data = "HEY";
		$this->load->view('globals/header');
		$this->load->view('telesales/login/index',$data);
		$this->load->view('telesales/scripts/login');
		$this->load->view('globals/footer');
	}

	//AJAX FUNCTIONS
	public function submit(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('username', 'USERNAME', 'min_length[3]|xss_clean|trim|required');
		$this->form_validation->set_rules('password', 'PASSWORD', 'min_length[5]|xss_clean|trim|required');
		if ($this->form_validation->run() == TRUE) {
			$username = $this->input->post('username', true);
			$rawpassword = $this->input->post('password', true);

			$result = $this->general->login_submit($username, $rawpassword);
			$this->general->create_today_table();
			echo json_encode($result);
		} else {
			$error = array(
				'logged_in' => 0,
				'message' => '<strong>Username / Password required</strong>',
				'type' => 'warning',
				);
			echo json_encode($error);
		}
	}
	public function logout(){
		$update = array(
			'user_status' => 0,
			);
		if($this->session->has_userdata('ck_id')){
			$this->db->where('user_id', $this->session->userdata('ck_id'));
			$this->db->update('tbl_ts_users', $update);

			$this->general->activity_stamp("Logged Out");
			$this->session->sess_destroy();
			header('location:'.base_url());
			die();
		}else{
			header('location:'.base_url());
			die();
		}
	}
}
