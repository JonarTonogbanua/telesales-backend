<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class General extends CI_Model {

	function _encryption_key(){
		return "OqDkf6JNhiy7IzrieIFhd9PKm7wXEBtrdmg0cQK8";
	}
	function create_today_table(){
		$tablename = "transaction_".date("m_d_Y");
		$sql = "CREATE TABLE IF NOT EXISTS `".$tablename."` LIKE `tbl_transaction_prototype`;";
		$this->db->query($sql);

		$tablename2 = "trans_deals_".date("m_d_Y");
		$sql2 = "CREATE TABLE IF NOT EXISTS `".$tablename2."` LIKE `tbl_deals_prototype`;";
		$this->db->query($sql2);
		$insert = array(
			'entry_id' => 'ar'.uniqid(),
			'table_trans' => $tablename,
			'table_deals' => $tablename2,
			);
		$this->db->select('*');
		$this->db->where('table_trans', $tablename);
		$query = $this->db->get('tbl_transaction_archive');
		if($query->num_rows() == 0){
			$this->db->insert('tbl_transaction_archive', $insert);
		}
		return $tablename;
	}
	function get_archive_list(){
		$this->db->select('*');
		$this->db->from('tbl_transaction_archive');
		$this->db->order_by('entry_id', 'DESC');
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}
	function login_submit($username, $rawpassword){
		$return = array(
			'logged_in' => 0,
			'message' => "<strong>User not found</strong>",
			'type' => "error",
			);
		$encryption = $this->_encryption_key();
		$password =  sha1(str_rot13($rawpassword . $encryption));

		$this->db->select('*');
		$this->db->where('user_name' , $username);
		$this->db->where('user_password' , $password);
		$this->db->where('is_hidden' , 0);
		$this->db->join('tbl_roles', 'tbl_roles.roles_id = tbl_ts_users.role');
		$query = $this->db->get('tbl_ts_users');

		if($query->num_rows() == 1){
			$datacookies = array(
				'ck_id' => $query->row()->user_id,
				'ck_name' => $query->row()->user_name,
				'ck_nickname' => $query->row()->user_nickname,
				'ck_language' => $query->row()->user_language,
				'ck_country' => $query->row()->user_country,
				'role' => $query->row()->role_name,
				'subsegment' => $query->row()->uri,
				);
			$update = array(
				'user_status' => 1,
				);
			$this->db->where('user_id', $query->row()->user_id);
			$this->db->update('tbl_ts_users', $update);

			$this->session->set_userdata($datacookies);
			$this->general->activity_stamp("Logged In");
			$return = array(
				'logged_in' => 1,
				'message' => "<strong>Welcome ".$datacookies['ck_name']."</strong>",
				'type' => "success",
				);
		}

		return $return;
	}
	function submit_deal($data, $player_info){
		$tablename = "trans_deals_".date("m_d_Y");
		$message =  array(
			"result" => 'true',
			"title" => "Action success",
			"message" => "Deal succesfully saved!",
			"type" => "success",
			);
		$this->db->select('*');
		$this->db->where('trans_id', $data['trans_id']);
		$this->db->where('promo_id', $data['promo_id']);
		$query = $this->db->get($tablename);
		if($query->num_rows() > 0){
			$message['title'] = "Deal Updated";
			$message['message'] = "Deal updated successfully";
			$message['type'] = "success";
			$reset = array(
				'is_interest' => 'not interested',
				);
			$this->db->where('trans_id', $data['trans_id']);
			$this->db->update($tablename, $reset);

			$this->db->where('trans_id', $data['trans_id']);
			$this->db->where('promo_id', $data['promo_id']);
			$this->db->update($tablename, $data);
			// $until = strtotime("+3 days midnight");
			// $update= array(
			// 	'no_call_until_date' => $until,
			// 	);
			// $this->db->where('entry_no' , $player_info['entry_no']);
			// $this->db->update('tbl_player_info', $update);
		}else{
			$this->db->insert($tablename, $data);
		}
		return $message;
	}
	function update_has_deal($interest, $transaction){
		$ret = true;
		$table = 'transaction_'.date("m_d_Y");
		if($interest == "deal"){
			$transaction['has_deal'] = 1;
		}else{
			$transaction['has_deal'] = 0;
			$ret = false;
		}
		$this->db->where('trans_id', $transaction['trans_id']);
		$this->db->update($table, $transaction);
		return $ret;
	}
	function account_submit($data){
		$return = array();
		$this->db->select("*");
		$this->db->where('user_name', $data['user_name']);
		$this->db->where('is_hidden' , 0);
		$this->db->or_where('user_nickname', $data['user_nickname']);
		$this->db->where('is_hidden' , 0);
		$query = $this->db->get('tbl_ts_users');

		if($query->num_rows() == 1){
			$return = array(
				"result" => 'false',
				"message" => "Username / Nickname already exist",
				"type" => "error",
				);
		}else{
			$return = array(
				"result" => 'true',
				"message" => "Account has been added!",
				"type" => "success",
				);
			$this->db->insert('tbl_ts_users', $data);

			$insert = array(
				'user_id' => $data['user_id'],
				'activity_name' => "Account Created",
				'activity_start' => time(),
				'timestamp' => date('c', time()),
				);
			$this->db->insert('tbl_ts_users_act', $insert);
		}
		return $return;
	}
	function get_telesales_account(){
		$sql = "SELECT * FROM `tbl_ts_users` LEFT JOIN `tbl_ts_users_act` on tbl_ts_users_act.user_id = tbl_ts_users.user_id WHERE `role` = 2 AND act_id = (SELECT `act_id` FROM `tbl_ts_users_act` WHERE `user_id` = tbl_ts_users.user_id ORDER BY `activity_start` DESC LIMIT 1) GROUP BY tbl_ts_users.user_id";
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) {
			return $query->result();
		}else{
			return false;
		}
	}
	function get_telesales_info($user_id){
		$this->db->select('user_name, user_nickname, user_id, user_country, user_language,user_status');
		$this->db->from('tbl_ts_users');
		$this->db->where('user_id', $user_id);
		$query = $this->db->get();

		if($query->num_rows() > 0){
			return $query->row();
		}else{
			return false;
		}
	}
	function get_campaign_info($campaign_id){
		$this->db->select('*, COUNT(tbl_promos.campaign_id) as total, tbl_campaigns.campaign_id as cid');
		$this->db->where('tbl_campaigns.campaign_id', $campaign_id);
		$this->db->join('tbl_promos','tbl_promos.campaign_id = tbl_campaigns.campaign_id', 'LEFT');
		$query = $this->db->get('tbl_campaigns');

		if($query->num_rows() > 0){
			$data = $query->row();
			$return = array();
			$return = (array) $data;
			$return['start_date'] = date('m/d/Y', $return['campaign_start_date']); 
			$return['start_time'] = date('H:i', $return['campaign_start_date']); 
			$return['end_date'] = date('m/d/Y', $return['campaign_end_date']);
			$return['end_time'] = date('H:i', $return['campaign_end_date']);
			return $return;
		}else{
			return false;
		}
	}
	function get_promo_info($promoid){
		$this->db->select('*');
		$this->db->from('tbl_promos');
		$this->db->join('tbl_campaigns', 'tbl_campaigns.campaign_id = tbl_promos.campaign_id', 'LEFT');
		$this->db->where('promo_id', $promoid);
		$query = $this->db->get();
		return $query->row();
	}
	function get_campaigns($call_type="", $product="", $country="", $cid=""){
		$like = array(
			'call_type' => $call_type,
			'product_type' => $product,
			'campaign_country' => $country,
			'campaign_id' => $cid,
			);
		$this->db->select('*');
		$this->db->from('tbl_campaigns');
		$this->db->where('is_hidden', 0);
		$this->db->like($like);
		$this->db->order_by("campaign_country");
		$query = $this->db->get();

		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}
	function submit_edit_promotion($data, $promoid){
		$return = array();
		$this->db->where('promo_id', $promoid);
		$this->db->update('tbl_promos', $data);
		if($this->db->affected_rows() > 0){
			$return = array(
				"result" => 'true',
				"title" => "Action success!",
				"message" => "Changes has been saved",
				"type" => "success",
				);
		}else{
			$return = array(
				"result" => 'false',
				"title" => "Action failed",
				"message" => "No rows affected",
				"type" => "error",
				);
		}
		return $return;
	}
	function campaign_submit($data){
		$return = array(
			"result" => 'false',
			"title" => 'Action Failed',
			"message" => '',
			"type" => "error",
			);
		$sql = "SELECT * FROM `tbl_campaigns` WHERE `campaign_start_date` BETWEEN ".$data['campaign_start_date'] ." AND ".$data['campaign_end_date']." AND `is_default` = 0 AND `call_type` = '".$data['call_type']."' AND is_hidden = 0 and `campaign_country` = '" .$data['campaign_country'] ."' OR `campaign_end_date` BETWEEN ".$data['campaign_start_date'] ." AND ".$data['campaign_end_date']." AND `is_default` = 0 AND `call_type` = '".$data['call_type']."' AND is_hidden = 0 and `campaign_country` = '" .$data['campaign_country'] ."'";
		$query = $this->db->query($sql);
		if ($query->num_rows() == 0) {
			$return = array(
				"result" => 'true',
				"title" => 'Action Success',
				"message" => 'Campaign successfully added!',
				"type" => "success",
				);
			$this->db->insert('tbl_campaigns', $data);
		}else{
			$return['message'] = "The system has detected a conflict with Campaign <strong>" .$query->row()->campaign_title ."</strong> with the duration from " .date('M d, Y @ h:i a', $query->row()->campaign_start_date) . " until " .date('M d, Y @ h:i a', $query->row()->campaign_end_date);
		}
		return $return;
	}
	function trash_campaign($campaign_id){
		$return = array();
		$update = array(
			'is_hidden' => 1,
			'is_enabled' => 0,
			);
		$this->db->where('campaign_id', $campaign_id);
		$this->db->where('is_default' , 0);
		$this->db->update('tbl_campaigns', $update);
		if($this->db->affected_rows() == 0){
			$return = array(
				"result" => 'false',
				"title" => 'Action failed',
				"message" => 'Default campaign cannot be trashed!',
				"type" => "info",
				);
		}else{
			$return = array(
				"result" => 'true',
				"title" => 'Action success',
				"message" => 'Campaign has been trashed!',
				"type" => "success",
				);
		}
		return $return;
	}
	function campaign_edit_submit($data, $cid){
		$return = array();
		$this->db->where('campaign_id', $cid);
		$this->db->update('tbl_campaigns', $data);

		if($this->db->affected_rows() > 0){
			$return = array(
				"result" => 'true',
				"title" => "Update success!",
				"message" => "Campaign successfully updated",
				"type" => "success",
				);
		}else{
			$return = array(
				"result" => 'false',
				"title" => "Update failed",
				"message" => "No rows affected",
				"type" => "error",
				);
		}
		return $return;
	}
	function get_promotions($call_type="", $product="", $country=""){
		$like = array(
			'call_type' => $call_type,
			'product_type' => $product,
			'campaign_country' => $country,
			);
		$this->db->select('*');
		$this->db->from('tbl_promos');
		$this->db->join('tbl_campaigns', 'tbl_campaigns.campaign_id = tbl_promos.campaign_id', 'LEFT');
		$this->db->where('tbl_campaigns.is_hidden', 0);
		$this->db->where('tbl_promos.promo_status', 1);
		$this->db->like($like);
		$query = $this->db->get();
		return $query->result();
	}
	function check_promocode($campaignid, $promocode){
		$this->db->select('*');
		$this->db->from('tbl_promos');
		$this->db->where('campaign_id', $campaignid);
		$this->db->where('promo_code', $promocode);
		$this->db->where('promo_status', 1);
		$query = $this->db->get();

		if($query->num_rows() > 0){
			return FALSE;
		}else{
			return TRUE;
		}
	}
	function submit_promotion($data){
		$this->db->insert('tbl_promos', $data);

		$return = array(
			'result' => 'true',
			'title' => 'Action success',
			'message' => 'Promo successfully saved',
			'type' => 'success',
			);
		return $return;
	}
	function check_temp_duplicate($data, $country){
		$this->db->select('*');
		$this->db->where('login_id', $data[0]);
		$this->db->where('player_loc', $country);
		$query = $this->db->get('tbl_temp_transaction');

		if($query->num_rows() > 0){
			return true;
		}
		$table = 'transaction_'.date("m_d_Y");
		$this->db->select('*');
		$this->db->where('tbl_player_info.login_id', $data[0]);
		$this->db->where('player_loc', $country);
		$this->db->join('tbl_player_info', 'tbl_player_info.login_id = '.$table.'.login_id');
		$query2 = $this->db->get($table);

		if($query2->num_rows() > 0){
			return true;
		}
		return false;
	}
	function check_agent_exist($nickname, $country){
		$this->db->where('user_nickname', $nickname);
		$this->db->where('user_country', $country);
		$this->db->where('role', 2);
		$query = $this->db->get('tbl_ts_users');
		if($query->num_rows() > 0){
			return $query->row()->user_nickname;
		}else{
			return null;
		}
	}
	function temp_transaction($data, $country, $calltype, $campaign){
		$name = explode(")", $data[1]);
		if(count($name) != 2){
			$name[1] = "";
		}else{
			$name[0] .= ")";
		}
		$agent = $this->check_agent_exist($data[7], $country);

		$return = array(
			"login_id" => $data[0],
			"user_id" => $name[0],
			"player_name" => $name[1],
			"join_date" => $data[2],
			"player_bank" => $data[3],
			"player_email" => $data[6],
			"player_phone" => $data[5],
			"player_agent" => $agent,
			"player_loc" => $country,
			"player_product" => $data[8],
			"call_type" => $calltype,
			"campaign_id" => $campaign,
			"entry_color" => "td-green",
			);
		return $return;
	}
	function get_temporary_record(){
		$this->db->select('*, tbl_temp_transaction.call_type as calltype');
		$this->db->from('tbl_temp_transaction');
		$this->db->join('tbl_campaigns', 'tbl_campaigns.campaign_id = tbl_temp_transaction.campaign_id', 'LEFT');
		$query = $this->db->get();
		return $query->result();
	}
	function check_data($data, $country, $calltype, $campaign){
		$return = array();
		$insert = array();
		$temp = $this->temp_transaction($data, $country, $calltype, $campaign);
		$activecampaign = $this->_get_active_campaign($country, $calltype);
		$this->db->select('*');
		$this->db->where('login_id', $data[0]);
		$this->db->where('player_loc', $country);
		$query = $this->db->get('tbl_player_info');
		$res = $query->row();
		if($this->check_temp_duplicate($data, $country)){
			$temp['entry_color'] = 'td-blue';
		}
		if($res){
			if(intval($res->no_call_until_date) > time()){
				$temp['entry_color'] = 'td-yellow';
			}elseif($res->is_blocked == 1){
				$temp['entry_color'] = 'td-red';
			}
		}
		$temp['campaign_id'] = $activecampaign;
		array_push($return, $temp);
		return $return;
	}
	function _get_active_campaign($country, $calltype){
		$sql = "SELECT * FROM `tbl_campaigns` WHERE `campaign_start_date` <= ".time()." AND `campaign_end_date` > ".time()." AND `call_type` = '".$calltype."' AND is_hidden = 0 AND `campaign_country` = '" .$country."' ORDER BY `campaign_start_date` DESC LIMIT 1";
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) {
			return $query->row()->campaign_id;
		}else{
			return false;
		}
	}
	function action_to_temp($action){
		if($action == "submit"){
			$this->_action_submit();
		}else{
			$this->_action_truncate();
		}
	}
	function _action_truncate(){
		$sql = "TRUNCATE `tbl_temp_transaction`";
		$this->db->query($sql);
	}
	function _action_submit(){
		$this->_save_new_player();
		$this->_remove_data_anomally();
		$this->_distribute_to_agent();
		$this->_action_truncate();
	}
	function _format_transaction($row, $agent,$country){
		$this->db->select('player_agent');
		$this->db->where('login_id',$row->login_id);
		$this->db->where('player_loc',$country);
		$query = $this->db->get('tbl_player_info');
		$agentid = $this->_get_agent_id($agent->user_nickname);
		if($query->row()->player_agent != ""){
			$agentid = $query->row()->player_agent;
		}

		$return = array(
			'trans_id' => "tr".uniqid().str_pad(rand(0,999), 3, 0, STR_PAD_LEFT),
			'login_id' => $row->login_id,
			'campaign_id' => $row->campaign_id,
			'call_type' => $row->call_type,
			'country' => $country,
			'assigned_agent' => $agentid,
			);
		return $return;
	}
	function _distribute_to_agent(){
		$processed_data = array();
		$max = $this->get_max_lead();
		$leads = $this->get_temporary_record();
		$incmax = 0;
		if($leads){
			$country  = $leads[0]->player_loc; 
			$agents = $this->get_agents($country);
			$agent_count = count($agents);
			$index = 0;
			foreach ($leads as $row) {
				for($i = $index; $i < $agent_count; $i++){
					if($agent_count == 1){
						$push = $this->_format_transaction($row, $agents[0],$country);
						array_push($processed_data, $push);
					}
					else{
						if(intval($agents[$i]->total) <= $max){
							$agents[$i]->total = intval($agents[$i]->total) + 1;
							$push = $this->_format_transaction($row, $agents[$i],$country);
							array_push($processed_data, $push);
							$index++;
							if($index == $agent_count - 1){
								$index = 0;
							}
							break;
						}elseif($agents[$i]->total > $max){
							$incmax++;
							if($incmax == $agent_count-1){
								$max = $max + 1;
								$incmax = 0;
							}
						}
					}
				}
			}
			$table = "transaction_".date("m_d_Y");
			//$table = "transaction_07_30_2017";
			$this->db->insert_batch($table , $processed_data);
		}
	}
	function get_max_lead(){
		$this->db->select('COUNT(entry_id) as max_lead');
		$this->db->from('tbl_temp_transaction');
		$this->db->where('player_agent !=', "");
		$this->db->group_by('player_agent');
		$this->db->order_by('max_lead', "DESC");
		$query = $this->db->get();
		if($query->num_rows > 0){
			return $query->row()->max_lead;
		}else{
			return 0;
		}
	}
	function _remove_data_anomally(){
		$this->db->where('entry_color', 'td-blue');
		$this->db->or_where('entry_color', 'td-yellow');
		$this->db->or_where('entry_color', 'td-red');
		$this->db->delete('tbl_temp_transaction');
	}
	function _save_new_player(){
		$insert = array();
		$update = array();
		$result = $this->get_temporary_record();
		foreach ($result as $row) {
			$this->db->select('*');
			$this->db->where('login_id', $row->login_id);
			$this->db->where('player_loc', $row->player_loc);
			$query = $this->db->get('tbl_player_info');
			$res = $query->row();
			if($query->num_rows() == 0){
				$push = array(
					"login_id" => $row->login_id,
					"user_id" => $row->user_id,
					"player_name" => $row->player_name,
					"join_date" => $row->join_date,
					"player_bank" => $row->player_bank,
					"player_email" => $row->player_email,
					"player_phone" => $row->player_phone,
					"player_agent" => $this->_get_agent_id($row->player_agent),
					"no_call_until_date" => 0,
					"last_called" => 0,
					"pref_language" => $row->player_loc,
					"player_loc" => $row->player_loc,
					"daily_attempt" => 0,
					"player_product" => $row->player_product,
					"is_blocked" => 0,
					);
				array_push($insert, $push);
			}else{
				$update = array();
				$where = array();
				$agent_id = $this->_get_agent_id($row->player_agent);
				if($row->player_agent != ""){
					$update = array(
						"player_bank" => $row->player_bank,
						"player_email" => $row->player_email,
						"player_phone" => $row->player_phone,
						'player_agent' => $agent_id,
						);
					$where = array(
						'login_id' => $row->login_id,
						'player_loc' => $row->player_loc,
						);
				}else{
					$update = array(
						"player_bank" => $row->player_bank,
						"player_email" => $row->player_email,
						"player_phone" => $row->player_phone,
						);
					$where = array(
						'login_id' => $row->login_id,
						'player_loc' => $row->player_loc,
						);
				}
				$this->db->where($where);
				$this->db->update('tbl_player_info' , $update);
			}
		}
		if($insert){
			$this->db->insert_batch('tbl_player_info', $insert);
		}
	}
	function _get_agent_id($agent){
		$this->db->where('user_nickname', $agent);
		$query = $this->db->get('tbl_ts_users');

		if($query->num_rows() > 0){
			return $query->row()->user_id;
		}else{
			return "";
		}
	}
	function get_agents($country){
		$this->db->select('tbl_ts_users.user_id, user_nickname, COUNT(entry_id) as total');
		$this->db->from('tbl_ts_users');
		$this->db->where('user_country' , $country);
		$this->db->where('role', 2);
		$this->db->where('is_hidden', 0);
		$this->db->group_by('user_nickname');
		$this->db->join('tbl_temp_transaction', 'tbl_temp_transaction.player_agent = tbl_ts_users.user_nickname', "LEFT");
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		}else{
			return false;
		}
	}
	function get_temporary(){
		$this->db->select('*');
		$this->db->from('tbl_temp_transaction');
		$this->db->where('player_agent', "");
		$this->db->join('tbl_campaigns', 'tbl_campaigns.campaign_id = tbl_temp_transaction.campaign_id', 'LEFT');
		$query = $this->db->get();
		return $query->result();
	}
	function get_onqueue($country, $calltype){
		$table = 'transaction_'.date("m_d_Y");

		$this->db->select('tbl_campaigns.campaign_title,trans_id,'.$table.'.login_id,tbl_player_info.user_id,player_name,player_email,player_phone,user_nickname,player_product,'.$table.'.call_type');
		$this->db->from($table);
		$this->db->join('tbl_player_info', 'tbl_player_info.login_id = '.$table.'.login_id');
		$this->db->join('tbl_campaigns', 'tbl_campaigns.campaign_id = '.$table.'.campaign_id');
		$this->db->join('tbl_ts_users', 'tbl_ts_users.user_id = '.$table.'.assigned_agent');
		if($country){
			$this->db->where('player_loc',$country);
		}
		if($calltype){
			$this->db->where($table.'.call_type',$calltype);
		}
		$this->db->where('is_fulfilled', NULL);
		$query = $this->db->get();

		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}
	function get_settings(){
		$this->db->where('setting_id', 1);
		$query = $this->db->get('tbl_settings');
		return $query->row();
	}
	function set_call_priority($id, $position){
		$update = array(
			'priority' => $position,
			);
		$this->db->where('entry_id', $id);
		$this->db->update('tbl_call_priority', $update);
	}
	function get_priority_order(){
		$this->db->select('*');
		$this->db->from('tbl_call_priority');
		$this->db->order_by('priority', "ASC");
		$query = $this->db->get();
		return $query->result();
	}
	function get_player_list(){

		$this->db->select('*');
		if($this->input->get('q')){
			$this->db->like('login_id',$this->input->get('q'));
			$this->db->or_like('user_id',$this->input->get('q'));
			$this->db->or_like('player_name',$this->input->get('q'));
			$this->db->or_like('player_email',$this->input->get('q'));
			$this->db->or_like('player_agent',$this->input->get('q'));
		}else{
			$like = array(
				'player_loc' => $this->input->get('country', true),
				'player_product' => $this->input->get('product', true),
				'is_blocked' => $this->input->get('status', true),
				);
			$this->db->like($like);
		}
		$query = $this->db->get('tbl_player_info');
		if ($query->num_rows() > 0) {
			return $query->result();
		}else{
			return false;
		}
	}
	function get_today_report($agent = null){
		$table = 'transaction_'.date("m_d_Y");
		$this->db->select("*");
		$this->db->join('tbl_player_info', 'tbl_player_info.login_id = '.$table.'.login_id');
		if($agent){
			$this->db->where('assigned_agent', $agent);
		}
		$query = $this->db->get($table);
		return $query->result();
	}
	function get_call_stat_count(){
		$table = 'transaction_'.date("m_d_Y");
		$results = array('REACHED', 'UNREACHED', 'INVALID');
		$return = array();
		$ck_id = $this->session->userdata('ck_id');
		foreach ($results as $value) {
			$this->db->where('assigned_agent', $ck_id);
			$this->db->where('result', $value);
			$query = $this->db->get($table);
			$temp = array(
				strtolower($value) => $query->num_rows(),
				);
			array_push($return, $temp);
		}
		return $return;
	}
	function agent_on_queue(){
		$current = $this->_get_current_transaction();
		$table = 'transaction_'.date("m_d_Y");
		$this->db->select('pref_language,tbl_campaigns.campaign_title,product_type,tbl_campaigns.campaign_id,trans_id,'.$table.'.login_id,tbl_player_info.user_id,player_name,assigned_agent,player_email,player_phone,user_nickname,daily_attempt,join_date,player_product,'.$table.'.call_type, priority,player_loc');
		$this->db->from($table);
		$this->db->join('tbl_call_priority', 'tbl_call_priority.call_type = '.$table.'.call_type');
		$this->db->join('tbl_player_info', 'tbl_player_info.login_id = '.$table.'.login_id');
		$this->db->join('tbl_campaigns', 'tbl_campaigns.campaign_id = '.$table.'.campaign_id');
		$this->db->join('tbl_ts_users', 'tbl_ts_users.user_id = '.$table.'.assigned_agent');
		
		$where = array(
			'is_fulfilled' => NULL,
			'assigned_agent' => $this->session->userdata('ck_id'),
			'no_call_until_date <=' => time(),
			$table.'.country' => $this->session->userdata('ck_country'),
			);
		$this->db->where($where);
		if($current){
			$this->db->where('trans_id', $current);
		}
		$this->db->order_by('no_call_until_date DESC','priority ASC');
		$this->db->limit(1);
		$query = $this->db->get();
		if($query->num_rows() > 0){
			$trans_id = $query->row()->trans_id;
			$update = array(
				'current_transaction' => $trans_id,
				);
			$this->db->where('user_id', $this->session->userdata('ck_id'));
			$this->db->update('tbl_ts_users', $update);
			$this->session->set_userdata($update);

			$timestart = array(
				'handle_start_timestamp' => time(),
				);
			$this->db->where('trans_id', $trans_id);
			$this->db->where('handle_start_timestamp', NULL);
			$this->db->update($table, $timestart);
			$res = $query->result();
			$this->activity_stamp("On call");
			return $res[0];
		}else{
			$update = array(
				'current_transaction' => "",
				);
			$this->db->where('user_id', $this->session->userdata('ck_id'));
			$this->db->update('tbl_ts_users', $update);
			return false;
		}
	}
	function _get_current_transaction(){
		$this->db->where('user_id', $this->session->userdata('ck_id'));
		$query = $this->db->get('tbl_ts_users');
		if ($query->num_rows() > 0) {
			return $query->row()->current_transaction;
		}else{
			return false;
		}
	}
	function fulfill_transaction($update, $current){
		$table = 'transaction_'.date("m_d_Y");
		$this->db->where('trans_id', $current);
		$this->db->update($table, $update);
		$transaction = (array) $this->get_transaction_info($current);

		$call_rec = array(
			'start_time' => $transaction['handle_start_timestamp'],
			'end_time' => time(),
			'user_id' => $this->session->userdata('ck_id'),
			'reason' => strtoupper($transaction['call_type']),
			'type' => 'CALL',
			'min_duration' => round((time() - $transaction['handle_start_timestamp']) / 60, 2),
			);
		$this->db->insert('tbl_break_record', $call_rec);

		$curr = array(
			'current_transaction' => "",
			);
		$this->db->where('user_id', $this->session->userdata('ck_id'));
		$this->db->update('tbl_ts_users', $curr);

		$transaction = (array) $this->get_transaction_info($current);
		$player_info = (array) $this->get_player_info($transaction);
		if($update['type'] == "FULL CONVERSATION"){

			$until = strtotime("+3 days midnight");
			$update= array(
				'last_called' => time(),
				'daily_attempt' => intval($player_info['daily_attempt']) + 1,
				'no_call_until_date' => $until,
				);
		}else{
			$update= array(
				'last_called' => time(),
				'daily_attempt' => intval($player_info['daily_attempt']) + 1,
				);	
		}
		
		$this->db->where('entry_no' , $player_info['entry_no']);
		$this->db->update('tbl_player_info', $update);
	}
	function reschedule_call($current, $reschedtime){
		$message;
		$table = 'transaction_'.date("m_d_Y");
		$transaction = (array) $this->get_transaction_info($current , true);
		if($transaction){
			$player_info = (array) $this->get_player_info($transaction);
			$until = strtotime("+4 days midnight");
			if(date('D', $until) == "Sun"){
				$until = strtotime("+5 days midnight");
			}
			if($player_info){
				if($player_info['daily_attempt'] < 2){
					$insert = array(
						'trans_id' => "tr".uniqid().str_pad(rand(0,999), 3, 0, STR_PAD_LEFT),
						'login_id' => $transaction['login_id'],
						'campaign_id' => $transaction['campaign_id'],
						'call_type' => $transaction['call_type'],
						'country' => $transaction['country'],
						'assigned_agent' => $transaction['assigned_agent'],
						'is_resched' => 1,
						);
					$til = time() + intval($reschedtime);
					$today = strtotime("today 23:59:59");
					if($til <= $today){
						$this->db->insert($table, $insert);
					}
					$update= array(
						'no_call_until_date' => time() + intval($reschedtime),
						);
					$this->db->where('entry_no' , $player_info['entry_no']);
					$this->db->update('tbl_player_info', $update);
					$message = "Call successfully rescheduled!";
				}else{
					$update= array(
						'no_call_until_date' => $until,
						'daily_attempt' => -1,
						);
					$this->db->where('entry_no' , $player_info['entry_no']);
					$this->db->update('tbl_player_info', $update);

					$message = "Reschedule failed. maximum 3 daily attempt reached. Transaction submitted!";
				}
			}
		}else{
			return "hasdeal";
		}
		return $message;
	}
	function block_call($current){
		$table = 'transaction_'.date("m_d_Y");
		$transaction = (array) $this->get_transaction_info($current);
		$player_info = (array) $this->get_player_info($transaction);

		$update= array(
			'is_blocked' => 1,
			);
		$this->db->where('entry_no' , $player_info['entry_no']);
		$this->db->update('tbl_player_info', $update);
		$message = "Player successfully blocked. Transaction submitted!";
		return $message;
	}
	function get_transaction_info($current, $checkdeal = null){
		$table = 'transaction_'.date("m_d_Y");
		$this->db->where('trans_id', $current);
		if($checkdeal){
			$this->db->where('has_deal', 0);
		}
		$query = $this->db->get($table);
		return $query->row();
	}
	function get_player_info($transaction){
		$this->db->where('login_id', $transaction['login_id']);
		$this->db->where('player_loc', $transaction['country']);
		$query = $this->db->get('tbl_player_info');
		if($query->num_rows() > 0){
			return $query->row();
		}else{
			return false;
		}
	}
	function activity_stamp($activity){
		$insert = array(
			'user_id' => $this->session->userdata('ck_id'),
			'activity_name' => $activity,
			'activity_start' => time(),
			'timestamp' => date('c', time()),
			);
		$this->db->where('user_id' , $insert['user_id']);
		$this->db->delete('tbl_ts_users_act');
		$this->db->insert('tbl_ts_users_act', $insert);
	}
	function get_campaign_promo($campaign_id){
		$this->db->select('*');
		$this->db->from('tbl_promos');
		$this->db->join('tbl_campaigns', 'tbl_campaigns.campaign_id = tbl_promos.campaign_id');
		$this->db->where('tbl_promos.campaign_id', $campaign_id);
		$this->db->where('tbl_promos.promo_status', 1);
		$this->db->order_by('is_default', 'DESC');
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}
	function player_history($trans_id = null){
		$current = $this->_get_current_transaction();
		$table = 'transaction_'.date("m_d_Y");
		$transaction = (array) $this->get_transaction_info($current);
		$player_info = (array) $this->get_player_info($transaction);
		$archive_tbl = $this->get_archive_table();

		$tbl_count = count($archive_tbl) - 1;
		if($archive_tbl){
			$sql = "SELECT * FROM (";
			foreach ($archive_tbl as $key => $row) {
				$sql .= "SELECT is_interest,promo_title,call_type,is_fulfilled,handle_end_timestamp,handle_start_timestamp,user_nickname,add_action,action,type,result,".$row->table_trans .".trans_id FROM ".$row->table_trans ." LEFT JOIN ".$row->table_deals ." ON ".$row->table_deals .".trans_id = ".$row->table_trans .".trans_id AND ".$row->table_deals .".is_interest = 'deal' LEFT JOIN tbl_ts_users ON tbl_ts_users.user_id = ".$row->table_trans .".assigned_agent LEFT JOIN `tbl_promos` ON tbl_promos.promo_id = ".$row->table_deals .".promo_id WHERE `is_fulfilled` = 1 AND ".$row->table_trans .".login_id = '" .$player_info['login_id']."'";
				if($trans_id){
					$sql .= " AND ".$row->table_trans .".trans_id = '".$trans_id ."' ";
				}
				if($key != $tbl_count){
					$sql .= " UNION ALL ";
				}
			}
			$sql .=" ) t ORDER BY `handle_start_timestamp` DESC, is_interest ASC LIMIT 10";
			
			$query = $this->db->query($sql);
			if($trans_id){
				$therow = $query->row();
				$promo = $therow->promo_title;	
				if(!$promo){
					$promo = "N/A";
				}
				$secs = $therow->handle_end_timestamp - $therow->handle_start_timestamp;
				$json = array(
					'title' => "Retrieve success",
					'result' => true,
					'trans_id' => $therow->trans_id,
					'promo_title' => $promo,
					'call_type' => $therow->call_type,
					'end_time' => date('h:i A M d, Y ', $therow->handle_end_timestamp),
					'start_time' => date('h:i A', $therow->handle_start_timestamp),
					'handler' => $therow->user_nickname,
					'add_action' => strtoupper($therow->add_action),
					'action' => strtoupper($therow->action),
					'duration' => gmdate("H:i:s", $secs),
					'type' => strtoupper($therow->type),
					'res' => strtoupper($therow->result),
					'is_interest' => $therow->is_interest,
					);
				return $json;
			}else{
				return $query->result();
			}
		}else{
			return false;
		}
	}
	function gettimestamp($rawdate, $add=null){
		$date = explode("/", $rawdate);
		if($add == "to"){
			$time = strtotime( $date[1] ."-" .$date[0] ."-" .$date[2] . " 23:59");
		}elseif($add == "from"){
			$time = strtotime( $date[1] ."-" .$date[0] ."-" .$date[2] . " 00:00");
		}else{
			$time = strtotime( $date[1] ."-" .$date[0] ."-" .$date[2]);
		}
		return $time;
	}
	function get_transaction_archives(){
		$archive_tbl = $this->get_archive_table();

		$tbl_count = count($archive_tbl) - 1;
		if($archive_tbl){
			$sql = "SELECT * FROM (";
			foreach ($archive_tbl as $key => $row) {
				$sql .= "SELECT ".$row->table_trans.".login_id,remarks,".$row->table_trans.".date_added,is_interest,promo_title,call_type,is_fulfilled,".$row->table_trans.".country,handle_end_timestamp,handle_start_timestamp,user_nickname,add_action,action,type,result,".$row->table_trans .".trans_id FROM ".$row->table_trans." LEFT JOIN ".$row->table_deals ." ON ".$row->table_deals .".trans_id = ".$row->table_trans .".trans_id AND ".$row->table_deals .".is_interest = 'deal' LEFT JOIN tbl_ts_users ON tbl_ts_users.user_id = ".$row->table_trans .".assigned_agent LEFT JOIN `tbl_promos` ON tbl_promos.promo_id = ".$row->table_deals .".promo_id";
				$sql .= " WHERE 1+1 ";
				if($this->input->get('inc-country')){
					$sql .= ' AND '.$row->table_trans .'.country LIKE \'%'.$this->input->get('country').'%\''; 
				}
				if($this->input->get('inc-result')){
					$sql .= ' AND '.$row->table_trans .'.result LIKE \'%'.$this->input->get('result').'%\''; 
				}
				if($this->input->get('inc-type')){
					$sql .= ' AND '.$row->table_trans .'.type LIKE \'%'.$this->input->get('type').'%\''; 
				}
				if($this->input->get('inc-agent')){
					$sql .= ' AND '.$row->table_trans .'.assigned_agent LIKE \'%'.$this->input->get('agent').'%\''; 
				}
				if($this->input->get('inc-range')){
					$range = explode('-', $this->input->get('daterange'));
					if(count($range) == 2){
						$from = intval($this->gettimestamp(trim($range[0]), "from"));
						$to = intval($this->gettimestamp(trim($range[1]), "to"));

						$sql .= ' AND '.$row->table_trans .'.date_added BETWEEN \''.date('Y-m-d H:m:i',$from).'\' AND \''.date('Y-m-d H:m:i',$to) .'\''; 
					}
				}
				if($key != $tbl_count){
					$sql .= " UNION ALL ";
				}
			}
			
			$sql .=" ) t ";
			
			$sql .="  ORDER BY `date_added`";
			$query = $this->db->query($sql);
			if($query->num_rows() > 0){
				return $query->result();
			}else{
				return false;
			}
		}
	}
	function get_archive_table(){
		$this->db->select();
		$this->db->from('tbl_transaction_archive');
		$this->db->order_by('entry_id');
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}
	function start_break($call = false){
		$user_id = $this->session->userdata('ck_id');
		$jsonresponse = array();
		$update = array(
			'on_break' => 1,
			);
		$this->db->where('user_id', $user_id);
		$this->db->where('current_transaction', "");
		$this->db->update('tbl_ts_users', $update);
		if($this->db->affected_rows() == 1){
			$this->general->activity_stamp("On Break");
			$jsonresponse = array(
				"result" => true,
				);
			$insert = array(
				'start_time' => time(),
				'user_id' => $user_id,
				);
			$this->db->insert('tbl_break_record', $insert);
		}else{
			$jsonresponse = array(
				"result" => false,
				);
		}
		return $jsonresponse;
	}
	function end_break($pause_type){
		$user_id = $this->session->userdata('ck_id');

		$update = array(
			'on_break' => 0,
			);
		$this->db->where('user_id', $user_id);
		$this->db->update('tbl_ts_users', $update);	

		if($this->db->affected_rows() == 1){
			
			$this->db->where('user_id', $user_id);
			$this->db->where('end_time', NULL);
			$query = $this->db->get('tbl_break_record');
			if($query->num_rows() > 0){
				$handle_start = $query->row()->start_time;
				$update = array(
					'end_time' => time(),
					'reason' => $pause_type,
					'min_duration' => round((time() - $handle_start) / 60, 2),
					);
				$this->db->where('user_id', $user_id);
				$this->db->where('end_time', NULL);
				$this->db->update('tbl_break_record', $update);
			}
			$this->db->last_query();
			$jsonresponse = array(
				"result" => true,
				"message" => "Session will start shortly  . . .",
				);
		}else{
			$jsonresponse = array(
				"result" => false,
				"message" => "Something went wrong",
				);
		}
		return $jsonresponse;
	}
	function is_on_break(){
		$user_id = $this->session->userdata('ck_id');
		$this->db->select("*");
		$this->db->where('user_id', $user_id);
		$this->db->where('end_time', NULL);
		$query = $this->db->get('tbl_break_record');
		if($query->num_rows() > 0){
			return $query->row();
		}else{
			return false;
		}
	}
	function drop_call_item($ids){
		$table = 'transaction_'.date("m_d_Y");
		foreach ($ids as $id) {
			$this->db->where('trans_id', $id);
			$this->db->where('handle_start_timestamp', NULL);
			$this->db->delete($table);
		}
	}
	function submit_revision($field, $new_value){
		$jsonresponse = array();
		$current = $this->_get_current_transaction();
		$transaction = (array) $this->get_transaction_info($current);
		$player_info = (array) $this->get_player_info($transaction);
		if($new_value){
			$data = array(
				'login_id' => $player_info['login_id'],
				'revise_field' => $field,
				'old_value' => $player_info[$field],
				'new_value' => $new_value,
				'placed_by' => $this->session->userdata('ck_nickname'),
				'indetifier' => $current,
				);
			$this->db->where('indetifier', $current);
			$this->db->where('revise_field', $field);
			$this->db->update('tbl_revision', $data);
			if($this->db->affected_rows() == 0){
				$this->db->insert('tbl_revision', $data);
				$jsonresponse = array(
					"result" => 'true',
					"title" => "Action success",
					"message" => "Revision has been submitted",
					"type" => "success",
					);
			}else{
				$jsonresponse = array(
					"result" => 'true',
					"title" => "Action success",
					"message" => "Revision has been updated",
					"type" => "success",
					);
			}
		}else{
			$this->db->where('indetifier', $current);
			$this->db->where('revise_field', $field);
			$this->db->delete('tbl_revision');
			$jsonresponse = array(
				"result" => 'true',
				"title" => "Action success",
				"message" => "Revision has been revoked",
				"type" => "info",
				);
		}
		return $jsonresponse;
	}
	function get_revision_list(){
		$countries = array('cn','vn','th','my');
		$choices = array(0,1);
		$country ="";
		$choice="";
		$show ="";
		if(in_array($this->input->get('country'), $countries)){
			$country = $this->input->get('country');
		}
		if(in_array($this->input->get('show'), $choices)){
			$choice = $this->input->get('show');
		}
		$this->db->select('*');
		$this->db->from('tbl_revision');
		$this->db->join('tbl_player_info', 'tbl_player_info.login_id = tbl_revision.login_id');
		$this->db->like('player_loc', $country);
		$this->db->like('fulfill_status', $choice);
		$this->db->order_by('');
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}
	function get_activity_graph($country="", $by_date = "week", $type="CALL", $agentid = null, $reason = null){
		$id;
		switch ($by_date) {
			case 'year':
			$id = "Y";
			break;
			case 'month':
			$id = "m";
			break;
			case 'day':
			$id = "d";
			break;
			default:
			$id = "W";
			break;
		}
		$sql = "SELECT timestamp,coalesce(SUM(min_duration)) AS dur, DATE_FORMAT(timestamp, '%".$id."') AS df";
		$sql .=" FROM tbl_break_record";
		$sql .= " LEFT JOIN tbl_ts_users ON tbl_ts_users.user_id = tbl_break_record.user_id";
		$sql .= " WHERE `user_country` like '%".$country."%'";
		$sql .= " AND `type` like '%".$type."%'";
		if($reason){
			$sql .= " AND `reason` like '%".$reason."%'";
		}
		$sql .= " AND tbl_break_record.user_id LIKE '%".$agentid."%'";
		if($this->input->get('daterange')){
			$range = explode('-', $this->input->get('daterange'));
			if(count($range) == 2){
				$from = intval($this->gettimestamp(trim($range[0]), "from"));
				$to = intval($this->gettimestamp(trim($range[1]), "to"));
				$sql .= ' AND timestamp BETWEEN \''.date('Y-m-d H:m:i',$from).'\' AND \''.date('Y-m-d H:m:i',$to) .'\''; 
			}
		}
		if(!$reason){
			if($by_date == "year"){
				$sql .=" GROUP BY YEAR(timestamp) ";
			}elseif($by_date == "month"){
				$sql .=" GROUP BY YEAR(timestamp), MONTH(timestamp)";
			}elseif($by_date == "week"){
				$sql .=" GROUP BY YEAR(timestamp), MONTH(timestamp), WEEK(timestamp)";
			}elseif($by_date == "day"){
				$sql .=" GROUP BY YEAR(timestamp), MONTH(timestamp), WEEK(timestamp), DAY(timestamp)";
			}
		}
		$sql .= " ORDER BY YEAR(timestamp) DESC, MONTH(timestamp) DESC, DAY(timestamp) DESC";
		if($this->input->get('daterange')){
			$limit = 7;
			$range = explode('-', $this->input->get('daterange'));
			if(count($range) == 2){
				$from = intval($this->gettimestamp(trim($range[0]), "from"));
				$to = intval($this->gettimestamp(trim($range[1]), "to"));
				$start = strtotime(date('Y-m-d',$from));
				$end = strtotime(date('Y-m-d',$to));
				$limit = ceil(abs( $end - $start ) / 86400);
				if($start == $end){
					$limit = 1;
				}
			}
			$sql .=" LIMIT ".$limit;
		}else{
			$sql .=" LIMIT 7";
		}
		$query = $this->db->query($sql);
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}
	function get_lead_graph($country="", $by_date = "week", $type="", $agentid = null, $cd = null){
		$archive_tbl = $this->get_archive_table();
		$id;
		$as;
		switch ($by_date) {
			case 'year':
			$id = "Y";
			break;
			case 'month':
			$id = "m";
			break;
			case 'day':
			$id = "d";
			break;
			default:
			$id = "W";
			break;
		}
		$tbl_count = count($archive_tbl) - 1;
		if($archive_tbl){
			$from;$to;
			$sql = "SELECT coalesce(sum(`type` <> 'FULL CONVERSATION'), 0) inotfull, coalesce(sum(`type` = 'INVALID NUMBER'), 0) inumber,coalesce(sum(`type` = 'UNANSWERED'), 0) uanswered,coalesce(sum(`type` = 'BUSY TONE'), 0) ubusy,coalesce(sum(`type` = 'HARASS'), 0) rharass,coalesce(sum(`type` = 'HANGUP'), 0) rhang,coalesce(sum(`type` = 'WRONG PERSON'), 0) rwrong,coalesce(sum(`type` = 'BUSY'), 0) rbusy,coalesce(sum(`type` = 'FULL CONVERSATION'), 0) rfull,date_added,coalesce(sum(`result` = 'INVALID'), 0) invalid,coalesce(sum(`result` = 'UNREACHED'), 0) unreached,coalesce(sum(`result` = 'REACHED'), 0) reached,coalesce(sum(`is_fulfilled` = 1), 0) fulfilled,coalesce(sum(`is_resched` = 0), 0) as count, DATE_FORMAT(date_added, '%".$id."') AS df FROM (";
			if($cd){
				$sql = "SELECT COUNT(*) as cd_count,date_added,DATE_FORMAT(date_added, '%".$id."') AS df FROM (";
			}
			foreach ($archive_tbl as $key => $row) {
				$sql .= "SELECT * FROM `".$row->table_trans ."`";
				$sql .= " WHERE `country` like '%".$country."%'";
				$sql .= " AND `call_type` like '%".$type."%'";
				$sql .= " AND `assigned_agent` LIKE '%".$agentid."%'";
				if($cd){
					$sql .= " AND type <> 'FULL CONVERSATION'";
				}
				if($this->input->get('daterange')){
					$range = explode('-', $this->input->get('daterange'));
					if(count($range) == 2){
						$from = intval($this->gettimestamp(trim($range[0]), "from"));
						$to = intval($this->gettimestamp(trim($range[1]), "to"));

						$sql .= ' AND '.$row->table_trans .'.date_added BETWEEN \''.date('Y-m-d H:m:i',$from).'\' AND \''.date('Y-m-d H:m:i',$to) .'\''; 
					}
				}
					if($cd){
						$sql .= " GROUP BY login_id HAVING COUNT(*) = 3";
					}
				if($key != $tbl_count){
					$sql .= " UNION ALL ";
				}
			}
			$sql .=" ) t ";
			$sql .= " GROUP BY ";
			if($by_date == "year"){
				$sql .=" YEAR(date_added) ";
			}elseif($by_date == "month"){
				$sql .=" YEAR(date_added), MONTH(date_added)";
			}elseif($by_date == "week"){
				$sql .=" YEAR(date_added), MONTH(date_added), WEEK(date_added)";
			}elseif($by_date == "day"){
				$sql .=" YEAR(date_added), MONTH(date_added), WEEK(date_added), DAY(date_added)";
			}
			$sql .= " ORDER BY YEAR(date_added) DESC, MONTH(date_added) DESC, DAY(date_added) DESC, `country` DESC, `call_type` DESC";
			if($this->input->get('daterange')){
				$limit = 7;
				$range = explode('-', $this->input->get('daterange'));
				if(count($range) == 2){
					$from = intval($this->gettimestamp(trim($range[0]), "from"));
					$to = intval($this->gettimestamp(trim($range[1]), "to"));
					$start = strtotime(date('Y-m-d',$from));
					$end = strtotime(date('Y-m-d',$to));
					$limit = ceil(abs( $end - $start ) / 86400);
					if($start == $end){
						$limit = 1;
					}
				}
				$sql .=" LIMIT ".$limit;
			}else{
				$sql .=" LIMIT 7";
			}
			$query = $this->db->query($sql);
			if($query->num_rows() > 0){
				return $query->result();
			}else{
				return false;
			}
		}
	}
	function delete_promotion($promo_id){
		$archive_tbl = $this->get_archive_table();
		$tbl_count = count($archive_tbl) - 1;
		if($archive_tbl){
			$sql = "SELECT * FROM (";
			foreach ($archive_tbl as $key => $row) {
				$sql .= "SELECT * FROM `".$row->table_deals ."`";
				if($key != $tbl_count){
					$sql .= " UNION ALL ";
				}
			}
			$sql .=" ) t ";
			$sql .= " WHERE `promo_id` = '".$promo_id."'";
			$query = $this->db->query($sql);
			if($query->num_rows() > 0){
				$update = array(
					'promo_status'=>0
					);
				$this->db->where('promo_id', $promo_id);
				$this->db->update('tbl_promos',$update);
			}else{
				$this->db->where('promo_id', $promo_id);
				$this->db->delete('tbl_promos');
			}
			return true;
		}else{
			return false;
		}
	}
	function get_transaction_graph($country=""){
		$archive_tbl = $this->get_archive_table();

		$tbl_count = count($archive_tbl) - 1;
		if($archive_tbl){
			$sql = "SELECT count(trans_id),country,call_type, DATE_FORMAT(date_added, '%d') AS DAY, DATE_FORMAT(date_added, '%M') AS MONTH, DATE_FORMAT(date_added, '%Y') AS YEAR FROM (";
			foreach ($archive_tbl as $key => $row) {
				$sql .= "SELECT * FROM `".$row->table_trans ."`";
				//$sql .= " WHERE `country` like '%".$country."%'";
				if($key != $tbl_count){
					$sql .= " UNION ALL ";
				}
			}
			
			$sql .=" ) t ";
			//$sql .= " WHERE `is_fulfilled`";
			$sql .=" GROUP BY `call_type`, YEAR(date_added), MONTH(date_added), DAY(date_added) ORDER BY YEAR(date_added) DESC, MONTH(date_added) DESC, DAY(date_added) DESC, `country` DESC, `call_type` DESC";
			$query = $this->db->query($sql);
			if($query->num_rows() > 0){
				return $query->result();
			}else{
				return false;
			}
		}
	}
	function get_average_call($type="", $country=""){
		$sql = "SELECT FLOOR(AVG(end_time) - AVG(start_time)) as endavg FROM `tbl_break_record` LEFT JOIN `tbl_ts_users` ON tbl_ts_users.user_id = tbl_break_record.user_id WHERE `type` = '".$type ."'";
		$sql .= " AND `user_country` like '%".$country."%'";
		$sql .= " AND end_time IS NOT NULL";
		if($this->input->get('daterange')){
			$range = explode('-', $this->input->get('daterange'));
			if(count($range) == 2){
				$from = intval($this->gettimestamp(trim($range[0]), "from"));
				$to = intval($this->gettimestamp(trim($range[1]), "to"));

				$sql .= ' AND timestamp BETWEEN \''.date('Y-m-d H:m:i',$from).'\' AND \''.date('Y-m-d H:m:i',$to) .'\''; 
			}
		}
		$sql .=" ORDER BY YEAR(timestamp) DESC, MONTH(timestamp) DESC, DAY(timestamp) DESC";
		$query = $this->db->query($sql);
		if($query->num_rows() > 0){
			$res = $query->row();
			$dif = $res->endavg;
			$return =  gmdate("H:i:s", $dif);
		}else{
			$return = "00:00:00";
		}
		return $return;
	}
	function get_agent_by_country($country){
		$this->db->select('user_id, user_nickname');
		$this->db->where('role', 2);
		$this->db->where('user_country', $country);
		$query = $this->db->get('tbl_ts_users');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}
	function get_ceil_floor($get, $type, $country= ""){
		$sql = "SELECT (end_time - start_time) as diff FROM tbl_break_record";
		$sql .= " LEFT JOIN tbl_ts_users ON tbl_ts_users.user_id = tbl_break_record.user_id";
		$sql .= " WHERE type = '".$type."'";
		$sql .= " AND user_country LIKE '%" .$country ."%'";
		$sql .= " AND end_time IS NOT NULL";
		if($this->input->get('agent')){
			$sql .= " AND tbl_ts_users.user_id ='" .$this->input->get('agent', true)."'";
		}
		if($this->input->get('daterange')){
			$range = explode('-', $this->input->get('daterange'));
			if(count($range) == 2){
				$from = intval($this->gettimestamp(trim($range[0]), "from"));
				$to = intval($this->gettimestamp(trim($range[1]), "to"));

				$sql .= ' AND timestamp BETWEEN \''.date('Y-m-d H:m:i',$from).'\' AND \''.date('Y-m-d H:m:i',$to) .'\''; 
			}
		}
		$query = $this->db->query($sql);

		if($query->num_rows() > 0){
			$dif =  max(array_column($query->result(), 'diff'));
		}else{
			$dif =  0;
		}
		$return =  gmdate("H:i:s", $dif);

		return $return;
	}
	function get_progress(){
		$countries = array(
			'china' => 'cn',
			'malaysia' => 'my',
			'thailand' => 'th',
			'vietnam' => 'vn',
			);
		$ret = array();
		$tablename = "transaction_".date("m_d_Y");
		foreach ($countries as $key => $value) {
			$sql = "SELECT DISTINCT login_id, country, COUNT(IF(`is_resched` = 0,`is_resched`, NULL)) as leads, COUNT(IF(`is_fulfilled` = 1 AND `is_resched` = 0,`is_fulfilled`, NULL)) as calls FROM " .$tablename ." WHERE country = '".$value."'";
			$query = $this->db->query($sql);
			if($query->row()->country){
				array_push($ret, $query->row());
			}else{
				$temp = array('country' => $value, 'lead' => "0", 'calls' => "0");
				array_push($ret, $temp);
			}
		}
		return $ret;
	}
	function get_activities(){
		$sql = "SELECT activity_name,user_nickname,timestamp FROM tbl_ts_users_act LEFT JOIN tbl_ts_users ON tbl_ts_users.user_id = tbl_ts_users_act.user_id WHERE role = 2 ORDER BY activity_start DESC";
		$query = $this->db->query($sql);
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}
	function get_time_breakdown(){

	}
	function update_grace_period($graceperiod){
		$sql = "UPDATE tbl_settings SET grace_period = ".$graceperiod ." WHERE setting_id = 1";
		$this->db->query($sql);
	}
	function update_player_info($data){
		$update2 = array(
			'fulfill_status' => 1,
			'date_fulfilled' => date('Y-m-d h:i:s', time())
			);
		$this->db->where('login_id', $data[0]);
		$this->db->where('revise_field', $data[3]);
		$this->db->where('fulfill_status', 0);
		$this->db->update('tbl_revision', $update2);

		if($this->db->affected_rows() > 0){
			$update = array(
				strtolower($data[3]) => $data[5],
				);
			$this->db->where('login_id', $data[0]);
			$this->db->where('player_loc', $data[2]);
			$this->db->update('tbl_player_info', $update);
		}
	}
}

