<?php  
	// PLEASE CHANGE THE VALUE INSIDE THE QUOTATIONS ON THE RIGHT SIDE
	//$lang['sample'] = 'CHANGE ME!';

	// DONT MODIFY THIS
	$lang['dashboard'] = 'Dashboard';
	$lang['data_wizard'] = 'Data Wizard';
	$lang['call_list'] = 'Call List';
	$lang['telesales'] = 'Telesales';
	$lang['settings'] = 'Settings';
	$lang['general_settings'] = 'General Settings';
	$lang['promo_settings'] = 'Promo Settings';
	$lang['reports'] = 'Reports';
	$lang['call_reports'] = 'Call Reports';
	$lang['agent_reports'] = 'Agent Reports';
	// DONT MODIFY THIS

	//START HERE 
	$lang['player_info'] = "玩家信息";
	$lang['campaign_promo'] = "参加活动";
	$lang['login_id'] = "登录ID";
	$lang['user_id'] = "用户名";
	$lang['name'] = "名称";
	$lang['phone'] = "电话";
	$lang['date_join'] = "加入日期";
	$lang['attempt'] = "尝试";
	$lang['last_called'] = "最后呼叫";
	$lang['update'] = "更新";
	$lang['not_available'] = "不可用";

	$lang['call_skype'] = "从Skype 通话";
	$lang['end_call'] = "结束通话";
	$lang['campaign'] = "竞选活动";
	$lang['t_n_c'] = "条款和条件";
	$lang['notes'] = "笔记";
	$lang['promotion_url'] = "促销网址/链接";
	$lang['interested'] = "有兴趣";
	$lang['not_interested'] = "没兴趣";
	$lang['remarks'] = "备注";
	$lang['submit'] = "次序";

	$lang['result'] = "结果";
	$lang['reached'] = "到达";
	$lang['unreached'] = "未得";
	$lang['blocked'] = "锁定";
	$lang['invalid number'] = "无效号码";
	
	$lang['type'] = "类型";
	$lang['full_conversation'] = "完整的对话";
	$lang['busy'] = "忙";
	$lang['wrong_person'] = "错误的人";
	$lang['hang_up'] = "挂断";

	$lang['action'] = "行动";
	$lang['email'] = "电子邮件";
	$lang['message'] = "信息";
	$lang['preferred_language'] = "首选语言";
	$lang['call_after'] = "打电话";
	$lang['seconds'] = "第二次";
	$lang['minutes'] = "分钟）";
	$lang['days'] = "天）";
	$lang['weeks'] = "周";
	$lang['no_action'] = "没有动作";

	$lang['recent_transaction'] = " 最近交易";
	$lang['date'] = "日期";
	$lang['promo'] = "促销";
	$lang['view'] = "视图";

	$lang['next'] = "下一个";
	$lang['previous'] = "以前";
	$lang['finish'] = "次序";

	$lang['activity_summary'] = "活动摘要";
	$lang['transaction_result'] = "交易结果";

	$lang['revise_email'] = "修改电子邮件";
	$lang['revise_phone_number'] = "修改电话号码";
	$lang['new_email'] = "新邮件";
	$lang['new_phone_number'] = "新电话号码";
	$lang['close'] = "关";
	$lang['save_changes'] = "保存更改";
	$lang['do_not_call'] = "不要打电话";
?>