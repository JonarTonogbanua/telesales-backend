<?php  
	// PLEASE CHANGE THE VALUE INSIDE THE QUOTATIONS ON THE RIGHT SIDE
	//$lang['sample'] = 'CHANGE ME!';

	// DONT MODIFY THIS
	$lang['dashboard'] = 'Dashboard';
	$lang['data_wizard'] = 'Data Wizard';
	$lang['call_list'] = 'Call List';
	$lang['telesales'] = 'Telesales';
	$lang['settings'] = 'Settings';
	$lang['general_settings'] = 'General Settings';
	$lang['promo_settings'] = 'Promo Settings';
	$lang['reports'] = 'Reports';
	$lang['call_reports'] = 'Call Reports';
	$lang['agent_reports'] = 'Agent Reports';
	// DONT MODIFY THIS

	//START HERE 
	$lang['player_info'] = "player info";
	$lang['campaign_promo'] = "campaign promo";
	$lang['login_id'] = "login id";
	$lang['user_id'] = "user id";
	$lang['name'] = "name";
	$lang['phone'] = "phone";
	$lang['date_join'] = "date join";
	$lang['attempt'] = "call attempt";
	$lang['last_called'] = "last called";
	$lang['update'] = "update";
	$lang['not_available'] = "not available";

	$lang['call_skype'] = "call skype";
	$lang['end_call'] = "end call";
	$lang['campaign'] = "campaign";
	$lang['t_n_c'] = "terms and conditions";
	$lang['notes'] = "notes";
	$lang['promotion_url'] = "promotion url / links";
	$lang['interested'] = "interested";
	$lang['not_interested'] = "not interested";
	$lang['remarks'] = "remarks";
	$lang['submit'] = "submit";

	$lang['result'] = "result";
	$lang['reached'] = "reached";
	$lang['unreached'] = "unreached";
	$lang['blocked'] = "blocked";
	$lang['invalid number'] = "invalid number";
	
	$lang['type'] = "type";
	$lang['full_conversation'] = "full conversation";
	$lang['busy'] = "busy";
	$lang['wrong_person'] = "wrong person";
	$lang['hang_up'] = "hang up";

	$lang['action'] = "action";
	$lang['email'] = "email";
	$lang['message'] = "message";
	$lang['preferred_language'] = "preferred language";
	$lang['call_after'] = "call after";
	$lang['seconds'] = "second(s)";
	$lang['minutes'] = "minute(s)";
	$lang['days'] = "day(s)";
	$lang['weeks'] = "week(s)";
	$lang['no_action'] = "no action";

	$lang['recent_transaction'] = " recent transaction";
	$lang['date'] = "date";
	$lang['promo'] = "promo";
	$lang['view'] = "view";

	$lang['next'] = "next";
	$lang['previous'] = "previous";
	$lang['finish'] = "submit";

	$lang['activity_summary'] = "activity summary";
	$lang['transaction_result'] = "transaction result";

	$lang['revise_email'] = "revise email";
	$lang['revise_phone_number'] = "revise phone number";
	$lang['new_email'] = "new email";
	$lang['new_phone_number'] = "new phone number";
	$lang['close'] = "close";
	$lang['save_changes'] = "save changes";
?>